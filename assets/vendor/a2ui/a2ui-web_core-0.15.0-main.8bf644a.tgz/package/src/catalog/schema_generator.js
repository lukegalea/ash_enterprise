/*
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { zodToJsonSchema } from 'zod-to-json-schema';
import { isAtLeastVersion, toCanonicalVersion } from '../common/semver.js';
import { CommonSchemas } from '../types/common-types.js';
import { exclusiveUnionOverride } from './exclusive_union.js';
import { catalogDocumentModel, deepCopyJson, THEME_DOCUMENT_KEYS, } from './schema_serializer.js';
import { isShorthandParameterMap } from './schema_loader.js';
import { schemaRequiresArgs, standardDefsForVersion } from './spec_shape.js';
/**
 * Resolves the appropriate standard $defs dictionary based on options or catalog configuration.
 *
 * An explicit `options.protocolVersion` wins over the catalog's own `protocolVersion`, so a
 * caller can serialize a catalog against another version's definitions. A version with no
 * entry of its own at or above 1.0, such as 1.0.1 or 1.1, gets the v1.0 definitions, as the
 * schema loader and payload validator already treat such versions as v1.0. Any other
 * version falls back to the v0.9 definitions.
 */
function getStandardDefsForCatalog(catalog, options) {
    if (options?.standardDefs) {
        return options.standardDefs;
    }
    return standardDefsForVersion(options?.protocolVersion ?? catalog.protocolVersion);
}
/**
 * Matches a reference to a definition of another document, such as
 * `common_types.json#/$defs/DynamicString`, capturing the definition's name and
 * any deeper pointer into it (`/oneOf/0` in
 * `common_types.json#/$defs/DynamicString/oneOf/0`).
 */
const EXTERNAL_DEF_REF = /^[^#]+#\/(?:\$defs|definitions)\/([^/]+)(\/.*)?$/;
/**
 * Rewrites a reference into another document's definitions as the local
 * reference to the bundled definition, keeping a deeper pointer into it whole:
 * `common_types.json#/$defs/DynamicString/oneOf/0` becomes
 * `#/$defs/DynamicString/oneOf/0`. A bare name, as a `REF:` marker may carry,
 * names the definition itself.
 */
function localizeExternalDefRef(ref) {
    const match = EXTERNAL_DEF_REF.exec(ref);
    if (match)
        return `#/$defs/${match[1]}${match[2] ?? ''}`;
    return `#/$defs/${ref.split('/').pop()}`;
}
/**
 * Returns the name of the definition a local `#/$defs/...` reference reaches,
 * which is the first segment of the pointer, or `undefined` for any other
 * reference.
 */
function localDefName(ref) {
    if (!ref.startsWith('#/$defs/'))
        return undefined;
    return ref.substring('#/$defs/'.length).split('/')[0].replace(/~1/g, '/').replace(/~0/g, '~');
}
/**
 * Transforms a schema node with a REF description into a `$ref` definition node.
 */
function transformRefDescriptionNode(obj) {
    if (typeof obj.description !== 'string' || !obj.description.startsWith('REF:')) {
        return false;
    }
    const content = obj.description.substring(4);
    const pipeIndex = content.indexOf('|');
    const ref = pipeIndex === -1 ? content : content.substring(0, pipeIndex);
    const desc = pipeIndex === -1 ? '' : content.substring(pipeIndex + 1);
    const savedDefault = obj.default;
    for (const key of Object.keys(obj)) {
        delete obj[key];
    }
    obj['$ref'] = ref.startsWith('#') ? ref : localizeExternalDefRef(ref);
    if (savedDefault !== undefined) {
        obj['default'] = savedDefault;
    }
    if (desc) {
        obj['description'] = desc;
    }
    return true;
}
/**
 * Normalizes property schema structures like allOf and additionalProperties.
 *
 * A `z.union` comes out as `anyOf`, and stays `anyOf`: a value may match more
 * than one branch. Only a union that requires exactly one match comes out as
 * `oneOf` (see `exclusiveUnionOverride`).
 */
function cleanSchemaProperties(obj, options = {}) {
    // A Zod schema piped from `z.any()` comes out as `allOf: [{}, <schema>]`.
    // The empty member constrains nothing.
    if (Array.isArray(obj.allOf)) {
        const members = obj.allOf.filter(m => !(typeof m === 'object' && m !== null && Object.keys(m).length === 0));
        const only = members.length === 1 ? members[0] : undefined;
        if (typeof only === 'object' &&
            only !== null &&
            !Array.isArray(only) &&
            Object.keys(only).every(key => !(key in obj) || key === 'allOf')) {
            delete obj.allOf;
            Object.assign(obj, only);
        }
        else if (members.length === 0) {
            delete obj.allOf;
        }
        else {
            obj.allOf = members;
        }
    }
    if (options.stripAdditionalProperties) {
        delete obj['additionalProperties'];
        delete obj['unevaluatedProperties'];
    }
    else {
        if (obj.additionalProperties &&
            typeof obj.additionalProperties === 'object' &&
            Object.keys(obj.additionalProperties).length === 0) {
            obj.additionalProperties = true;
        }
        if (obj.unevaluatedProperties &&
            typeof obj.unevaluatedProperties === 'object' &&
            Object.keys(obj.unevaluatedProperties).length === 0) {
            obj.unevaluatedProperties = true;
        }
    }
    if ('$schema' in obj) {
        delete obj['$schema'];
    }
}
/**
 * Cleans auto-generated Zod schema artifacts and transforms REF markers into explicit `$ref` objects.
 *
 * Removes schema metadata and converts `REF:<url>|<desc>` description markers into `$ref` references.
 *
 * @param node The schema object or array node to sanitize in place.
 * @param visited Set of visited objects to prevent infinite recursion on cyclic structures.
 * @param options Sanitization options such as stripping additionalProperties.
 */
export function cleanSchemaNode(node, visited = new Set(), options = {}) {
    if (typeof node !== 'object' || node === null)
        return;
    if (visited.has(node))
        return;
    visited.add(node);
    if (Array.isArray(node)) {
        for (const item of node) {
            cleanSchemaNode(item, visited, options);
        }
        return;
    }
    const obj = node;
    if (transformRefDescriptionNode(obj)) {
        return;
    }
    cleanSchemaProperties(obj, options);
    for (const key of Object.keys(obj)) {
        cleanSchemaNode(obj[key], visited, options);
    }
}
function isJsonObject(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/** Keywords a reference to a standard definition keeps besides `$ref`. */
const REF_ANNOTATION_KEYWORDS = new Set([
    'description',
    'title',
    'default',
    'deprecated',
    'readOnly',
    'writeOnly',
    'examples',
]);
/** Keys of the component envelope, which the validation schema declares itself. */
const COMPONENT_ENVELOPE_KEYS = new Set(['id', 'component', 'catalogId', '@catalogId']);
/**
 * The pieces {@link collectSourceSubSchemas} takes from a standard mixin such
 * as `ComponentCommon`, as opposed to the component's own definition.
 */
const standardMixinPieces = new WeakSet();
/** Definitions of a catalog document that the validation schema generates itself. */
const GENERATED_DEF_NAMES = new Set(['anyComponent', 'anyFunction', 'theme']);
/**
 * Matches a reference to a common type, local or in `common_types.json`,
 * capturing the document, the definition's name and any deeper pointer into the
 * definition.
 */
const COMMON_TYPE_REF = /^(?:([^#]*common_types\.json))?#\/\$defs\/([^/]+)(\/.*)?$/;
/** Matches a reference to a definition of the standard mixins components inherit. */
const STANDARD_MIXIN_REF = /\/(ComponentCommon|Checkable)$/;
/**
 * Points `node` at the standard definition `name`, or at `pointer` within it,
 * and, when `node` references the whole definition and has no description of
 * its own, gives it the definition's.
 */
function localizeStandardRef(node, name, standardDefs, pointer = '') {
    node['$ref'] = `#/$defs/${name}${pointer}`;
    if (pointer || node['description'] !== undefined)
        return;
    const definition = standardDefs[name];
    if (isJsonObject(definition) && typeof definition['description'] === 'string') {
        node['description'] = definition['description'];
    }
}
/**
 * Rewrites, in place, every reference in an authored schema to a common type
 * as a local reference to the bundled standard definition. A reference deeper
 * into a definition, such as `common_types.json#/$defs/DynamicString/oneOf/0`,
 * keeps its whole pointer.
 *
 * A reference to a whole definition without a description of its own takes the
 * description of the definition it names. With `annotationsOnly`, as for
 * component properties, the reference also drops every keyword other than
 * annotations, since the standard definition alone defines the value.
 */
function restoreSourceRefs(node, standardDefs, annotationsOnly) {
    if (Array.isArray(node)) {
        for (const item of node)
            restoreSourceRefs(item, standardDefs, annotationsOnly);
        return;
    }
    if (!isJsonObject(node))
        return;
    const ref = node['$ref'];
    const match = typeof ref === 'string' ? COMMON_TYPE_REF.exec(ref) : null;
    if (match) {
        const [, document, name, pointer] = match;
        if (document !== undefined || name in standardDefs) {
            if (annotationsOnly) {
                for (const key of Object.keys(node)) {
                    if (key !== '$ref' && !REF_ANNOTATION_KEYWORDS.has(key))
                        delete node[key];
                }
                localizeStandardRef(node, name, standardDefs, pointer);
                return;
            }
            localizeStandardRef(node, name, standardDefs, pointer);
        }
    }
    for (const value of Object.values(node)) {
        restoreSourceRefs(value, standardDefs, annotationsOnly);
    }
}
/** Resolves a local JSON pointer such as `#/$defs/Base` against `rootDoc`. */
function resolveLocalPointer(rootDoc, pointer) {
    if (!pointer.startsWith('#/'))
        return undefined;
    let current = rootDoc;
    for (const raw of pointer.substring(2).split('/')) {
        const segment = raw.replace(/~([01])/g, (_, p1) => (p1 === '1' ? '/' : '~'));
        if (!isJsonObject(current) || !(segment in current))
            return undefined;
        current = current[segment];
    }
    return current;
}
/**
 * Gathers the pieces of an authored component definition that declare its
 * properties, from the most generic to the most specific: the standard mixins
 * (`ComponentCommon`, `Checkable` and the like) its `allOf` references, the
 * local definitions it references, its inline `allOf` members and, last, the
 * definition itself.
 *
 * A standard mixin contributes its properties and `required` list but not its
 * description, which describes the mixin rather than the component.
 */
function collectSourceSubSchemas(schema, context, visited) {
    const inline = [];
    const local = [];
    const mixins = [];
    for (const sub of Array.isArray(schema['allOf']) ? schema['allOf'] : []) {
        if (!isJsonObject(sub))
            continue;
        const ref = sub['$ref'];
        if (typeof ref !== 'string') {
            inline.push(...collectSourceSubSchemas(sub, context, visited));
            continue;
        }
        const mixinName = STANDARD_MIXIN_REF.exec(ref)?.[1];
        const target = ref.startsWith('#/') ? resolveLocalPointer(context.rootDoc, ref) : undefined;
        if (mixinName === undefined && isJsonObject(target)) {
            if (!visited.has(ref)) {
                visited.add(ref);
                local.push(...collectSourceSubSchemas(target, context, visited));
            }
            continue;
        }
        const external = EXTERNAL_DEF_REF.exec(ref);
        const name = mixinName ?? (external && !external[2] ? external[1] : undefined);
        const mixin = name !== undefined ? context.standardDefs[name] : undefined;
        if (isJsonObject(mixin) && isJsonObject(mixin['properties'])) {
            const piece = {
                properties: deepCopyJson(mixin['properties']),
                ...(Array.isArray(mixin['required']) ? { required: mixin['required'] } : {}),
            };
            standardMixinPieces.add(piece);
            mixins.push(piece);
        }
    }
    const pieces = [...mixins, ...local, ...inline];
    if ('properties' in schema || 'description' in schema)
        pieces.push(schema);
    return pieces;
}
/**
 * Builds a component's properties, `required` list and description from its
 * authored definition, as the protocol reads it: the properties of every piece
 * {@link collectSourceSubSchemas} gathers, a more specific piece overriding a
 * property a more generic one declares, and the union of their `required`
 * lists, without the envelope keys. The description is the most specific one.
 */
function sourceComponentSchema(source, context) {
    const pieces = collectSourceSubSchemas(source, context, new Set());
    let description;
    const props = {};
    // Envelope keys the component declares as its own properties, such as a
    // custom `catalogId`, rather than inheriting from a standard mixin.
    const ownEnvelopeKeys = new Set();
    const required = new Set();
    for (const piece of pieces) {
        if (typeof piece['description'] === 'string')
            description = piece['description'];
        if (isJsonObject(piece['properties'])) {
            Object.assign(props, piece['properties']);
            if (!standardMixinPieces.has(piece)) {
                for (const name of Object.keys(piece['properties']))
                    ownEnvelopeKeys.add(name);
            }
        }
        if (Array.isArray(piece['required'])) {
            for (const name of piece['required']) {
                if (typeof name === 'string')
                    required.add(name);
            }
        }
    }
    // A bare `catalogId` the component declares itself is one of its own
    // properties: below v1.0 the protocol has no per-component catalog, and
    // from v1.0 the envelope field is `@catalogId`.
    const isEnvelopeKey = (name) => COMPONENT_ENVELOPE_KEYS.has(name) && !(name === 'catalogId' && ownEnvelopeKeys.has(name));
    const copied = {};
    for (const [name, schema] of Object.entries(props)) {
        if (isEnvelopeKey(name))
            continue;
        const copy = deepCopyJson(schema);
        restoreSourceRefs(copy, context.standardDefs, true);
        copied[name] = copy;
    }
    return {
        props: copied,
        required: [...required].filter(name => !isEnvelopeKey(name)).sort(),
        ...(description !== undefined ? { description } : {}),
    };
}
/**
 * Returns the `args` schema a function's definition declares, read as the
 * schema loader reads it, or `undefined` for a function without a usable
 * definition.
 */
function authoredFunctionArgs(name, context) {
    const source = context.model.functions.get(name);
    if (!source)
        return undefined;
    const props = isJsonObject(source.properties) ? source.properties : undefined;
    const explicit = props?.args ?? source.args ?? source.parameters;
    if (explicit !== undefined) {
        if (!isJsonObject(explicit))
            return {};
        // A bare map of argument schemas, with the object keywords beside it.
        if (isShorthandParameterMap(explicit)) {
            return {
                type: 'object',
                properties: explicit,
                ...(source.required !== undefined ? { required: source.required } : {}),
                ...(source.additionalProperties !== undefined
                    ? { additionalProperties: source.additionalProperties }
                    : {}),
            };
        }
        return explicit;
    }
    // A definition that is not a call schema is its own argument schema; its
    // description, title and call metadata describe the function, not the
    // arguments.
    const isCallSchema = props && ('call' in props || '@call' in props || 'function' in props);
    if (!props || isCallSchema)
        return {};
    const { description: _description, title: _title, name: _name, returnType: _returnType, allowedCallers: _allowedCallers, requiresUserActivation: _requiresUserActivation, ...args } = source;
    return args;
}
/**
 * Returns the theme schema a catalog declares: under one of the document's
 * top-level theme keys, or as `$defs.theme`.
 */
function authoredTheme(model) {
    const theme = THEME_DOCUMENT_KEYS.map(key => model.extensionFields[key]).find(value => value !== undefined) ??
        model.defs['theme'];
    if (!isJsonObject(theme))
        return undefined;
    return 'properties' in theme || 'allOf' in theme || theme.type === 'object'
        ? theme
        : { type: 'object', properties: theme };
}
function isV08Catalog(catalog) {
    const version = toCanonicalVersion(catalog.protocolVersion) ?? catalog.protocolVersion;
    return version === '0.8' || catalog.id.includes('v0_8') || catalog.id.includes('v0.8');
}
/**
 * Builds the theme definition.
 *
 * A theme loaded from JSON is emitted as written; one defined in code is
 * generated from its Zod schema. From v0.9 a theme that declares neither
 * `additionalProperties` nor `unevaluatedProperties` gets
 * `additionalProperties: true`, as themes are open; a v0.8 theme stays as
 * written.
 */
function processTheme(catalog, defs, generated, context) {
    if (!catalog.themeSchema)
        return;
    const isV08 = isV08Catalog(catalog);
    const authored = authoredTheme(context.model);
    if (authored) {
        const theme = deepCopyJson({ ...authored });
        if (!isV08 &&
            theme['additionalProperties'] === undefined &&
            theme['unevaluatedProperties'] === undefined) {
            theme['additionalProperties'] = true;
        }
        defs['theme'] = theme;
        return;
    }
    const themeRaw = zodToJsonSchema(catalog.themeSchema, {
        target: 'jsonSchema2019-09',
        $refStrategy: 'none',
        override: exclusiveUnionOverride,
    });
    cleanSchemaNode(themeRaw);
    mergeGeneratedDefs(themeRaw, defs, generated);
    const closed = themeRaw.additionalProperties === false;
    const themeObj = {
        type: 'object',
        ...(typeof themeRaw.description === 'string' && !themeRaw.description.startsWith('REF:')
            ? { description: themeRaw.description }
            : {}),
        properties: themeRaw.properties || {},
        ...(Array.isArray(themeRaw.required) && themeRaw.required.length > 0
            ? { required: themeRaw.required }
            : {}),
        ...(closed
            ? { additionalProperties: false }
            : isV08
                ? {}
                : {
                    additionalProperties: themeRaw.additionalProperties !== undefined ? themeRaw.additionalProperties : true,
                }),
    };
    generated.push(themeObj);
    defs['theme'] = themeObj;
}
/**
 * Moves the definitions a Zod-generated schema carries into `defs`, recording
 * them as generated.
 */
function mergeGeneratedDefs(raw, defs, generated) {
    const nested = isJsonObject(raw.definitions)
        ? raw.definitions
        : isJsonObject(raw.$defs)
            ? raw.$defs
            : undefined;
    delete raw.definitions;
    delete raw.$defs;
    if (!nested)
        return;
    Object.assign(defs, nested);
    generated.push(nested);
}
/**
 * Extracts raw Zod properties, required fields, and definitions from a component API schema.
 */
function extractZodComponentSchema(comp, defs, generated) {
    if (!comp.schema || typeof comp.schema !== 'object' || !('safeParse' in comp.schema)) {
        return { props: {}, reqList: [], additionalProps: undefined };
    }
    const rawZod = zodToJsonSchema(comp.schema, {
        target: 'jsonSchema2019-09',
        $refStrategy: 'none',
        override: exclusiveUnionOverride,
    });
    cleanSchemaNode(rawZod);
    mergeGeneratedDefs(rawZod, defs, generated);
    const props = rawZod.properties || {};
    const reqList = Array.isArray(rawZod.required)
        ? rawZod.required.filter(r => r !== 'component' && r !== 'id')
        : [];
    const rawExtra = rawZod.unevaluatedProperties ?? rawZod.additionalProperties;
    const additionalProps = typeof rawExtra === 'boolean' || isJsonObject(rawExtra)
        ? rawExtra
        : undefined;
    return { props, reqList, additionalProps };
}
/**
 * Returns the description on a component's Zod schema, ignoring internal
 * `REF:` markers.
 */
function zodComponentDescription(comp) {
    const zodDescription = comp.schema?.description;
    return typeof zodDescription === 'string' && !zodDescription.startsWith('REF:')
        ? zodDescription
        : undefined;
}
/**
 * Returns the closure a component's source document declares
 * (`unevaluatedProperties`, else `additionalProperties`), if any. A component
 * defined in code declares none.
 */
function authoredClosure(source) {
    return source['unevaluatedProperties'] ?? source['additionalProperties'];
}
/**
 * Builds the schema of one component with the component envelope: an `id`,
 * the `component` constant and the component's own properties.
 *
 * A component with a definition in the catalog's document model (one loaded
 * from JSON, or one whose definition is computed from its specification
 * model) is built from that definition, so every nested keyword survives; any
 * other component defined in code is generated from its Zod schema.
 */
function processSingleComponent(name, comp, defs, generated, context, options) {
    let props;
    let reqList;
    let description;
    let closure;
    const source = context.model.components.get(name);
    if (source) {
        ({ props, required: reqList, description } = sourceComponentSchema(source, context));
        // From v1.0 the protocol's Component envelope combines the entry with
        // ComponentCommon (accessibility, catalogId, metadata) under its own
        // `unevaluatedProperties: false`, so the entry is closed only when its
        // author closed it. Earlier versions close it unless it was declared open.
        closure = authoredClosure(source) ?? (context.isV10 ? undefined : false);
    }
    else {
        const extracted = extractZodComponentSchema(comp, defs, generated);
        const { component: _ignoredComp, id: _ignoredId, ...sanitized } = extracted.props;
        generated.push(sanitized);
        props = sanitized;
        reqList = extracted.reqList;
        description = zodComponentDescription(comp);
        closure = context.isV10
            ? extracted.additionalProps === true
                ? true
                : undefined
            : (extracted.additionalProps ?? false);
    }
    const id = {};
    localizeStandardRef(id, 'ComponentId', context.standardDefs);
    const innerProperties = { id, ...props, component: { const: name } };
    const innerRequired = ['id', ...reqList, 'component'];
    const closureEntry = closure !== undefined ? { unevaluatedProperties: closure } : {};
    let compSchemaObj;
    if (options?.componentEnvelopeRef) {
        compSchemaObj = {
            ...(description !== undefined ? { description } : {}),
            allOf: [
                { $ref: options.componentEnvelopeRef },
                {
                    type: 'object',
                    properties: innerProperties,
                    required: innerRequired,
                },
            ],
            ...closureEntry,
        };
    }
    else {
        compSchemaObj = {
            type: 'object',
            ...(description !== undefined ? { description } : {}),
            properties: innerProperties,
            required: innerRequired,
            ...closureEntry,
        };
    }
    if (comp.allowedParents && comp.allowedParents.length > 0) {
        compSchemaObj['allowedParents'] = comp.allowedParents;
    }
    if (comp.allowedChildren && comp.allowedChildren.length > 0) {
        compSchemaObj['allowedChildren'] = comp.allowedChildren;
    }
    return compSchemaObj;
}
function processComponents(catalog, schema, defs, generated, context, options) {
    if (catalog.components.size === 0) {
        schema['components'] = {};
        return;
    }
    const componentsMap = {};
    for (const [name, comp] of catalog.components.entries()) {
        componentsMap[name] = processSingleComponent(name, comp, defs, generated, context, options);
    }
    schema['components'] = componentsMap;
    defs['anyComponent'] = {
        oneOf: Array.from(catalog.components.keys()).map(name => ({
            $ref: `#/components/${name}`,
        })),
        discriminator: {
            propertyName: 'component',
        },
    };
}
/**
 * Builds the JSON Schema of a function's `args` object, merging any nested
 * definitions into `defs`.
 *
 * Arguments loaded from JSON are copied as written; ones defined in code are
 * generated from their Zod schema. An object schema is closed with
 * `unevaluatedProperties`: the declared `unevaluatedProperties` or
 * `additionalProperties`, and `false` when it declares neither.
 */
function buildFunctionArgsSchema(name, fn, defs, generated, context) {
    let paramSchemaObj;
    const authored = authoredFunctionArgs(name, context);
    if (authored) {
        paramSchemaObj = deepCopyJson(authored);
        restoreSourceRefs(paramSchemaObj, context.standardDefs, false);
    }
    else if (fn.schema && typeof fn.schema === 'object' && 'safeParse' in fn.schema) {
        const rawZod = zodToJsonSchema(fn.schema, {
            target: 'jsonSchema2019-09',
            $refStrategy: 'none',
            override: exclusiveUnionOverride,
        });
        cleanSchemaNode(rawZod);
        mergeGeneratedDefs(rawZod, defs, generated);
        generated.push(rawZod);
        paramSchemaObj = rawZod;
    }
    else {
        paramSchemaObj = { type: 'object', properties: {} };
    }
    if (paramSchemaObj.type === 'object') {
        const additional = paramSchemaObj.additionalProperties;
        delete paramSchemaObj.additionalProperties;
        paramSchemaObj.unevaluatedProperties =
            paramSchemaObj.unevaluatedProperties ?? additional ?? false;
    }
    return paramSchemaObj;
}
/**
 * Builds the schema that validates a wire `FunctionCall` of one function.
 *
 * The call names the function under `callKey` (`call` before v1.0, `@call` from
 * v1.0), passes its arguments under `args` and may restate its `returnType`. A
 * call to a function without required parameters may omit `args` altogether.
 */
function processSingleFunction(name, fn, defs, generated, context) {
    const argsSchema = buildFunctionArgsSchema(name, fn, defs, generated, context);
    const hasRequiredArgs = schemaRequiresArgs(argsSchema, { ...context.defs, ...defs });
    const callKey = context.isV10 ? '@call' : 'call';
    const required = hasRequiredArgs ? [callKey, 'args'] : [callKey];
    if (context.isV10) {
        // The published v1.0 shape. The entry stays open: the bundled FunctionCall
        // combines it with FunctionCommon (`catalogId` and the like) under its own
        // `unevaluatedProperties: false`, which a closed entry would defeat.
        return {
            type: 'object',
            ...(fn.description ? { description: fn.description } : {}),
            returnType: fn.returnType,
            ...(fn.allowedCallers !== undefined ? { allowedCallers: fn.allowedCallers } : {}),
            ...(fn.requiresUserActivation !== undefined
                ? { requiresUserActivation: fn.requiresUserActivation }
                : {}),
            properties: {
                '@call': { const: name },
                args: argsSchema,
            },
            required,
        };
    }
    return {
        type: 'object',
        ...(fn.description ? { description: fn.description } : {}),
        properties: {
            call: { const: name },
            args: argsSchema,
            returnType: { const: fn.returnType },
        },
        required,
        unevaluatedProperties: false,
    };
}
function processFunctions(catalog, schema, defs, generated, context) {
    // System functions such as `@index` are defined by the protocol itself, not
    // by the catalog.
    const names = Array.from(catalog.functions.keys()).filter(name => !name.startsWith('@'));
    if (names.length === 0)
        return;
    const functionsMap = {};
    for (const name of names) {
        functionsMap[name] = processSingleFunction(name, catalog.functions.get(name), defs, generated, context);
    }
    schema['functions'] = functionsMap;
    defs['anyFunction'] = {
        oneOf: names.map(name => ({
            $ref: `#/functions/${name}`,
        })),
    };
}
/**
 * Descriptions the shared Zod mirrors of the common types carry on their
 * `REF:` markers, by definition name.
 *
 * The mirrors are shared by every protocol version, so their text is one
 * version's. A reference that carries exactly this text did not get it from
 * its author.
 */
const MIRROR_REF_DESCRIPTIONS = new Map(Object.values(CommonSchemas).flatMap(mirror => {
    const description = mirror.description;
    if (typeof description !== 'string' || !description.startsWith('REF:'))
        return [];
    const content = description.substring(4);
    const pipeIndex = content.indexOf('|');
    if (pipeIndex === -1)
        return [];
    const name = content.substring(0, pipeIndex).split('/').pop();
    return [[name, content.substring(pipeIndex + 1)]];
}));
/**
 * Rewrites every reference to a definition of another document, such as
 * `common_types.json#/$defs/DynamicString` or `catalog.json#/$defs/anyFunction`,
 * to the bundled `#/$defs/<name>`. A reference deeper into the definition keeps
 * its whole pointer: `common_types.json#/$defs/DynamicString/oneOf/0` becomes
 * `#/$defs/DynamicString/oneOf/0`.
 *
 * @param node The schema to rewrite in place.
 * @param keep A reference to leave as it is: the caller's `componentEnvelopeRef`,
 *     which names a document the caller resolves itself.
 * @throws {Error} If a reference points into another document but not into one
 *     of its definitions, which the bundle cannot carry.
 */
function localizeRefs(node, keep, visited = new Set()) {
    if (typeof node !== 'object' || node === null || visited.has(node))
        return;
    visited.add(node);
    if (Array.isArray(node)) {
        for (const item of node)
            localizeRefs(item, keep, visited);
        return;
    }
    const obj = node;
    const ref = obj['$ref'];
    if (typeof ref === 'string' && !ref.startsWith('#') && ref !== keep) {
        if (!EXTERNAL_DEF_REF.test(ref)) {
            throw new Error(`Cannot bundle the external schema reference '${ref}'.`);
        }
        obj['$ref'] = localizeExternalDefRef(ref);
    }
    for (const value of Object.values(obj))
        localizeRefs(value, keep, visited);
}
/**
 * Gives each reference to a whole standard definition in a Zod-generated schema
 * the description of the definition it names, from the catalog's own protocol
 * version, unless the reference has a description of its own. A reference
 * deeper into a definition names no definition and is left as it is.
 */
function describeStandardRefs(node, standardDefs, visited = new Set()) {
    if (typeof node !== 'object' || node === null || visited.has(node))
        return;
    visited.add(node);
    if (Array.isArray(node)) {
        for (const item of node)
            describeStandardRefs(item, standardDefs, visited);
        return;
    }
    const obj = node;
    const ref = obj['$ref'];
    if (typeof ref === 'string' && ref.startsWith('#/$defs/')) {
        const name = ref.substring('#/$defs/'.length);
        const definition = name.includes('/')
            ? undefined
            : standardDefs[name];
        const inherited = obj['description'] === undefined || obj['description'] === MIRROR_REF_DESCRIPTIONS.get(name);
        if (definition && inherited) {
            if (typeof definition['description'] === 'string') {
                obj['description'] = definition['description'];
            }
            else {
                delete obj['description'];
            }
        }
    }
    for (const value of Object.values(obj))
        describeStandardRefs(value, standardDefs, visited);
}
/**
 * Adds to `referenced` the name of every definition a local `#/$defs/...`
 * reference in `node` reaches: the first segment of its pointer, so that
 * `#/$defs/DynamicString/oneOf/0` bundles `DynamicString`.
 */
function collectReferencedDefs(node, referenced, visited = new Set()) {
    if (typeof node !== 'object' || node === null)
        return;
    if (visited.has(node))
        return;
    visited.add(node);
    if (typeof node['$ref'] === 'string') {
        const name = localDefName(node['$ref']);
        if (name !== undefined)
            referenced.add(name);
    }
    if (Array.isArray(node)) {
        for (const item of node) {
            collectReferencedDefs(item, referenced, visited);
        }
    }
    else {
        for (const val of Object.values(node)) {
            collectReferencedDefs(val, referenced, visited);
        }
    }
}
/**
 * Reconstructs a specification-compliant A2UI catalog JSON Schema document from a Catalog instance.
 *
 * Components, functions and a theme with a definition in the catalog's
 * document model (see `catalogDocumentModel`) are built from it; other ones
 * defined in code are generated from their Zod schemas. References to common types become local references, and the
 * standard definitions and authored local definitions they reach are copied
 * into `$defs`, alongside the component and function unions.
 *
 * @param catalog The catalog instance to serialize.
 * @param options Optional configuration options such as component envelope wrapping.
 * @returns Specification-compliant A2UI Catalog JSON Schema object.
 */
export function generateValidationSchema(catalog, options) {
    const schema = {
        $schema: 'https://json-schema.org/draft/2020-12/schema',
        // The declared version, in the bare semantic version form
        // catalog_definition.json requires: `v0.9.1` becomes `0.9.1`.
        ...(typeof catalog.declaredProtocolVersion === 'string'
            ? { protocolVersion: catalog.declaredProtocolVersion.trim().replace(/^[vV](?=\d)/, '') }
            : {}),
        catalogId: catalog.id,
    };
    if (catalog.instructions) {
        schema['instructions'] = catalog.instructions;
    }
    const standardDefs = getStandardDefsForCatalog(catalog, options);
    const version = options?.protocolVersion ?? catalog.protocolVersion;
    const model = catalogDocumentModel(catalog);
    const authoredDefs = model.defs;
    const context = {
        standardDefs,
        model,
        defs: authoredDefs,
        rootDoc: { $defs: authoredDefs },
        isV10: Boolean(version) && isAtLeastVersion(version, '1.0'),
    };
    const defs = {};
    // The parts generated from Zod schemas, whose references to standard
    // definitions take those definitions' descriptions.
    const generated = [];
    processTheme(catalog, defs, generated, context);
    processComponents(catalog, schema, defs, generated, context, options);
    processFunctions(catalog, schema, defs, generated, context);
    // Everything generated so far is the catalog's own content; standard
    // definitions are copied in below and left as their version defines them.
    localizeRefs(schema, options?.componentEnvelopeRef);
    localizeRefs(defs);
    for (const node of generated)
        describeStandardRefs(node, standardDefs);
    // Fixed-point iteration to discover all transitive $defs references
    let defsCountBefore;
    do {
        defsCountBefore = Object.keys(defs).length;
        const referenced = new Set();
        collectReferencedDefs(schema, referenced);
        collectReferencedDefs(defs, referenced);
        if (referenced.has('DynamicString') ||
            referenced.has('DynamicNumber') ||
            referenced.has('DynamicBoolean') ||
            referenced.has('DynamicValue')) {
            referenced.add('DataBinding');
            referenced.add('FunctionCall');
        }
        for (const refName of referenced) {
            if (refName in defs)
                continue;
            if (refName in standardDefs) {
                const copied = deepCopyJson(standardDefs[refName]);
                localizeRefs(copied);
                defs[refName] = copied;
            }
            else if (!GENERATED_DEF_NAMES.has(refName) && refName in authoredDefs) {
                // A definition of the catalog's own, which an authored entry names.
                const copied = deepCopyJson(authoredDefs[refName]);
                restoreSourceRefs(copied, standardDefs, false);
                localizeRefs(copied);
                defs[refName] = copied;
            }
        }
        // FunctionCall names the catalog's function union. A catalog without
        // functions gets the empty union, so the reference still resolves.
        if (referenced.has('anyFunction') && !('anyFunction' in defs)) {
            defs['anyFunction'] = { not: {} };
        }
    } while (Object.keys(defs).length > defsCountBefore);
    if (Object.keys(defs).length > 0) {
        schema['$defs'] = defs;
    }
    return schema;
}
/** @deprecated Use {@link generateValidationSchema} instead. */
export const generateCatalogSchema = generateValidationSchema;
//# sourceMappingURL=schema_generator.js.map