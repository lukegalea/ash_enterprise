/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { z } from 'zod';
import { validateMetadata } from '../common/metadata.js';
import { isAtLeastVersion } from '../common/semver.js';
import { assertUax31Identifier } from '../common/uax31.js';
import { A2uiCatalogError } from '../errors.js';
import { CommonSchemas, ComponentCommonSchema } from '../types/common-types.js';
import { markStandardMixinSchema } from './component_envelope.js';
import { exclusiveUnion } from './exclusive_union.js';
import { JsonComponentApi, JsonFunctionApi } from './json_entries.js';
import { buildComponentUnion, buildFunctionUnion, deepCopyJson, deepFreeze, } from './schema_serializer.js';
/**
 * Protocol version assumed for a catalog schema that does not declare one.
 *
 * Catalog schemas only began carrying `protocolVersion` at v1.0, so a schema
 * that omits it predates that field.
 */
export const DEFAULT_PROTOCOL_VERSION = '0.9';
/**
 * Resolves a JSON Pointer within a root JSON document.
 *
 * Follows RFC 6901 pointer unescaping (~1 -> /, ~0 -> ~).
 *
 * @param rootDoc Root JSON document to resolve within.
 * @param pointer RFC 6901 JSON pointer string.
 * @returns The resolved document subtree, or undefined if not found.
 */
function resolveJsonPointer(rootDoc, pointer) {
    if (!pointer.startsWith('#/'))
        return undefined;
    const segments = pointer
        .slice(2)
        .split('/')
        .map(s => s.replace(/~1/g, '/').replace(/~0/g, '~'));
    let curr = rootDoc;
    for (const seg of segments) {
        if (curr && typeof curr === 'object' && seg in curr) {
            curr = curr[seg];
        }
        else {
            return undefined;
        }
    }
    return typeof curr === 'object' && curr !== null ? curr : undefined;
}
/**
 * Resolves a standard protocol `$ref` to its corresponding common type schema.
 *
 * @param ref JSON Schema reference string.
 * @returns The matching Zod schema, or undefined if not a known protocol definition.
 */
function resolveProtocolRef(ref) {
    const defName = ref.split(/#\/(?:\$defs|definitions)\//)[1];
    return defName && Object.hasOwn(CommonSchemas, defName)
        ? CommonSchemas[defName]
        : undefined;
}
/**
 * Converts an array of JSON Schema enum values to a Zod schema.
 *
 * @param values Allowed enum values.
 * @returns Zod enum, literal, or union schema representing the allowed values.
 */
function convertEnumToZod(values) {
    if (values.length === 0) {
        return z.unknown();
    }
    if (values.every(v => typeof v === 'string')) {
        return z.enum(values);
    }
    if (values.length === 1) {
        return z.literal(values[0]);
    }
    return z.union(values.map(v => z.literal(v)));
}
/**
 * Serializes a value to canonical JSON with deterministically sorted object keys.
 *
 * Produces identical strings for semantically equivalent values regardless of
 * object property insertion order.
 *
 * @param val Value to serialize.
 * @returns Deterministic JSON string representation.
 */
function canonicalJsonStringify(val) {
    if (val === null || typeof val !== 'object') {
        return JSON.stringify(val);
    }
    if (Array.isArray(val)) {
        return `[${val.map(canonicalJsonStringify).join(',')}]`;
    }
    const keys = Object.keys(val).sort();
    const entries = keys.map(k => `${JSON.stringify(k)}:${canonicalJsonStringify(val[k])}`);
    return `{${entries.join(',')}}`;
}
/**
 * Applies `not`, `default`, and `description` modifiers to a converted Zod schema.
 *
 * @param baseZod Base Zod schema before modifiers.
 * @param propSchema Raw property schema definition.
 * @param rootDoc Optional root schema document for resolving nested references.
 * @param visitedPointers Set of JSON pointer references currently being resolved.
 * @param defCache Cache of previously converted definition schemas.
 * @returns The modified Zod schema.
 */
function finalizePropertyZod(baseZod, propSchema, rootDoc, visitedPointers, defCache) {
    let result = baseZod;
    if (propSchema.not && typeof propSchema.not === 'object') {
        const notSchema = convertPropertyToZod(propSchema.not, rootDoc, new Set(visitedPointers), defCache);
        // Checks the value as written, before `baseZod` fills in the defaults of
        // its properties, which `not` must not see.
        result = z.preprocess((val, ctx) => {
            if (notSchema.safeParse(val).success) {
                ctx.addIssue({
                    code: z.ZodIssueCode.custom,
                    message: 'Value matched prohibited "not" schema',
                });
            }
            return val;
        }, result);
    }
    if (propSchema.default !== undefined) {
        result = result.default(propSchema.default);
    }
    if (typeof propSchema.description === 'string') {
        result = result.describe(propSchema.description);
    }
    return result;
}
/**
 * Converts a JSON Schema `$ref` pointer into a Zod schema.
 *
 * Resolves standard protocol definitions from common types, as well as local
 * `#/$defs/...` pointers within the root document. Handles recursive references
 * using `z.lazy` and caches resolved schemas to break cycles.
 *
 * @param ref JSON Schema reference string.
 * @param propSchema Property schema containing the reference.
 * @param rootDoc Root schema document containing definition targets.
 * @param visitedPointers Set of reference pointers currently on the resolution stack.
 * @param defCache Cache mapping reference strings to resolved Zod schemas.
 * @returns Converted Zod schema, or undefined if the reference cannot be resolved.
 */
function convertRefToZod(ref, propSchema, rootDoc, visitedPointers, defCache) {
    const resolvedProtocol = resolveProtocolRef(ref);
    if (resolvedProtocol) {
        const defName = ref.split(/#\/(?:\$defs|definitions)\//)[1];
        const desc = typeof propSchema.description === 'string'
            ? `REF:common_types.json#/$defs/${defName}|${propSchema.description}`
            : resolvedProtocol.description;
        return desc ? resolvedProtocol.describe(desc) : resolvedProtocol;
    }
    if (rootDoc && ref.startsWith('#/')) {
        const localTarget = resolveJsonPointer(rootDoc, ref);
        if (!localTarget) {
            return z.unknown().superRefine((_val, ctx) => {
                ctx.addIssue({
                    code: z.ZodIssueCode.custom,
                    message: `Unresolvable schema reference: '${ref}'`,
                });
            });
        }
        if (visitedPointers.has(ref)) {
            let cached = defCache.get(ref);
            return z.lazy(() => {
                if (!cached) {
                    cached =
                        defCache.get(ref) ??
                            convertPropertyToZod(localTarget, rootDoc, new Set([ref]), defCache);
                    defCache.set(ref, cached);
                }
                return cached;
            });
        }
        let zodType = defCache.get(ref);
        if (!zodType) {
            const nextVisited = new Set(visitedPointers);
            nextVisited.add(ref);
            zodType = convertPropertyToZod(localTarget, rootDoc, nextVisited, defCache);
            defCache.set(ref, zodType);
        }
        if (typeof propSchema.description === 'string') {
            zodType = zodType.describe(propSchema.description);
        }
        return zodType;
    }
    return undefined;
}
/**
 * Converts `oneOf` or `anyOf` JSON Schema unions into a Zod schema.
 *
 * Enforces mutual exclusivity for `oneOf` unions by verifying that valid values
 * match exactly one branch. Preserves metadata such as `default`, `description`,
 * and dynamic string annotations for enum/DataBinding unions.
 *
 * @param propSchema Schema containing `oneOf` or `anyOf` branches.
 * @param rootDoc Root schema document for resolving nested references.
 * @param visitedPointers Set of reference pointers currently on the resolution stack.
 * @param defCache Cache mapping reference strings to resolved Zod schemas.
 * @returns Converted Zod union schema, or undefined if no valid branches exist.
 */
function convertUnionToZod(propSchema, rootDoc, visitedPointers, defCache) {
    const isOneOf = Array.isArray(propSchema.oneOf);
    const rawBranches = (propSchema.oneOf || propSchema.anyOf);
    const branches = rawBranches.filter((b) => typeof b === 'object' && b !== null);
    if (branches.length === 0)
        return undefined;
    const enumBranch = branches.find(b => Array.isArray(b.enum));
    const hasBinding = branches.some(b => typeof b.$ref === 'string' && b.$ref.includes('DataBinding'));
    const zodBranches = branches.map(b => convertPropertyToZod(b, rootDoc, new Set(visitedPointers), defCache));
    let unionZod;
    if (zodBranches.length === 1) {
        unionZod = zodBranches[0];
    }
    else {
        const tuple = [zodBranches[0], zodBranches[1], ...zodBranches.slice(2)];
        unionZod = isOneOf ? exclusiveUnion(tuple) : z.union(tuple);
    }
    if (propSchema.default !== undefined) {
        unionZod = unionZod.default(propSchema.default);
    }
    const desc = (typeof propSchema.description === 'string' ? propSchema.description : undefined) ||
        (enumBranch && hasBinding ? 'REF:common_types.json#/$defs/DynamicString' : undefined);
    return desc ? unionZod.describe(desc) : unionZod;
}
/**
 * Converts an `allOf`-composed JSON Schema property or leaf `$defs` entry into a Zod schema.
 *
 * When all branches contribute object property definitions (inline or via `#/$defs/...`),
 * merges their properties and required sets into a single `z.object(...)` respecting
 * `additionalProperties` / `unevaluatedProperties`. Otherwise, intersects the converted
 * branch schemas with `.and(...)`.
 */
function convertAllOfPropertyToZod(propSchema, rootDoc, visitedPointers, defCache) {
    const rawBranches = propSchema.allOf;
    const branches = rawBranches.filter((b) => typeof b === 'object' && b !== null);
    if (branches.length === 0)
        return undefined;
    if (rootDoc) {
        const subSchemas = collectComponentSubSchemas(propSchema, rootDoc, new Set(visitedPointers), false);
        if (subSchemas.length > 0) {
            const requiredSet = new Set();
            for (const s of subSchemas) {
                if (s.kind === 'json' && Array.isArray(s.schema.required)) {
                    for (const r of s.schema.required) {
                        if (typeof r === 'string')
                            requiredSet.add(r);
                    }
                }
            }
            if (Array.isArray(propSchema.required)) {
                for (const r of propSchema.required) {
                    if (typeof r === 'string')
                        requiredSet.add(r);
                }
            }
            const shape = {};
            for (const s of subSchemas) {
                if (s.kind === 'zod') {
                    Object.assign(shape, s.properties);
                    continue;
                }
                const propShape = convertPropertiesToShape(s.schema.properties || {}, requiredSet, false, rootDoc, new Set(visitedPointers), defCache);
                Object.assign(shape, propShape);
            }
            const baseObj = z.object(shape);
            const forbidExtra = propSchema.additionalProperties === false ||
                propSchema.unevaluatedProperties === false ||
                subSchemas.some(s => s.kind === 'json' &&
                    (s.schema.additionalProperties === false || s.schema.unevaluatedProperties === false));
            const obj = closeObjectSchema(baseObj, [
                propSchema,
                ...subSchemas.flatMap(s => s.kind === 'json' && s.schema !== propSchema ? [s.schema] : []),
            ], forbidExtra, rootDoc, visitedPointers, defCache);
            return finalizePropertyZod(obj, propSchema, rootDoc, visitedPointers, defCache);
        }
    }
    const zodBranches = branches.map(b => convertPropertyToZod(b, rootDoc, new Set(visitedPointers), defCache));
    let intersected = zodBranches[0];
    for (let i = 1; i < zodBranches.length; i++) {
        intersected = intersected.and(zodBranches[i]);
    }
    return finalizePropertyZod(intersected, propSchema, rootDoc, visitedPointers, defCache);
}
/**
 * Converts a JSON Schema property definition into a runtime Zod schema.
 *
 * Handles `$ref` pointers, unions (`oneOf`, `anyOf`), enums, const values,
 * arrays with boundary constraints and uniqueness, strings with length and pattern
 * validations, numbers with minimum/maximum/multipleOf bounds, booleans, and nested
 * objects with property maps and additionalProperties constraints.
 *
 * @param propSchema Raw JSON Schema property definition.
 * @param rootDoc Optional root schema document for resolving references.
 * @param visitedPointers Set of reference pointers currently being resolved.
 * @param defCache Cache of resolved definition schemas to handle recursion and avoid duplicate work.
 * @returns Runtime Zod schema enforcing the declared JSON Schema constraints.
 */
function convertPropertyToZod(propSchema, rootDoc, visitedPointers = new Set(), defCache = new Map()) {
    if (!propSchema || typeof propSchema !== 'object') {
        return z.unknown();
    }
    if (propSchema instanceof z.ZodType) {
        return propSchema;
    }
    if (propSchema.$ref && typeof propSchema.$ref === 'string') {
        const resolvedRef = convertRefToZod(propSchema.$ref, propSchema, rootDoc, visitedPointers, defCache);
        if (resolvedRef)
            return resolvedRef;
    }
    // oneOf / anyOf inspection
    if (Array.isArray(propSchema.oneOf) || Array.isArray(propSchema.anyOf)) {
        const resolvedUnion = convertUnionToZod(propSchema, rootDoc, visitedPointers, defCache);
        if (resolvedUnion)
            return resolvedUnion;
    }
    // allOf inspection
    if (Array.isArray(propSchema.allOf) && propSchema.allOf.length > 0) {
        const resolvedAllOf = convertAllOfPropertyToZod(propSchema, rootDoc, visitedPointers, defCache);
        if (resolvedAllOf)
            return resolvedAllOf;
    }
    // Const literal
    if (propSchema.const !== undefined) {
        const constZod = z.literal(propSchema.const);
        return finalizePropertyZod(constZod, propSchema, rootDoc, visitedPointers, defCache);
    }
    // Enums
    if (Array.isArray(propSchema.enum) && propSchema.enum.length > 0) {
        const enumZod = convertEnumToZod(propSchema.enum);
        return finalizePropertyZod(enumZod, propSchema, rootDoc, visitedPointers, defCache);
    }
    // Arrays
    if (propSchema.type === 'array') {
        const itemSchema = propSchema.items && typeof propSchema.items === 'object'
            ? convertPropertyToZod(propSchema.items, rootDoc, new Set(visitedPointers), defCache)
            : z.unknown();
        let arr = z.array(itemSchema);
        if (typeof propSchema.minItems === 'number') {
            arr = arr.min(propSchema.minItems);
        }
        if (typeof propSchema.maxItems === 'number') {
            arr = arr.max(propSchema.maxItems);
        }
        if (propSchema.uniqueItems === true) {
            arr = arr.refine((items) => new Set(items.map(canonicalJsonStringify)).size === items.length, { message: 'Array items must be unique' });
        }
        return finalizePropertyZod(arr, propSchema, rootDoc, visitedPointers, defCache);
    }
    // Primitives
    switch (propSchema.type) {
        case 'string': {
            let s = z.string();
            if (typeof propSchema.minLength === 'number') {
                s = s.min(propSchema.minLength);
            }
            if (typeof propSchema.maxLength === 'number') {
                s = s.max(propSchema.maxLength);
            }
            if (typeof propSchema.pattern === 'string') {
                try {
                    s = s.regex(new RegExp(propSchema.pattern, 'u'));
                }
                catch {
                    // ignore regex compilation failure
                }
            }
            return finalizePropertyZod(s, propSchema, rootDoc, visitedPointers, defCache);
        }
        case 'integer':
        case 'number': {
            let n = propSchema.type === 'integer' ? z.number().int() : z.number();
            if (typeof propSchema.minimum === 'number') {
                n = n.min(propSchema.minimum);
            }
            if (typeof propSchema.maximum === 'number') {
                n = n.max(propSchema.maximum);
            }
            if (typeof propSchema.exclusiveMinimum === 'number') {
                n = n.gt(propSchema.exclusiveMinimum);
            }
            if (typeof propSchema.exclusiveMaximum === 'number') {
                n = n.lt(propSchema.exclusiveMaximum);
            }
            if (typeof propSchema.multipleOf === 'number') {
                n = n.multipleOf(propSchema.multipleOf);
            }
            return finalizePropertyZod(n, propSchema, rootDoc, visitedPointers, defCache);
        }
        case 'boolean': {
            return finalizePropertyZod(z.boolean(), propSchema, rootDoc, visitedPointers, defCache);
        }
        case 'object': {
            // An inline object that declares its properties is converted structurally
            // rather than collapsed to an opaque record. Without this, a child
            // reference nested inside an array item is invisible to the reference map,
            // so the component graph would look as if it had no children there.
            const props = propSchema.properties;
            const hasPatterns = typeof propSchema.patternProperties === 'object' && propSchema.patternProperties !== null;
            let obj;
            if ((typeof props === 'object' && props !== null) || hasPatterns) {
                const required = Array.isArray(propSchema.required)
                    ? new Set(propSchema.required.filter((r) => typeof r === 'string'))
                    : new Set();
                const baseObj = z.object(convertPropertiesToShape((props ?? {}), required, false, rootDoc, visitedPointers, defCache));
                const forbidExtra = propSchema.additionalProperties === false || propSchema.unevaluatedProperties === false;
                obj = closeObjectSchema(baseObj, [propSchema], forbidExtra, rootDoc, visitedPointers, defCache);
            }
            else {
                obj = z.record(z.unknown());
            }
            return finalizePropertyZod(obj, propSchema, rootDoc, visitedPointers, defCache);
        }
        default: {
            return finalizePropertyZod(z.unknown(), propSchema, rootDoc, visitedPointers, defCache);
        }
    }
}
/**
 * Whether a property name is one of the component envelope fields (`id`,
 * `component`, `@catalogId`), which route a component rather than configure it.
 * The validation schema leaves them out of a component for the same reason, and
 * `PayloadValidator` strips them before parsing a component.
 *
 * @param propName Property name to check.
 * @returns True if the property belongs to the envelope rather than the component.
 */
function isEnvelopeField(propName) {
    // A bare `catalogId` a component declares is its own property: below v1.0
    // the protocol has no per-component catalog, and from v1.0 the envelope
    // field is `@catalogId`.
    return propName === 'id' || propName === 'component' || propName === '@catalogId';
}
/**
 * Whether a `properties` block declares `catalogId` or `metadata` as part of
 * an inlined `ComponentCommon`, as flattened validation schemas do: beside
 * `id`, and with the standard shape (a string `catalogId`, or a `metadata`
 * object whose only property is `extensions`). Such a property is the
 * standard mixin rather than a custom property of the same name.
 *
 * @param properties The `properties` block that declares the property.
 * @param propName The property's name.
 * @param propSchema The property's JSON Schema.
 * @returns Whether the property is the inlined standard mixin.
 */
function isInlineStandardMixinProperty(properties, propName, propSchema) {
    if (!Object.hasOwn(properties, 'id') || !isPlainObject(propSchema))
        return false;
    switch (propName) {
        case 'catalogId':
            return propSchema.type === 'string';
        case 'metadata': {
            const metadataProps = propSchema.properties;
            if (propSchema.type !== 'object' || !isPlainObject(metadataProps))
                return false;
            const keys = Object.keys(metadataProps);
            return keys.length === 1 && keys[0] === 'extensions';
        }
        default:
            return false;
    }
}
/**
 * Converts a dictionary of property definitions into a Zod raw shape map.
 *
 * Marks fields as optional unless present in `requiredSet`.
 *
 * @param properties Property name to property schema mapping.
 * @param requiredSet Set of required property names.
 * @param omitEnvelopeFields Whether to omit component envelope fields (`id`, `component`, `@catalogId`).
 * @param rootDoc Optional root schema document for reference resolution.
 * @param visitedPointers Set of reference pointers currently on the resolution stack.
 * @param defCache Cache mapping reference strings to resolved Zod schemas.
 * @returns Map of property names to Zod schemas representing the shape.
 */
function convertPropertiesToShape(properties, requiredSet, omitEnvelopeFields = false, rootDoc, visitedPointers, defCache = new Map()) {
    const shape = {};
    for (const [propName, propSchema] of Object.entries(properties)) {
        if (omitEnvelopeFields && isEnvelopeField(propName)) {
            continue;
        }
        const zodField = convertPropertyToZod(typeof propSchema === 'object' && propSchema !== null
            ? propSchema
            : {}, rootDoc, visitedPointers ? new Set(visitedPointers) : new Set(), defCache);
        if (!requiredSet.has(propName)) {
            // A property with a `default` already accepts a missing value, and
            // `optional()` would skip the default. Leaving it unwrapped applies the
            // default on parse, as a `.default()` in a catalog defined in code does.
            shape[propName] = zodField instanceof z.ZodDefault ? zodField : zodField.optional();
            continue;
        }
        if (zodField.safeParse(undefined).success) {
            // A required property must be present. A schema that accepts any value,
            // such as `{}`, also accepts a missing key, and a `default` would stand
            // in for one, so a missing key is rejected before either applies.
            shape[propName] = z.preprocess((value, ctx) => {
                if (value === undefined) {
                    ctx.addIssue({ code: z.ZodIssueCode.custom, message: 'Required' });
                }
                return value;
            }, zodField);
        }
        else {
            shape[propName] = zodField;
        }
    }
    for (const [propName, propSchema] of Object.entries(properties)) {
        if (Object.hasOwn(shape, propName) &&
            isInlineStandardMixinProperty(properties, propName, propSchema)) {
            markStandardMixinSchema(shape[propName]);
        }
    }
    return shape;
}
/**
 * Closes or opens a converted object schema, honoring the `patternProperties`
 * of the JSON Schema pieces it was built from.
 *
 * Without `patternProperties` this is `.strict()` or `.passthrough()`. With
 * them, a key the object doesn't declare is checked against the schema of
 * every pattern it matches, and when `forbidExtra` is set, a key that matches
 * no pattern is rejected, as `additionalProperties: false` rejects it.
 *
 * @param obj The object schema of the declared properties.
 * @param pieces The JSON Schema pieces whose `patternProperties` apply.
 * @param forbidExtra Whether keys that are neither declared nor matched are rejected.
 * @param rootDoc Optional root schema document for reference resolution.
 * @param visitedPointers Set of reference pointers currently on the resolution stack.
 * @param defCache Cache mapping reference strings to resolved Zod schemas.
 * @returns The object schema, wrapped in a refinement when patterns apply.
 */
function closeObjectSchema(obj, pieces, forbidExtra, rootDoc, visitedPointers, defCache = new Map()) {
    const patterns = [];
    for (const piece of new Set(pieces)) {
        const raw = piece.patternProperties;
        if (!raw || typeof raw !== 'object' || Array.isArray(raw))
            continue;
        for (const [pattern, patternSchema] of Object.entries(raw)) {
            let regex;
            try {
                regex = new RegExp(pattern, 'u');
            }
            catch {
                continue;
            }
            patterns.push({
                regex,
                schema: convertPropertyToZod(typeof patternSchema === 'object' && patternSchema !== null
                    ? patternSchema
                    : {}, rootDoc, visitedPointers ? new Set(visitedPointers) : new Set(), defCache),
            });
        }
    }
    if (patterns.length === 0) {
        return forbidExtra ? obj.strict() : obj.passthrough();
    }
    const declared = new Set(Object.keys(obj.shape));
    return obj.passthrough().superRefine((value, ctx) => {
        const unrecognized = [];
        for (const [key, entry] of Object.entries(value)) {
            if (declared.has(key))
                continue;
            let matched = false;
            for (const { regex, schema } of patterns) {
                if (!regex.test(key))
                    continue;
                matched = true;
                const result = schema.safeParse(entry);
                if (!result.success) {
                    for (const issue of result.error.issues) {
                        ctx.addIssue({
                            code: z.ZodIssueCode.custom,
                            message: issue.message,
                            path: [key, ...issue.path],
                        });
                    }
                }
            }
            if (!matched && forbidExtra)
                unrecognized.push(key);
        }
        if (unrecognized.length > 0) {
            ctx.addIssue({ code: z.ZodIssueCode.unrecognized_keys, keys: unrecognized });
        }
    });
}
/**
 * Returns the `ComponentCommon` properties a component schema that composes
 * `common_types.json#/$defs/ComponentCommon` inherits, marked as standard
 * mixin properties.
 *
 * The component's `id` and catalog are envelope fields rather than
 * properties, and below v1.0 `metadata` is not part of the protocol.
 *
 * @param isAtLeastV10 Whether the catalog targets protocol v1.0 or higher.
 * @returns The inherited property schemas, keyed by their wire names.
 */
function componentCommonMixinProperties(isAtLeastV10) {
    const properties = {};
    for (const [key, schema] of Object.entries(ComponentCommonSchema.shape)) {
        if (!isAtLeastV10 && key.startsWith('@'))
            continue;
        const bareKey = key.replace(/^@/, '');
        if (bareKey === 'id' || bareKey === 'catalogId')
            continue;
        if (bareKey === 'metadata' && !isAtLeastV10)
            continue;
        properties[key] = markStandardMixinSchema(schema);
    }
    return properties;
}
/**
 * Collects all property definitions and constraints from a component schema.
 *
 * Resolves local document `$defs` and canonical protocol references, including
 * external `common_types.json` mixins such as `Checkable`.
 *
 * The pieces are ordered from the most generic to the most specific, so that a
 * later piece overrides a property an earlier one declares: the standard
 * mixins first, then the local definitions the schema references, then its
 * inline `allOf` members, and the schema's own `properties` last. A component
 * that narrows a property it inherits keeps its narrowed schema, and the mixin
 * properties stay first in key order.
 *
 * @param schema Component schema definition.
 * @param rootDoc Root schema document containing definition targets.
 * @param visitedPointers Set of reference pointers currently being resolved to prevent cycles.
 * @param isAtLeastV10 Whether the catalog targets protocol v1.0 or higher.
 * @returns The pieces gathered from the schema and its `allOf` hierarchy, as JSON Schema
 *     fragments or zod mirrors of canonical types, least specific first.
 */
function collectComponentSubSchemas(schema, rootDoc, visitedPointers = new Set(), isAtLeastV10 = false) {
    if (!schema || typeof schema !== 'object')
        return [];
    const mixins = [];
    const local = [];
    const inline = [];
    if (Array.isArray(schema.allOf)) {
        for (const sub of schema.allOf) {
            if (!sub || typeof sub !== 'object')
                continue;
            if (typeof sub.$ref === 'string') {
                const ref = sub.$ref;
                if (ref.includes('common_types.json') && ref.includes('ComponentCommon')) {
                    // Protocol common properties: accessibility attributes, and from
                    // v1.0 also the component's metadata, under their bare or
                    // `@`-prefixed names. `catalogId` is an envelope field, like `id`.
                    mixins.push({ kind: 'zod', properties: componentCommonMixinProperties(isAtLeastV10) });
                }
                else if (ref.startsWith('#/')) {
                    if (!visitedPointers.has(ref)) {
                        visitedPointers.add(ref);
                        const target = resolveJsonPointer(rootDoc, ref);
                        if (target) {
                            local.push(...collectComponentSubSchemas(target, rootDoc, visitedPointers, isAtLeastV10));
                        }
                    }
                }
                else {
                    // Any other external reference, such as common_types.json#/$defs/Checkable.
                    // The referenced document is not loaded here, so fall back to the zod mirror of
                    // the canonical type. Without this the mixin is dropped with no error, which is
                    // how `checks` used to disappear from every Checkable component.
                    const mirror = resolveProtocolRef(ref);
                    if (mirror instanceof z.ZodObject) {
                        const properties = {};
                        for (const [key, prop] of Object.entries(mirror.shape)) {
                            if (!isAtLeastV10 && key.startsWith('@'))
                                continue;
                            properties[key] = markStandardMixinSchema(prop);
                        }
                        mixins.push({ kind: 'zod', properties });
                    }
                }
            }
            else {
                inline.push(...collectComponentSubSchemas(sub, rootDoc, visitedPointers, isAtLeastV10));
            }
        }
    }
    const result = [...mixins, ...local, ...inline];
    if (schema.properties) {
        result.push({ kind: 'json', schema });
    }
    return result;
}
/**
 * Converts a raw component JSON schema definition into a Zod object schema.
 *
 * Merges sub-schemas from `allOf` compositions, applies required fields, and
 * respects `additionalProperties` and `unevaluatedProperties` constraints.
 *
 * @param rawSchema Raw component schema definition.
 * @param rootDoc Root schema document for resolving references.
 * @param omitEnvelopeFields Whether to omit envelope fields (`id`, `component`, `@catalogId`). Defaults to true.
 * @param defCache Cache mapping reference strings to resolved Zod schemas.
 * @param isAtLeastV10 Whether the catalog targets protocol v1.0 or higher.
 * @returns Zod object schema validating component properties.
 */
function convertComponentJsonSchemaToZod(rawSchema, rootDoc, omitEnvelopeFields = true, defCache = new Map(), isAtLeastV10 = false) {
    const shape = {};
    const schemasToMerge = collectComponentSubSchemas(rawSchema, rootDoc, undefined, isAtLeastV10);
    const requiredSet = new Set();
    for (const s of schemasToMerge) {
        if (s.kind === 'json' && Array.isArray(s.schema.required)) {
            s.schema.required.forEach((r) => {
                if (typeof r === 'string')
                    requiredSet.add(r);
            });
        }
    }
    for (const s of schemasToMerge) {
        if (s.kind === 'zod') {
            for (const [propName, propSchema] of Object.entries(s.properties)) {
                if (omitEnvelopeFields && isEnvelopeField(propName)) {
                    continue;
                }
                shape[propName] = propSchema;
            }
            continue;
        }
        const propShape = convertPropertiesToShape(s.schema.properties || {}, requiredSet, omitEnvelopeFields, rootDoc, undefined, defCache);
        Object.assign(shape, propShape);
    }
    const obj = z.object(shape);
    const allowExtra = rawSchema.unevaluatedProperties === true ||
        (typeof rawSchema.unevaluatedProperties === 'object' &&
            rawSchema.unevaluatedProperties !== null) ||
        rawSchema.additionalProperties === true ||
        (typeof rawSchema.additionalProperties === 'object' && rawSchema.additionalProperties !== null);
    return allowExtra ? obj.passthrough() : obj.strict();
}
/**
 * Checks whether an object schema represents a shorthand parameter map (a map
 * of parameter names to subschemas), rather than a full JSON Schema object or
 * reference combinator.
 */
export function isShorthandParameterMap(schema) {
    if (!schema || typeof schema !== 'object' || Array.isArray(schema)) {
        return false;
    }
    const s = schema;
    return (Object.keys(s).length > 0 &&
        s.properties === undefined &&
        typeof s.type !== 'string' &&
        !('$ref' in s) &&
        !('allOf' in s) &&
        !('oneOf' in s) &&
        !('anyOf' in s) &&
        !('not' in s) &&
        Object.values(s).every(v => v !== null && (typeof v === 'object' || typeof v === 'boolean')));
}
/**
 * Checks whether an object schema explicitly permits additional or unevaluated properties.
 */
function isExplicitlyOpen(schema) {
    return (schema.unevaluatedProperties === true ||
        (typeof schema.unevaluatedProperties === 'object' && schema.unevaluatedProperties !== null) ||
        schema.additionalProperties === true ||
        (typeof schema.additionalProperties === 'object' && schema.additionalProperties !== null));
}
/**
 * Collects sub-schemas and references for function argument definitions.
 *
 * Resolves local document pointers (`#/`), recurses into `allOf` compositions,
 * and detects unresolvable references or open combiners (`oneOf`, `anyOf`).
 */
function collectArgSubSchemas(schema, rootDoc, visited = new Set()) {
    const result = {
        schemas: [],
        hasUnresolvable: false,
    };
    if (!schema || typeof schema !== 'object' || Array.isArray(schema)) {
        return result;
    }
    if (isShorthandParameterMap(schema)) {
        result.schemas.push({
            type: 'object',
            properties: schema,
        });
        return result;
    }
    if (typeof schema.$ref === 'string') {
        const ref = schema.$ref;
        if (ref.startsWith('#/')) {
            if (!rootDoc) {
                result.hasUnresolvable = true;
            }
            else if (!visited.has(ref)) {
                visited.add(ref);
                const target = resolveJsonPointer(rootDoc, ref);
                if (target) {
                    const sub = collectArgSubSchemas(target, rootDoc, visited);
                    result.schemas.push(...sub.schemas);
                    if (sub.hasUnresolvable) {
                        result.hasUnresolvable = true;
                    }
                }
                else {
                    result.hasUnresolvable = true;
                }
            }
        }
        else {
            result.hasUnresolvable = true;
        }
    }
    if (Array.isArray(schema.allOf)) {
        for (const sub of schema.allOf) {
            if (sub && typeof sub === 'object' && !Array.isArray(sub)) {
                const subResult = collectArgSubSchemas(sub, rootDoc, visited);
                result.schemas.push(...subResult.schemas);
                if (subResult.hasUnresolvable) {
                    result.hasUnresolvable = true;
                }
            }
        }
    }
    if (Array.isArray(schema.anyOf) || Array.isArray(schema.oneOf)) {
        result.hasUnresolvable = true;
    }
    if (schema.properties ||
        schema.required ||
        schema.patternProperties ||
        schema.additionalProperties !== undefined ||
        schema.unevaluatedProperties !== undefined) {
        result.schemas.push(schema);
    }
    return result;
}
/**
 * Converts a function argument JSON schema definition into a Zod object schema.
 *
 * Maps function argument schemas to object properties, requiring fields listed in
 * `required` and applying strictness or passthrough based on `additionalProperties`,
 * `patternProperties` and reference resolution.
 *
 * @param rawSchema Raw function arguments schema.
 * @param rootDoc Optional root schema document for reference resolution.
 * @param defCache Cache mapping reference strings to resolved Zod schemas.
 * @returns Zod object schema validating function arguments, wrapped in a
 *     refinement when `patternProperties` apply.
 */
export function convertFunctionArgsJsonSchemaToZod(rawSchema, rootDoc, defCache = new Map()) {
    const collected = collectArgSubSchemas(rawSchema, rootDoc);
    const requiredSet = new Set();
    for (const s of collected.schemas) {
        if (Array.isArray(s.required)) {
            for (const r of s.required) {
                if (typeof r === 'string') {
                    requiredSet.add(r);
                }
            }
        }
    }
    const shape = {};
    for (const s of collected.schemas) {
        if (s.properties && typeof s.properties === 'object' && !Array.isArray(s.properties)) {
            const propShape = convertPropertiesToShape(s.properties, requiredSet, false, rootDoc, undefined, defCache);
            Object.assign(shape, propShape);
        }
    }
    const obj = z.object(shape);
    const allowExtra = collected.hasUnresolvable ||
        collected.schemas.some(isExplicitlyOpen) ||
        isExplicitlyOpen(rawSchema);
    return closeObjectSchema(obj, [rawSchema, ...collected.schemas.filter(s => s !== rawSchema)], !allowExtra, rootDoc, undefined, defCache);
}
/**
 * Whether a value is a Zod schema. Checked structurally so schemas built with
 * another copy of Zod are recognized.
 */
export function isZodSchema(value) {
    return (typeof value === 'object' &&
        value !== null &&
        typeof value.safeParse === 'function');
}
/**
 * Collects every object property key a Zod schema declares.
 *
 * Unlike `getKnownSchemaKeys`, which answers which keys an object may have, it
 * also collects the keys of an open (`.passthrough()`) object, and of every
 * branch of a union. It traverses `ZodEffects`, `ZodOptional`, `ZodNullable`,
 * `ZodDefault`, `ZodCatch`, `ZodIntersection`, `ZodUnion`,
 * `ZodDiscriminatedUnion`, `ZodPipeline`, `ZodReadonly` and `ZodBranded`.
 *
 * @param schema Zod schema to inspect.
 * @returns The declared property names; empty when the schema declares none.
 */
export function getDeclaredSchemaKeys(schema) {
    const keys = new Set();
    const visit = (node) => {
        const def = node?._def;
        switch (def?.typeName) {
            case 'ZodObject': {
                const shape = typeof node.shape === 'function' ? node.shape() : node.shape;
                if (shape && typeof shape === 'object') {
                    for (const key of Object.keys(shape))
                        keys.add(key);
                }
                return;
            }
            case 'ZodEffects':
                visit(def.schema);
                return;
            case 'ZodOptional':
            case 'ZodNullable':
            case 'ZodDefault':
            case 'ZodCatch':
            case 'ZodReadonly':
                visit(def.innerType);
                return;
            case 'ZodBranded':
                visit(def.type);
                return;
            case 'ZodPipeline':
                visit(def.in);
                visit(def.out);
                return;
            case 'ZodIntersection':
                visit(def.left);
                visit(def.right);
                return;
            case 'ZodUnion':
            case 'ZodDiscriminatedUnion':
                for (const option of def.options)
                    visit(option);
                return;
            default:
                return;
        }
    };
    visit(schema);
    return keys;
}
/**
 * Extracts declared parameter names from a function's argument schema,
 * including those of `allOf`, `anyOf` and `oneOf` members and `$ref` targets.
 */
export function functionParameterNames(schema, rootDoc) {
    if (!schema || typeof schema !== 'object' || Array.isArray(schema)) {
        return [];
    }
    const s = schema;
    const names = [];
    const visited = new Set();
    const extractProperties = (node) => {
        if (!node || typeof node !== 'object' || Array.isArray(node))
            return;
        const n = node;
        if (typeof n.$ref === 'string' && rootDoc && n.$ref.startsWith('#/')) {
            if (!visited.has(n.$ref)) {
                visited.add(n.$ref);
                const target = resolveJsonPointer(rootDoc, n.$ref);
                if (target) {
                    extractProperties(target);
                }
            }
        }
        if (n.properties &&
            typeof n.properties === 'object' &&
            n.properties !== null &&
            !Array.isArray(n.properties)) {
            names.push(...Object.keys(n.properties));
        }
        for (const combinator of [n.allOf, n.anyOf, n.oneOf]) {
            if (Array.isArray(combinator)) {
                for (const member of combinator) {
                    extractProperties(member);
                }
            }
        }
    };
    if ((s.properties &&
        typeof s.properties === 'object' &&
        s.properties !== null &&
        !Array.isArray(s.properties)) ||
        Array.isArray(s.allOf) ||
        Array.isArray(s.anyOf) ||
        Array.isArray(s.oneOf) ||
        typeof s.$ref === 'string') {
        extractProperties(s);
        return names;
    }
    if (isShorthandParameterMap(s)) {
        return Object.keys(s);
    }
    return [];
}
/**
 * Parses raw catalog function definitions into typed FunctionApi objects.
 *
 * Validates UAX #31 identifier requirements when targeting protocol v1.0 or higher,
 * filters against permitted function names, and converts parameter schemas to Zod validators.
 *
 * @param rawFunctions Raw function definitions from the catalog schema (array or dictionary).
 * @param rootDoc Optional root schema document for reference resolution.
 * @param permittedNames Optional set of allowed function names from `anyFunction.oneOf`.
 * @param atLeastV10 Whether the catalog targets protocol v1.0 or higher.
 * @returns Array of parsed FunctionApi objects.
 * @throws {A2uiCatalogError} If a function or argument identifier fails UAX #31 validation in v1.0+.
 */
function parseFunctionDefinitions(rawFunctions, rootDoc, permittedNames, atLeastV10 = false) {
    const result = [];
    if (!rawFunctions)
        return result;
    const defCache = new Map();
    /** Validates a function's own name and its declared argument names. */
    const assertFunctionIdentifiers = (name, paramNames) => {
        if (!atLeastV10)
            return;
        assertUax31Identifier(name, `function identifier: '${name}'`);
        for (const argName of paramNames) {
            assertUax31Identifier(argName, `argument identifier: '${argName}' in function '${name}'`);
        }
    };
    /**
     * Rejects requiresUserActivation=true with callers other than rendererOnly.
     * The rule exists only in the v1.0 catalog_definition.json.
     */
    const assertUserActivationCallers = (entry) => {
        if (!atLeastV10)
            return;
        if (entry.requiresUserActivation === true &&
            entry.allowedCallers !== undefined &&
            entry.allowedCallers !== 'rendererOnly') {
            throw new A2uiCatalogError(`Function '${entry.name}' declares requiresUserActivation=true with allowedCallers='${entry.allowedCallers}'; requiresUserActivation=true requires allowedCallers='rendererOnly'.`);
        }
    };
    if (Array.isArray(rawFunctions)) {
        for (const fn of rawFunctions) {
            if (fn && typeof fn === 'object' && typeof fn.name === 'string') {
                const paramNames = functionParameterNames(fn.parameters, rootDoc);
                assertFunctionIdentifiers(fn.name, paramNames);
                const entry = new JsonFunctionApi(fn.name, fn, definition => definition['parameters'] && typeof definition['parameters'] === 'object'
                    ? convertFunctionArgsJsonSchemaToZod(definition['parameters'], rootDoc, defCache)
                    : z.record(z.unknown()));
                assertUserActivationCallers(entry);
                if (permittedNames && !permittedNames.has(fn.name)) {
                    continue;
                }
                result.push(entry);
            }
        }
        return result;
    }
    if (typeof rawFunctions === 'object' && rawFunctions !== null) {
        for (const [name, defn] of Object.entries(rawFunctions)) {
            const rawDefn = defn && typeof defn === 'object' ? defn : {};
            const argsSchema = functionArgsSchema(rawDefn);
            const paramNames = functionParameterNames(argsSchema, rootDoc);
            assertFunctionIdentifiers(name, paramNames);
            if (!defn || typeof defn !== 'object')
                continue;
            const entry = new JsonFunctionApi(name, defn, definition => {
                const argsSchema = functionArgsSchema(definition);
                return argsSchema
                    ? convertFunctionArgsJsonSchemaToZod(argsSchema, rootDoc, defCache)
                    : z.record(z.unknown());
            });
            assertUserActivationCallers(entry);
            if (permittedNames && !permittedNames.has(name)) {
                continue;
            }
            result.push(entry);
        }
    }
    return result;
}
/**
 * Returns the schema of the arguments of a function a `functions` map
 * defines: its call schema's `args`, a bare map of argument schemas with the
 * object keywords beside it, or, for a definition that is not a call schema,
 * the definition itself.
 *
 * @param d The function's definition.
 */
function functionArgsSchema(d) {
    let props = d.properties &&
        typeof d.properties === 'object' &&
        d.properties !== null &&
        !Array.isArray(d.properties)
        ? d.properties
        : undefined;
    if (!props?.args && Array.isArray(d.allOf)) {
        for (const member of d.allOf) {
            if (member &&
                typeof member === 'object' &&
                !Array.isArray(member) &&
                member.properties &&
                typeof member.properties === 'object' &&
                member.properties !== null &&
                !Array.isArray(member.properties)) {
                props = {
                    ...props,
                    ...member.properties,
                };
            }
        }
    }
    let argsSchema = props?.args ?? d.args ?? d.parameters;
    if (!argsSchema && props && !('call' in props) && !('@call' in props) && !('function' in props)) {
        argsSchema = d;
    }
    else if (isShorthandParameterMap(argsSchema)) {
        argsSchema = {
            type: 'object',
            properties: argsSchema,
            required: d.required,
            additionalProperties: d.additionalProperties,
        };
    }
    return argsSchema && typeof argsSchema === 'object' && !Array.isArray(argsSchema)
        ? argsSchema
        : undefined;
}
/**
 * Extracts permitted definition names matching a reference prefix from a `oneOf` array.
 *
 * @param oneOf Array of reference schema objects from `anyComponent` or `anyFunction`.
 * @param prefix Prefix to match and strip, such as `#/components/` or `#/functions/`.
 * @returns Set of unescaped allowed names, or undefined if `oneOf` is not an array.
 */
function extractPermittedNames(oneOf, prefix) {
    if (!Array.isArray(oneOf))
        return undefined;
    const permitted = new Set();
    for (const item of oneOf) {
        if (typeof item?.$ref === 'string' && item.$ref.startsWith(prefix)) {
            const rawName = item.$ref.slice(prefix.length);
            const unescapedName = rawName.replace(/~([01])/g, (_, p1) => p1 === '1' ? '/' : '~');
            permitted.add(unescapedName);
        }
    }
    return permitted;
}
/**
 * Parses raw catalog component schemas into typed ComponentApi definitions.
 *
 * Validates UAX #31 identifier requirements for v1.0+ specifications, filters
 * components if permitted names are specified, and transforms JSON schemas into
 * runtime Zod schemas.
 *
 * @param componentsMap Mapping of component name to raw component schema definition.
 * @param catalogSchema Enclosing raw catalog schema for resolving local references.
 * @param atLeastV10 Whether the catalog targets protocol v1.0 or higher.
 * @param permittedNames Optional set of allowed component names from anyComponent.oneOf.
 * @returns Array of parsed ComponentApi objects with validation schemas and hierarchy constraints.
 * @throws {A2uiCatalogError} If a component or property identifier fails UAX #31 validation in v1.0+.
 */
function parseCatalogComponents(componentsMap, catalogSchema, atLeastV10, permittedNames) {
    const components = [];
    const defCache = new Map();
    for (const [name, rawCompSchema] of Object.entries(componentsMap)) {
        const rawComp = rawCompSchema || {};
        if (atLeastV10) {
            assertUax31Identifier(name, `component identifier: '${name}'`);
            const props = rawComp.properties;
            if (props && typeof props === 'object') {
                for (const propName of Object.keys(props)) {
                    assertUax31Identifier(propName, `property identifier: '${propName}' in component '${name}'`);
                }
            }
            const rawMeta = rawComp.metadata;
            if (rawMeta !== undefined) {
                try {
                    validateMetadata(rawMeta);
                }
                catch (err) {
                    throw new A2uiCatalogError(err instanceof Error ? err.message : String(err));
                }
            }
        }
        if (permittedNames && !permittedNames.has(name)) {
            continue;
        }
        components.push(new JsonComponentApi(name, rawComp, definition => convertComponentJsonSchemaToZod(definition, catalogSchema, true, defCache, atLeastV10)));
    }
    return components;
}
/**
 * Extracts and compiles the theme schema from a catalog definition if present.
 *
 * Checks top-level theme, themeSchema, styles, and $defs.theme definitions.
 *
 * @param catalogSchema Raw catalog schema or capabilities definition object.
 * @param defs Optional $defs mapping from the root schema.
 * @returns Compiled Zod object schema for theme tokens, or undefined if not declared.
 */
function parseThemeSchema(catalogSchema, defs) {
    const rawTheme = catalogSchema.theme ??
        catalogSchema.themeSchema ??
        catalogSchema.styles ??
        defs?.theme;
    if (rawTheme && typeof rawTheme === 'object') {
        const rawThemeObj = rawTheme;
        const normalizedThemeSchema = 'properties' in rawThemeObj || 'allOf' in rawThemeObj || rawThemeObj.type === 'object'
            ? rawThemeObj
            : { type: 'object', properties: rawThemeObj };
        const themeZod = convertComponentJsonSchemaToZod(normalizedThemeSchema, catalogSchema, false);
        // Unlike a component, a theme is open unless its author closes it, as JSON
        // Schema itself defaults.
        const closed = normalizedThemeSchema.additionalProperties === false ||
            normalizedThemeSchema.unevaluatedProperties === false;
        return closed ? themeZod : themeZod.passthrough();
    }
    return undefined;
}
/**
 * Whether a v1.0 catalog may use `ref` as a `$ref` target.
 *
 * A v1.0 catalog may reference its own document, through a local reference
 * (`#/...`) or the `catalog.json` envelope placeholder, and `common_types.json`,
 * by a relative or absolute URI.
 *
 * @param ref The `$ref` value.
 * @returns Whether the reference is allowed.
 */
function isSupportedV10Ref(ref) {
    if (ref.startsWith('#'))
        return true;
    const hashIndex = ref.indexOf('#');
    const documentPart = hashIndex === -1 ? ref : ref.slice(0, hashIndex);
    if (documentPart === 'catalog.json')
        return true;
    return documentPart.split('/').pop() === 'common_types.json';
}
/**
 * Escapes a key as an RFC 6901 JSON Pointer reference token.
 */
function escapeJsonPointerToken(token) {
    return token.replace(/~/g, '~0').replace(/\//g, '~1');
}
/**
 * Checks that every `$ref` of a v1.0 catalog document targets the document
 * itself or `common_types.json`.
 *
 * Walks the whole document, including components, functions and `$defs`.
 * References are only inspected, never resolved or fetched.
 *
 * @param node The document, or a value nested in it.
 * @param pointer JSON Pointer of `node` within the document.
 * @throws {A2uiCatalogError} If a `$ref` targets any other document, such as
 *   another catalog.
 */
function assertSupportedV10Refs(node, pointer) {
    if (Array.isArray(node)) {
        node.forEach((item, index) => assertSupportedV10Refs(item, `${pointer}/${index}`));
        return;
    }
    if (!isPlainObject(node))
        return;
    for (const [key, value] of Object.entries(node)) {
        const childPointer = `${pointer}/${escapeJsonPointerToken(key)}`;
        if (key === '$ref' && typeof value === 'string' && !isSupportedV10Ref(value)) {
            throw new A2uiCatalogError(`Unsupported external $ref '${value}' at ${childPointer}: a v1.0 catalog may only ` +
                'reference its own components and functions (#/...) or common_types.json.');
        }
        assertSupportedV10Refs(value, childPointer);
    }
}
/**
 * Parses a raw A2UI catalog schema into its typed component, function, and metadata fields.
 *
 * Parses component and function definitions, extracts hierarchy constraints (`allowedParents`,
 * `allowedChildren`), unescapes RFC 6901 JSON pointers, and builds runtime Zod validators.
 *
 * @param inputSchema Raw catalog schema or capabilities definition object. It
 *   is copied first and never referenced afterwards.
 * @param protocolVersion Protocol version of the catalog. When given, it takes
 *   precedence over the `protocolVersion` the schema declares and selects the
 *   version's loading rules; the declared version is still kept as written.
 *   Catalog schemas published before v1.0 omit `protocolVersion`; when
 *   neither the caller nor the schema supplies it, `DEFAULT_PROTOCOL_VERSION`
 *   applies.
 * @param catalogIdOverride Catalog ID to use instead of the one the schema
 *   declares. The schema itself is kept as written.
 * @returns Parsed catalog fields ready to construct a `Catalog` instance.
 * @throws {Error} If the catalog ID is missing or not a string.
 * @throws {A2uiCatalogError} If a v1.0+ catalog has a `$ref` to a document
 *   other than itself or `common_types.json`, such as another catalog.
 */
export function parseCatalogSchema(inputSchema, protocolVersion, catalogIdOverride) {
    // Everything the catalog keeps, including what the Zod schemas close over,
    // comes from this copy, so mutating the input afterwards cannot change it.
    const catalogSchema = deepCopyJson(inputSchema);
    const catalogId = catalogIdOverride ?? catalogSchema.catalogId ?? catalogSchema.$id ?? catalogSchema.id;
    if (!catalogId || typeof catalogId !== 'string') {
        throw new Error("Catalog ID must be specified via catalog metadata ('catalogId' or '$id').");
    }
    // Filter permitted components via anyComponent.oneOf if declared
    const defs = catalogSchema.$defs;
    const anyComp = defs?.anyComponent;
    const permittedNames = extractPermittedNames(anyComp?.oneOf, '#/components/');
    const resolvedVersion = protocolVersion ??
        catalogSchema.protocolVersion ??
        DEFAULT_PROTOCOL_VERSION;
    const atLeastV10 = isAtLeastVersion(resolvedVersion, '1.0');
    if (atLeastV10) {
        // Before anything reads the entries, so no unsupported reference is ever
        // followed.
        assertSupportedV10Refs(catalogSchema, '');
    }
    const componentsMap = catalogSchema.components ?? {};
    const components = parseCatalogComponents(componentsMap, catalogSchema, atLeastV10, permittedNames);
    // Filter permitted functions via anyFunction.oneOf if declared
    const anyFunc = defs?.anyFunction;
    const permittedFunctionNames = extractPermittedNames(anyFunc?.oneOf, '#/functions/');
    const functions = parseFunctionDefinitions(catalogSchema.functions, catalogSchema, permittedFunctionNames, atLeastV10);
    const themeSchema = parseThemeSchema(catalogSchema, defs);
    // The copy is frozen: the entries' definitions and the document fields
    // refer into it.
    deepFreeze(catalogSchema);
    return {
        id: catalogId,
        protocolVersion: resolvedVersion,
        components,
        functions,
        themeSchema,
        ...readDocumentFields(catalogSchema, components, functions),
    };
}
/** Top-level keys of a catalog document that `CatalogDocumentOptions` models. */
const DOCUMENT_STRING_FIELDS = {
    '$schema': 'schemaUri',
    '$id': 'schemaId',
    'title': 'title',
    'description': 'description',
    'instructions': 'instructions',
};
/** Top-level keys of a catalog document that `Catalog` models besides the string fields. */
const DOCUMENT_STRUCTURE_FIELDS = new Set(['protocolVersion', 'catalogId', 'components']);
function isPlainObject(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
/**
 * Whether `actual` is the union a catalog computes, ignoring object key order.
 */
function isComputedUnion(actual, computed) {
    return canonicalJsonStringify(actual) === canonicalJsonStringify(computed);
}
/**
 * Reads the document-level fields of a catalog document into the model fields
 * `Catalog` keeps.
 *
 * The `anyComponent` and `anyFunction` unions become flags when they list
 * exactly the loaded entries, in order, as `toJson` computes them; a union of
 * any other form stays in `defs` as written. Keys the model has no field for
 * are kept in `extensionFields`.
 *
 * @param document The frozen catalog document.
 * @param components The components loaded from it.
 * @param functions The functions loaded from it.
 */
function readDocumentFields(document, components, functions) {
    const fields = {};
    const extensionFields = {};
    for (const [key, value] of Object.entries(document)) {
        if (key in DOCUMENT_STRING_FIELDS && typeof value === 'string') {
            fields[DOCUMENT_STRING_FIELDS[key]] = value;
        }
        else if (key === 'protocolVersion' && typeof value === 'string') {
            fields.declaredProtocolVersion = value;
        }
        else if (key === 'functions' && (Array.isArray(value) || isPlainObject(value))) {
            fields.functionsLayout = Array.isArray(value) ? 'list' : 'map';
        }
        else if (key === '$defs' && isPlainObject(value)) {
            const anyComponent = isComputedUnion(value['anyComponent'], buildComponentUnion(components.map(c => c.name)));
            const anyFunction = isComputedUnion(value['anyFunction'], buildFunctionUnion(functions.map(f => f.name)));
            fields.unions = { anyComponent, anyFunction };
            const defs = {};
            for (const [name, def] of Object.entries(value)) {
                if ((name === 'anyComponent' && anyComponent) || (name === 'anyFunction' && anyFunction)) {
                    continue;
                }
                defs[name] = def;
            }
            fields.defs = Object.freeze(defs);
        }
        else if (!DOCUMENT_STRUCTURE_FIELDS.has(key) ||
            (key === 'components' && !isPlainObject(value))) {
            extensionFields[key] = value;
        }
    }
    fields.declaredProtocolVersion ??= null;
    fields.declaresCatalogId = typeof document['catalogId'] === 'string';
    fields.declaresComponents = isPlainObject(document['components']);
    fields.unions ??= { anyComponent: false, anyFunction: false };
    if (Object.keys(extensionFields).length > 0) {
        fields.extensionFields = Object.freeze(extensionFields);
    }
    return fields;
}
//# sourceMappingURL=schema_loader.js.map