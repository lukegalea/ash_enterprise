/**
 * Catalog interfaces and component/function registration utilities.
 */
export * from './types.js';
export * from './function_invoker.js';
export { JsonComponentApi, JsonFunctionApi } from './json_entries.js';
export { spec, specDef, type SpecAnnotation, type SpecMixin } from './spec_annotations.js';
//# sourceMappingURL=index.d.ts.map