/**
 * Validation utilities for A2UI payloads, messages, and component graphs.
 *
 * Re-exports payload structural validation and component reference integrity checks.
 */
export * from './integrity-checker.js';
export { PayloadValidator } from './payload-validator.js';
//# sourceMappingURL=index.d.ts.map