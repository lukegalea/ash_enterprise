/**
 * Validates that a value is present and non-empty for v1.0 catalogs.
 *
 * Returns a validation result object with an error message if invalid.
 */
export declare const RequiredV1Point0Implementation: import("../index.js").FunctionImplementation;
/**
 * Validates that a string matches a regular expression pattern for v1.0 catalogs.
 *
 * @throws {A2uiExpressionError} If the pattern is invalid.
 */
export declare const RegexV1Point0Implementation: import("../index.js").FunctionImplementation;
/**
 * Validates that string or array length falls within an optional range for v1.0 catalogs.
 */
export declare const LengthV1Point0Implementation: import("../index.js").FunctionImplementation;
/**
 * Validates that a numeric value falls within an optional range for v1.0 catalogs.
 */
export declare const NumericV1Point0Implementation: import("../index.js").FunctionImplementation;
/**
 * Validates that a string matches basic email address syntax for v1.0 catalogs.
 */
export declare const EmailV1Point0Implementation: import("../index.js").FunctionImplementation;
/** Standard validation function implementations for v1.0 catalogs. */
export declare const V10_VALIDATION_FUNCTION_IMPLEMENTATIONS: import("../index.js").FunctionImplementation[];
//# sourceMappingURL=validation_functions.d.ts.map