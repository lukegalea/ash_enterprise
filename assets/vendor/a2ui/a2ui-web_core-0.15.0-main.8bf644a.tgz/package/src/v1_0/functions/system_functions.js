/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { z } from 'zod';
import { createFunctionImplementation } from '../../catalog/types.js';
import { A2uiValidationError } from '../../errors.js';
import { resolveContextIndex } from '../../resolution/data-context.js';
import { DataBindingSchema, FunctionCallSchema } from '../schema/common-types.js';
/**
 * System function definition for computing iteration indices in array contexts.
 *
 * Evaluates the 0-based iteration index with an optional numerical offset.
 */
export const IndexApi = {
    /** Name of the system function. */
    name: '@index',
    /** Declared return type for catalog type checking. */
    returnType: 'number',
    /** Scope of callers permitted to invoke this function. */
    allowedCallers: 'rendererOnly',
    /**
     * Zod schema validating function arguments.
     *
     * `offset` is a DynamicNumber, so a payload may bind it to a path or a
     * nested call. Once resolved, the value is coerced to a number.
     */
    schema: z.object({
        'offset': z.union([DataBindingSchema, FunctionCallSchema, z.coerce.number()]).optional(),
    }),
};
/**
 * Implementation of the `@index` system function.
 *
 * Returns the 0-based iteration index of the enclosing collection template,
 * plus an optional offset.
 *
 * @throws {A2uiValidationError} If called outside a collection template iteration scope.
 */
export const IndexImplementation = createFunctionImplementation(IndexApi, (args, context) => {
    const offset = typeof args.offset === 'number' && Number.isFinite(args.offset) ? args.offset : 0;
    const index = resolveContextIndex(context);
    if (index === undefined || !Number.isFinite(index)) {
        throw new A2uiValidationError('@index function can only be evaluated inside a collection template iteration scope.');
    }
    return index + offset;
});
/**
 * Standard v1.0 system function implementations.
 */
export const SYSTEM_FUNCTIONS = [IndexImplementation];
//# sourceMappingURL=system_functions.js.map