export * from './schema/index.js';
export * from './standard_defs.js';
export * from './functions/system_functions.js';
export * from './functions/validation_functions_api.js';
export * from './functions/validation_functions.js';
export * from '../catalog/index.js';
export * from '../state/index.js';
export * from '../processing/index.js';
export * from '../resolution/index.js';
export type { ResolvedChildRef } from '../resolution/index.js';
export * from '../reactivity/index.js';
export * from '../expressions/index.js';
export * from '../rpc/index.js';
export * from '../validation/index.js';
export * from '../errors.js';
export * from '../common/events.js';
export { validateMetadata, cloneMetadata, metadataEquals, type A2uiMetadata, type Extensions, type ActionDispatchOptions, } from '../common/metadata.js';
export * from '../catalogs/basic/v1/index.js';
export { MAX_REGEX_PATTERN_CODE_POINTS, MAX_REGEX_VALUE_CODE_POINTS, RegexSyntaxError, analyzeRegex, checkRegexSafety, parseRegexSubset, type AnchorKind, type CodePointRange, type RegexAnalysisResult, type RegexNode, type RegexRejection, } from '../common/regex_subset.js';
export * from '../universal/index.js';
export * from '../spec_versions.js';
export declare const Schemas: {
    A2uiMessageSchemaRaw: {
        $schema: string;
        $id: string;
        title: string;
        description: string;
        type: string;
        oneOf: {
            $ref: string;
        }[];
        $defs: {
            CreateSurfaceMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    createSurface: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            catalogId: {
                                type: string;
                                description: string;
                            };
                            sendDataModel: {
                                type: string;
                                description: string;
                            };
                            components: {
                                $ref: string;
                            };
                            dataModel: {
                                type: string;
                                description: string;
                                additionalProperties: boolean;
                            };
                            metadata: {
                                type: string;
                                description: string;
                                properties: {
                                    extensions: {
                                        $ref: string;
                                    };
                                };
                                additionalProperties: boolean;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            Component: {
                description: string;
                allOf: ({
                    $ref: string;
                    type?: undefined;
                    properties?: undefined;
                } | {
                    type: string;
                    properties: {
                        component: {
                            not: {
                                const: string;
                            };
                        };
                    };
                    $ref?: undefined;
                })[];
                unevaluatedProperties: boolean;
            };
            ComponentsList: {
                type: string;
                description: string;
                minItems: number;
                items: {
                    $ref: string;
                };
            };
            UpdateComponentsMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    updateComponents: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            components: {
                                $ref: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            UpdateDataModelMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    updateDataModel: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            path: {
                                type: string;
                                description: string;
                            };
                            value: {
                                description: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            DeleteSurfaceMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    deleteSurface: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            CallRendererFunctionMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    callRendererFunction: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            functionCallId: {
                                $ref: string;
                                description: string;
                            };
                            callFunction: {
                                allOf: ({
                                    $ref: string;
                                    required?: undefined;
                                } | {
                                    required: string[];
                                    $ref?: undefined;
                                })[];
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            AgentFunctionResponseMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    agentFunctionResponse: {
                        $ref: string;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
        };
    };
};
//# sourceMappingURL=index.d.ts.map