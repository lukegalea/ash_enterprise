/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { A2uiMessageSchema } from '../schema/server-to-client.js';
import { A2uiStateError, A2uiValidationError } from '../errors.js';
import { isComponentArrayReference, isObject, isPath, isResolvedAudioPlayer, isResolvedButton, isResolvedCard, isResolvedCheckbox, isResolvedColumn, isResolvedDateTimeInput, isResolvedDivider, isResolvedIcon, isResolvedImage, isResolvedList, isResolvedModal, isResolvedMultipleChoice, isResolvedRow, isResolvedSlider, isResolvedTabs, isResolvedText, isResolvedTextField, isResolvedVideo, } from './guards.js';
/**
 * Processes and consolidates A2UI v0.8 protocol messages into a structured model of UI surfaces.
 */
export class A2uiMessageProcessor {
    constructor(opts = { mapCtor: Map, arrayCtor: Array, setCtor: Set, objCtor: Object }) {
        this.opts = opts;
        this.mapCtor = Map;
        this.arrayCtor = Array;
        this.setCtor = Set;
        this.objCtor = Object;
        this.arrayCtor = opts.arrayCtor;
        this.mapCtor = opts.mapCtor;
        this.setCtor = opts.setCtor;
        this.objCtor = opts.objCtor;
        this.surfaces = new opts.mapCtor();
    }
    /**
     * Retrieves a map of all visible surfaces with root components.
     *
     * @returns Readonly map of active surfaces keyed by surface ID.
     */
    getSurfaces() {
        const allSurfaces = this.surfaces;
        // NOTE: If a message with a `surfaceUpdate` is processed prior to a
        // `beginRendering` message, the surface is still returned, but it will
        // throw an error when attempting to render it due to the missing
        // `rootComponentId`.
        const visibleSurfaces = new Map();
        for (const [surfaceId, surface] of allSurfaces) {
            if (surface.rootComponentId) {
                visibleSurfaces.set(surfaceId, surface);
            }
        }
        return visibleSurfaces;
    }
    /**
     * Clears all surface records from memory.
     */
    clearSurfaces() {
        this.surfaces.clear();
    }
    /**
     * Processes an array of server-to-client messages and applies state mutations.
     *
     * @param messages Array of v0.8 server-to-client messages.
     */
    processMessages(messages) {
        for (const rawMessage of messages) {
            const message = A2uiMessageSchema.parse(rawMessage);
            if (message.beginRendering) {
                this.handleBeginRendering(message.beginRendering, message.beginRendering.surfaceId);
            }
            if (message.surfaceUpdate) {
                this.handleSurfaceUpdate(message.surfaceUpdate, message.surfaceUpdate.surfaceId);
            }
            if (message.dataModelUpdate) {
                this.handleDataModelUpdate(message.dataModelUpdate, message.dataModelUpdate.surfaceId);
            }
            if (message.deleteSurface) {
                this.handleDeleteSurface(message.deleteSurface);
            }
        }
    }
    /**
     * Retrieves data for a given component node and relative path string.
     *
     * @param node Component node providing data context.
     * @param relativePath Relative or absolute JSON pointer path.
     * @param surfaceId Surface identifier.
     * @returns Resolved data value, or null if not found.
     */
    getData(node, relativePath, surfaceId = A2uiMessageProcessor.DEFAULT_SURFACE_ID) {
        const surface = this.getOrCreateSurface(surfaceId);
        if (!surface)
            return null;
        let finalPath;
        // The special `.` path means the final path is the node's data context
        // path and so we return the dataContextPath as-is.
        if (relativePath === '.' || relativePath === '') {
            finalPath = node.dataContextPath ?? '/';
        }
        else {
            // For all other paths, resolve them against the node's context.
            finalPath = this.resolvePath(relativePath, node.dataContextPath);
        }
        return this.getDataByPath(surface.dataModel, finalPath);
    }
    /**
     * Updates data at a path relative to a component node.
     *
     * @param node Component node providing data context.
     * @param relativePath Relative or absolute JSON pointer path.
     * @param value New value to assign.
     * @param surfaceId Surface identifier.
     */
    setData(node, relativePath, value, surfaceId = A2uiMessageProcessor.DEFAULT_SURFACE_ID) {
        if (!node) {
            console.warn('No component node set');
            return;
        }
        const surface = this.getOrCreateSurface(surfaceId);
        if (!surface)
            return;
        let finalPath;
        // The special `.` path means the final path is the node's data context
        // path and so we return the dataContextPath as-is.
        if (relativePath === '.' || relativePath === '') {
            finalPath = node.dataContextPath ?? '/';
        }
        else {
            // For all other paths, resolve them against the node's context.
            finalPath = this.resolvePath(relativePath, node.dataContextPath);
        }
        this.setDataByPath(surface.dataModel, finalPath, value);
    }
    /**
     * Resolves a path relative to a base data context path.
     *
     * @param path Target path string.
     * @param dataContextPath Base context path.
     * @returns Resolved absolute path string.
     */
    resolvePath(path, dataContextPath) {
        // If the path is absolute, it overrides any context.
        if (path.startsWith('/')) {
            return path;
        }
        if (dataContextPath && dataContextPath !== '/') {
            // Ensure there's exactly one slash between the context and the path.
            return dataContextPath.endsWith('/')
                ? `${dataContextPath}${path}`
                : `${dataContextPath}/${path}`;
        }
        // Fallback for no context or root context: make it an absolute path.
        return `/${path}`;
    }
    parseIfJsonString(value) {
        if (typeof value !== 'string') {
            return value;
        }
        const trimmedValue = value.trim();
        if ((trimmedValue.startsWith('{') && trimmedValue.endsWith('}')) ||
            (trimmedValue.startsWith('[') && trimmedValue.endsWith(']'))) {
            try {
                // It looks like JSON, attempt to parse it.
                return JSON.parse(value);
            }
            catch (e) {
                // It looked like JSON but wasn't. Keep the original string.
                console.warn(`Failed to parse potential JSON string: "${value.substring(0, 50)}..."`, e);
                return value; // Return original string
            }
        }
        // It's a string, but not JSON-like.
        return value;
    }
    /**
     * Converts a specific array format [{key: "...", value_string: "..."}, ...]
     * into a standard Map. It also attempts to parse any string values that
     * appear to be stringified JSON.
     */
    convertKeyValueArrayToMap(arr) {
        const map = new this.mapCtor();
        for (const item of arr) {
            if (!isObject(item) || !('key' in item))
                continue;
            const key = item.key;
            // Find the value, which is in a property prefixed with "value".
            const valueKey = this.findValueKey(item);
            if (!valueKey)
                continue;
            let value = item[valueKey];
            // It's a valueMap. We must recursively convert it.
            if (valueKey === 'valueMap' && Array.isArray(value)) {
                value = this.convertKeyValueArrayToMap(value);
            }
            else if (typeof value === 'string') {
                value = this.parseIfJsonString(value);
            }
            this.setDataByPath(map, key, value);
        }
        return map;
    }
    setDataByPath(root, path, value) {
        // Check if the incoming value is the special key-value array format.
        if (Array.isArray(value) && (value.length === 0 || (isObject(value[0]) && 'key' in value[0]))) {
            // Check for "set primitive at path" convention:
            // path: "/messages/123", contents: [{ key: ".", valueString: "hi" }]
            if (value.length === 1 && isObject(value[0]) && value[0].key === '.') {
                const item = value[0];
                const valueKey = this.findValueKey(item);
                if (valueKey) {
                    // Extract the primitive value
                    value = item[valueKey];
                    // We must still process this value in case it's a valueMap or
                    // a JSON string.
                    if (valueKey === 'valueMap' && Array.isArray(value)) {
                        value = this.convertKeyValueArrayToMap(value);
                    }
                    else if (typeof value === 'string') {
                        value = this.parseIfJsonString(value);
                    }
                    // Now, `value` is the primitive (e.g., "hi"), and we continue
                    // the function.
                }
                else {
                    // Malformed, but fall back to existing behavior.
                    value = this.convertKeyValueArrayToMap(value);
                }
            }
            else {
                value = this.convertKeyValueArrayToMap(value);
            }
        }
        const segments = this.normalizePath(path)
            .split('/')
            .filter(s => s);
        if (segments.length === 0) {
            // Root data can either be a Map or an Object. If we receive an Object,
            // however, we will normalize it to a proper Map.
            if (value instanceof Map || isObject(value)) {
                // Normalize an Object to a Map.
                if (!(value instanceof Map) && isObject(value)) {
                    value = new this.mapCtor(Object.entries(value));
                }
                root.clear();
                for (const [key, v] of value.entries()) {
                    root.set(key, v);
                }
            }
            else {
                console.error('Cannot set root of DataModel to a non-Map value.');
            }
            return;
        }
        let current = root;
        for (let i = 0; i < segments.length - 1; i++) {
            const segment = segments[i];
            let target;
            if (current instanceof Map) {
                target = current.get(segment);
            }
            else if (Array.isArray(current) && /^\d+$/.test(segment)) {
                target = current[parseInt(segment, 10)];
            }
            if (target === undefined || typeof target !== 'object' || target === null) {
                target = new this.mapCtor();
                if (current instanceof this.mapCtor) {
                    current.set(segment, target);
                }
                else if (Array.isArray(current)) {
                    current[parseInt(segment, 10)] = target;
                }
            }
            current = target;
        }
        const finalSegment = segments[segments.length - 1];
        const storedValue = value;
        if (current instanceof this.mapCtor) {
            current.set(finalSegment, storedValue);
        }
        else if (Array.isArray(current) && /^\d+$/.test(finalSegment)) {
            current[parseInt(finalSegment, 10)] = storedValue;
        }
    }
    /**
     * Normalizes a path string into a consistent, slash-delimited format.
     * Converts bracket notation and dot notation in a two-pass.
     * e.g., "bookRecommendations[0].title" -> "/bookRecommendations/0/title"
     * e.g., "book.0.title" -> "/book/0/title"
     */
    normalizePath(path) {
        // 1. Replace all bracket accessors `[index]` with dot accessors `.index`
        const dotPath = path.replace(/\[(\d+)\]/g, '.$1');
        // 2. Split by dots
        const segments = dotPath.split('.');
        // 3. Join with slashes and ensure it starts with a slash
        return '/' + segments.filter(s => s.length > 0).join('/');
    }
    getDataByPath(root, path) {
        const segments = this.normalizePath(path)
            .split('/')
            .filter(s => s);
        let current = root;
        for (const segment of segments) {
            if (current === undefined || current === null)
                return null;
            if (current instanceof Map) {
                current = current.get(segment);
            }
            else if (Array.isArray(current) && /^\d+$/.test(segment)) {
                current = current[parseInt(segment, 10)];
            }
            else if (isObject(current)) {
                if (!Object.prototype.hasOwnProperty.call(current, segment)) {
                    return null;
                }
                current = current[segment];
            }
            else {
                // If we need to traverse deeper but `current` is a primitive, the path is invalid.
                return null;
            }
        }
        return current;
    }
    getOrCreateSurface(surfaceId) {
        let surface = this.surfaces.get(surfaceId);
        if (!surface) {
            surface = new this.objCtor({
                rootComponentId: null,
                componentTree: null,
                dataModel: new this.mapCtor(),
                components: new this.mapCtor(),
                styles: new this.objCtor(),
            });
            this.surfaces.set(surfaceId, surface);
        }
        return surface;
    }
    handleBeginRendering(message, surfaceId) {
        const surface = this.getOrCreateSurface(surfaceId);
        surface.rootComponentId = message.root;
        surface.styles = message.styles ?? {};
        this.rebuildComponentTree(surface);
    }
    handleSurfaceUpdate(message, surfaceId) {
        const surface = this.getOrCreateSurface(surfaceId);
        for (const component of message.components) {
            surface.components.set(component.id, component);
        }
        this.rebuildComponentTree(surface);
    }
    handleDataModelUpdate(message, surfaceId) {
        const surface = this.getOrCreateSurface(surfaceId);
        const path = message.path ?? '/';
        this.setDataByPath(surface.dataModel, path, message.contents);
        this.rebuildComponentTree(surface);
    }
    handleDeleteSurface(message) {
        this.surfaces.delete(message.surfaceId);
    }
    /**
     * Starts at the root component of the surface and builds out the tree
     * recursively. This process involves resolving all properties of the child
     * components, and expanding on any explicit children lists or templates
     * found in the structure.
     *
     * @param surface The surface to be built.
     */
    rebuildComponentTree(surface) {
        if (!surface.rootComponentId) {
            surface.componentTree = null;
            return;
        }
        // Track visited nodes to avoid circular references.
        const visited = new this.setCtor();
        surface.componentTree = this.buildNodeRecursive(surface.rootComponentId, surface, visited, '/', '');
    }
    /** Finds a value key in a map. */
    findValueKey(value) {
        return Object.keys(value).find(k => k.startsWith('value'));
    }
    /**
     * Builds out the nodes recursively.
     */
    buildNodeRecursive(baseComponentId, surface, visited, dataContextPath, idSuffix = '') {
        const fullId = `${baseComponentId}${idSuffix}`; // Construct the full ID
        const { components } = surface;
        if (!components.has(baseComponentId)) {
            return null;
        }
        if (visited.has(fullId)) {
            throw new A2uiStateError(`Circular dependency for component "${fullId}".`);
        }
        visited.add(fullId);
        const componentData = components.get(baseComponentId);
        const componentProps = componentData.component ?? {};
        const componentType = Object.keys(componentProps)[0];
        const unresolvedProperties = componentProps[componentType];
        // Manually build the resolvedProperties object by resolving each value in
        // the component's properties.
        const resolvedProperties = new this.objCtor();
        if (isObject(unresolvedProperties)) {
            for (const [key, value] of Object.entries(unresolvedProperties)) {
                resolvedProperties[key] = this.resolvePropertyValue(value, surface, visited, dataContextPath, idSuffix, key === 'action');
            }
        }
        visited.delete(fullId);
        // Now that we have the resolved properties in place we can go ahead and
        // ensure that they meet expectations in terms of types and so forth,
        // casting them into the specific shape for usage.
        const baseNode = {
            id: fullId,
            dataContextPath,
            weight: componentData.weight ?? 'initial',
        };
        switch (componentType) {
            case 'Text':
                if (!isResolvedText(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Text',
                    properties: resolvedProperties,
                });
            case 'Image':
                if (!isResolvedImage(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Image',
                    properties: resolvedProperties,
                });
            case 'Icon':
                if (!isResolvedIcon(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Icon',
                    properties: resolvedProperties,
                });
            case 'Video':
                if (!isResolvedVideo(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Video',
                    properties: resolvedProperties,
                });
            case 'AudioPlayer':
                if (!isResolvedAudioPlayer(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'AudioPlayer',
                    properties: resolvedProperties,
                });
            case 'Row':
                if (!isResolvedRow(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Row',
                    properties: resolvedProperties,
                });
            case 'Column':
                if (!isResolvedColumn(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Column',
                    properties: resolvedProperties,
                });
            case 'List':
                if (!isResolvedList(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'List',
                    properties: resolvedProperties,
                });
            case 'Card':
                if (!isResolvedCard(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Card',
                    properties: resolvedProperties,
                });
            case 'Tabs':
                if (!isResolvedTabs(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Tabs',
                    properties: resolvedProperties,
                });
            case 'Divider':
                if (!isResolvedDivider(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Divider',
                    properties: resolvedProperties,
                });
            case 'Modal':
                if (!isResolvedModal(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Modal',
                    properties: resolvedProperties,
                });
            case 'Button':
                if (!isResolvedButton(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Button',
                    properties: resolvedProperties,
                });
            case 'CheckBox':
                if (!isResolvedCheckbox(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'CheckBox',
                    properties: resolvedProperties,
                });
            case 'TextField':
                if (!isResolvedTextField(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'TextField',
                    properties: resolvedProperties,
                });
            case 'DateTimeInput':
                if (!isResolvedDateTimeInput(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'DateTimeInput',
                    properties: resolvedProperties,
                });
            case 'MultipleChoice':
                if (!isResolvedMultipleChoice(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'MultipleChoice',
                    properties: resolvedProperties,
                });
            case 'Slider':
                if (!isResolvedSlider(resolvedProperties)) {
                    throw new A2uiValidationError(`Invalid data; expected ${componentType}`);
                }
                return new this.objCtor({
                    ...baseNode,
                    type: 'Slider',
                    properties: resolvedProperties,
                });
            default:
                // Catch-all for other custom component types.
                return new this.objCtor({
                    ...baseNode,
                    type: componentType,
                    properties: resolvedProperties,
                });
        }
    }
    /**
     * Recursively resolves an individual property value. If a property indicates
     * a child node (a string that matches a component ID), an explicitList of
     * children, or a template, these will be built out here.
     */
    resolvePropertyValue(value, surface, visited, dataContextPath, idSuffix = '', isInsideAction = false) {
        // 1. If it's a string that matches a component ID, build that node.
        if (!isInsideAction && typeof value === 'string' && surface.components.has(value)) {
            return this.buildNodeRecursive(value, surface, visited, dataContextPath, idSuffix);
        }
        // 2. If it's a ComponentArrayReference (e.g., a `children` property),
        //    resolve the list and return an array of nodes.
        if (!isInsideAction && isComponentArrayReference(value)) {
            if (value.explicitList) {
                return value.explicitList.map(id => this.buildNodeRecursive(id, surface, visited, dataContextPath, idSuffix));
            }
            if (value.template) {
                const fullDataPath = this.resolvePath(value.template.dataBinding, dataContextPath);
                const data = this.getDataByPath(surface.dataModel, fullDataPath);
                const template = value.template;
                // Handle Array data.
                if (Array.isArray(data)) {
                    return data.map((_, index) => {
                        // Create a synthetic ID based on the template ID and the
                        // full index path of the data (e.g., template-id:0:1)
                        const parentIndices = dataContextPath
                            .split('/')
                            .filter(segment => /^\d+$/.test(segment));
                        const newIndices = [...parentIndices, index];
                        const newSuffix = `:${newIndices.join(':')}`;
                        const childDataContextPath = `${fullDataPath}/${index}`;
                        return this.buildNodeRecursive(template.componentId, // baseId
                        surface, visited, childDataContextPath, newSuffix);
                    });
                }
                // Handle Map data.
                const mapCtor = this.mapCtor;
                if (data instanceof mapCtor) {
                    return Array.from(data.keys(), key => {
                        const newSuffix = `:${key}`;
                        const childDataContextPath = `${fullDataPath}/${key}`;
                        return this.buildNodeRecursive(template.componentId, // baseId
                        surface, visited, childDataContextPath, newSuffix);
                    });
                }
                // Return empty array if the data is not ready yet.
                return new this.arrayCtor();
            }
        }
        // 3. If it's a plain array, resolve each of its items.
        if (Array.isArray(value)) {
            return value.map(item => this.resolvePropertyValue(item, surface, visited, dataContextPath, idSuffix, isInsideAction));
        }
        // 4. If it's a plain object, resolve each of its properties.
        if (isObject(value)) {
            const newObj = new this.objCtor();
            for (const [key, propValue] of Object.entries(value)) {
                // Special case for paths. Here we might get /item/ or ./ on the front
                // of the path which isn't what we want. In this case we check the
                // dataContextPath and if 1) it's not the default and 2) we also see the
                // path beginning with /item/ or ./we trim it.
                let propertyValue = propValue;
                if (isPath(key, propValue) && dataContextPath !== '/') {
                    propertyValue = propValue
                        .replace(/^\.?\/item/, '')
                        .replace(/^\.?\/text/, '')
                        .replace(/^\.?\/label/, '')
                        .replace(/^\.?\//, '');
                    newObj[key] = propertyValue;
                    continue;
                }
                newObj[key] = this.resolvePropertyValue(propertyValue, surface, visited, dataContextPath, idSuffix, isInsideAction || key === 'action');
            }
            return newObj;
        }
        // 5. Otherwise, it's a primitive value.
        return value;
    }
}
A2uiMessageProcessor.DEFAULT_SURFACE_ID = '@default';
//# sourceMappingURL=model-processor.js.map