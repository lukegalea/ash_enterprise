import { ColorPalettes } from '../types/colors.js';
/**
 * Merges multiple style class dictionaries, overriding classes with matching prefixes.
 *
 * @param classes Style class records to merge.
 * @returns Combined style class dictionary.
 */
export declare function merge(...classes: Array<Record<string, boolean>>): Record<string, boolean>;
/**
 * Appends or replaces style classes across multiple target tag mappings.
 *
 * @param target Target tag to class list dictionary.
 * @param exclusions Tag names excluded from mutation.
 * @param classes Style class records to apply.
 * @returns Updated tag-to-classes dictionary.
 */
export declare function appendToAll(target: Record<string, string[]>, exclusions: string[], ...classes: Array<Record<string, boolean>>): Record<string, string[]>;
/**
 * Generates CSS custom property mappings from color palettes.
 *
 * @param palettes Color palette definitions.
 * @returns CSS variable key-value pairs.
 */
export declare function createThemeStyles(palettes: ColorPalettes): Record<string, string>;
/**
 * Converts a palette token key into a CSS custom property name.
 *
 * @param key Color token key string.
 * @returns Formatted CSS property name.
 */
export declare function toProp(key: string): string;
//# sourceMappingURL=utils.d.ts.map