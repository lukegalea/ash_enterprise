import { Catalog, type ComponentApi, type FunctionApi } from '../../catalog/types.js';
/**
 * The ID of the v0.8 basic (standard) catalog. The published v0.8 catalog
 * document declares no `catalogId`, so this is the ID v0.8 messages use for it.
 */
export declare const BASIC_CATALOG_ID = "https://a2ui.org/specification/v0_8/standard_catalog_definition.json";
/**
 * The v0.8 basic catalog: the component APIs of the published v0.8 standard
 * catalog and its `styles` theme, without implementations.
 *
 * Its components and theme are the models generated from the published
 * catalog document by src/v0_8/scripts/generate-catalog.mjs, and its
 * document-level fields are those the generated models carry, so `toJson`
 * computes the published document from the models and `validationSchema` is
 * built from it.
 */
export declare const basicCatalog: Catalog<ComponentApi<import("zod").ZodTypeAny>, FunctionApi>;
//# sourceMappingURL=catalog.d.ts.map