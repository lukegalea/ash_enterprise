/**
 * Base interface for custom event payload details.
 *
 * Ensures event detail structures carry a discriminator `eventType` matching the event name.
 */
export interface BaseEventDetail<EventType extends string> {
    readonly eventType: EventType;
}
//# sourceMappingURL=base.d.ts.map