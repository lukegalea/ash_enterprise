import { BaseEventDetail } from './base.js';
/**
 * Detailed payload for the `a2ui-validation-input` event.
 */
export interface ValidationEventDetail extends BaseEventDetail<'a2ui-validation-input'> {
    /**
     * The ID of the component that is being validated.
     */
    readonly componentId: string;
    /**
     * The current value of the input component.
     */
    readonly value: string;
    /**
     * Whether the current value matches the validation constraints.
     */
    readonly valid: boolean;
}
/**
 * Event dispatched when an input component's validation state is updated.
 */
export declare class A2UIValidationEvent extends CustomEvent<ValidationEventDetail> {
    static readonly EVENT_NAME = "a2ui-validation-input";
    /**
     * Creates a new `A2UIValidationEvent` instance.
     *
     * @param detail Event detail payload without the `eventType` discriminator.
     * @param eventInitDict Optional standard `EventInit` dictionary.
     */
    constructor(detail: Omit<ValidationEventDetail, 'eventType'>, eventInitDict?: EventInit);
}
declare global {
    interface HTMLElementEventMap {
        'a2ui-validation-input': A2UIValidationEvent;
    }
}
//# sourceMappingURL=validation-event.d.ts.map