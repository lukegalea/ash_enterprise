import type { z } from 'zod';
import type { StringValueSchema, NumberValueSchema, BooleanValueSchema } from '../schema/common-types.js';
export declare interface StringValue extends z.infer<typeof StringValueSchema> {
}
export declare interface NumberValue extends z.infer<typeof NumberValueSchema> {
}
export declare interface BooleanValue extends z.infer<typeof BooleanValueSchema> {
}
//# sourceMappingURL=primitives.d.ts.map