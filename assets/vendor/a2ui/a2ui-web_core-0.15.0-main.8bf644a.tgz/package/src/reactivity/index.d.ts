/**
 * Lightweight reactive signal primitives for state observation.
 */
export * from './signals.js';
//# sourceMappingURL=index.d.ts.map