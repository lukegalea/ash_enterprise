import type { ComponentApi } from '../catalog/types.js';
import type { WebComponentImplementation } from './web_component_implementation.js';
/**
 * A Custom Element class that declares its own tag name.
 */
export type TaggedCustomElementConstructor = CustomElementConstructor & {
    /** The HTML tag name to register this element under. */
    readonly tagName: string;
};
/**
 * Pairs a Custom Element with the API of one protocol version.
 *
 * A single element class can serve several protocol versions. Each versioned
 * catalog calls this once per component with its own `api`, so the same
 * element and tag name are shared while the schema follows the catalog.
 *
 * ```ts
 * export const A2uiButton = toWebComponentImplementation(A2uiBasicButtonElement, ButtonApi);
 * ```
 *
 * @param element The element class. Its static `tagName` becomes the
 *     implementation's tag name.
 * @param api The component API whose name and schema the implementation uses.
 * @returns A `WebComponentImplementation` combining `api`, `element`, and
 *     `element.tagName`.
 */
export declare function toWebComponentImplementation<Api extends ComponentApi>(element: TaggedCustomElementConstructor, api: Api): WebComponentImplementation<Api['schema']>;
//# sourceMappingURL=to_web_component_implementation.d.ts.map