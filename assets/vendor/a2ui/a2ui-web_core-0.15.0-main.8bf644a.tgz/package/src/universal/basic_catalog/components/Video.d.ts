import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { VideoSupportedApis } from './supported_apis.js';
export declare class A2uiVideoElement extends BasicCatalogA2uiLitElement<VideoSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-video";
    /**
     * The styles of the video can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-video-border-radius`: Controls the rounded corners of the video. Defaults to `0`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Video.d.ts.map