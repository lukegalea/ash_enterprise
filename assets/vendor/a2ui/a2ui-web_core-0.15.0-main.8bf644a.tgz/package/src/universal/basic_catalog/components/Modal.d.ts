import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ModalSupportedApis } from './supported_apis.js';
export declare class A2uiLitModal extends BasicCatalogA2uiLitElement<ModalSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-modal";
    /**
     * The styles of the modal can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-modal-background`: Controls the background of the modal content.
     * - `--a2ui-modal-padding`: Controls the padding of the modal content.
     * - `--a2ui-modal-border-radius`: Controls the border radius of the modal content.
     * - `--a2ui-modal-box-shadow`: Controls the box shadow of the modal content.
     * - `--a2ui-modal-backdrop-bg`: Controls the background of the backdrop.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    isOpen: boolean;
    openModal(): void;
    closeModal(): void;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
export { A2uiLitModal as A2uiModalElement };
//# sourceMappingURL=Modal.d.ts.map