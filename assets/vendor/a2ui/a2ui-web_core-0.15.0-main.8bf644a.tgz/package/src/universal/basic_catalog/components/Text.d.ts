import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { TextSupportedApis } from './supported_apis.js';
import type { MarkdownRenderer } from '../context/markdown.js';
export declare class A2uiBasicTextElement extends BasicCatalogA2uiLitElement<TextSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-basic-text";
    /**
     * The styles of the text component can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-text-color-text`: The color of the text. Defaults to `--a2ui-color-on-background`.
     * - `--a2ui-text-caption-color`: The color for caption text. Defaults to `light-dark(#666, #aaa)`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    markdownRenderer: MarkdownRenderer | undefined;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Text.d.ts.map