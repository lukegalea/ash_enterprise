/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { html, nothing, css } from 'lit';
import { getAccessibilityDescription, getAccessibilityLabel } from './accessibility.js';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
const ICON_NAME_OVERRIDES = {
    play: 'play_arrow',
    rewind: 'fast_rewind',
    favoriteOff: 'favorite_border',
    starOff: 'star_border',
};
function toMaterialIconName(name) {
    if (ICON_NAME_OVERRIDES[name])
        return ICON_NAME_OVERRIDES[name];
    return name.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
}
export class A2uiIconElement extends BasicCatalogA2uiLitElement {
    render() {
        const props = this.controller.props;
        if (!props)
            return nothing;
        const name = props.name;
        const isSvgPath = typeof name === 'object' && name !== null && 'svgPath' in name;
        const a11yLabel = getAccessibilityLabel(props.accessibility);
        const a11yDescription = getAccessibilityDescription(props.accessibility);
        const hasLabel = a11yLabel !== nothing;
        const isDecorative = !hasLabel && a11yDescription === nothing;
        if (isSvgPath) {
            const svgPath = name.svgPath;
            return html `
        <svg
          class="a2ui-icon a2ui-icon-svg"
          viewBox="0 0 24 24"
          role=${hasLabel ? 'img' : nothing}
          aria-label=${a11yLabel}
          aria-description=${a11yDescription}
          aria-hidden=${isDecorative ? 'true' : nothing}
        >
          <path d=${svgPath}></path>
        </svg>
      `;
        }
        const iconName = typeof name === 'string' ? toMaterialIconName(name) : '';
        return html `<i
      class="material-icons a2ui-icon"
      role=${hasLabel ? 'img' : nothing}
      aria-label=${a11yLabel}
      aria-description=${a11yDescription}
      aria-hidden=${isDecorative ? 'true' : nothing}
      >${iconName}</i
    >`;
    }
}
/** @nocollapse */
A2uiIconElement.tagName = 'a2ui-icon';
/**
 * The icon component can be customized with the following CSS variables:
 *
 * - `--a2ui-icon-size`: Dimensions of the icon.
 * - `--a2ui-icon-color`: Color tint applied to the icon.
 * - `--a2ui-icon-font-family`: Override the font family for icons. Defaults to 'Material Icons', 'Material Symbols Outlined'.
 * - `--a2ui-icon-font-variation-settings`: Complete override for font-variation-settings.
 *
 * @nocollapse
 */
A2uiIconElement.styles = css `
    .a2ui-icon {
      display: inline-block;
      width: var(--a2ui-icon-size, 24px);
      height: var(--a2ui-icon-size, 24px);
      font-size: var(--a2ui-icon-size, 24px);
      font-style: normal;
      font-weight: normal;
      font-family: var(--a2ui-icon-font-family, 'Material Icons', 'Material Symbols Outlined');
      color: var(
        --a2ui-icon-color,
        var(--a2ui-text-color-text, var(--a2ui-color-on-background, #333))
      );
      font-variation-settings: var(--a2ui-icon-font-variation-settings, 'FILL' 1);
      line-height: 1;
      text-transform: none;
      letter-spacing: normal;
      word-wrap: normal;
      white-space: nowrap;
      direction: ltr;
      -webkit-font-smoothing: antialiased;
      text-rendering: optimizeLegibility;
      -moz-osx-font-smoothing: grayscale;
      font-feature-settings: 'liga';
      vertical-align: middle;
    }
    .a2ui-icon.a2ui-icon-svg {
      fill: currentColor;
    }
  `;
//# sourceMappingURL=Icon.js.map