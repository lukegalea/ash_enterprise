import { nothing, type TemplateResult } from 'lit';
import { type CheckableResolvedProps, hasValidationErrors, type ResolvedAccessibilityAttributes, setHostAccessibilityAttributes } from '../../host_accessibility.js';
export { type CheckableResolvedProps, hasValidationErrors, type ResolvedAccessibilityAttributes, setHostAccessibilityAttributes, };
/**
 * Sets group-level `role`, `aria-label`, and `aria-description` directly onto
 * wrapperless layout host elements (`Column` and `Row`) only when explicitly set.
 */
export declare function setContainerAccessibilityAttributes(host: HTMLElement, a11y?: ResolvedAccessibilityAttributes): void;
export declare function hasAttributeValue(value: unknown): boolean;
export declare function getAccessibilityLabel(a11y?: ResolvedAccessibilityAttributes): string | typeof nothing;
export declare function getAccessibilityDescription(a11y?: ResolvedAccessibilityAttributes): string | typeof nothing;
export declare function getValidationErrorId(domId: string, props?: CheckableResolvedProps): string | typeof nothing;
export declare function renderValidationErrors(domId: string, props?: CheckableResolvedProps): TemplateResult | typeof nothing;
//# sourceMappingURL=accessibility.d.ts.map