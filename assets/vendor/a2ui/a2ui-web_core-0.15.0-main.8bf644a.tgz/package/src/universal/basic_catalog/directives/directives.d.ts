export * from './markdown.js';
//# sourceMappingURL=directives.d.ts.map