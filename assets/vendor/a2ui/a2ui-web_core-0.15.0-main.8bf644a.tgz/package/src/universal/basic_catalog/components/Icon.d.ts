import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { IconSupportedApis } from './supported_apis.js';
export declare class A2uiIconElement extends BasicCatalogA2uiLitElement<IconSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-icon";
    /**
     * The icon component can be customized with the following CSS variables:
     *
     * - `--a2ui-icon-size`: Dimensions of the icon.
     * - `--a2ui-icon-color`: Color tint applied to the icon.
     * - `--a2ui-icon-font-family`: Override the font family for icons. Defaults to 'Material Icons', 'Material Symbols Outlined'.
     * - `--a2ui-icon-font-variation-settings`: Complete override for font-variation-settings.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Icon.d.ts.map