import { z } from 'zod';
export declare const HEX_COLOR_REGEX: RegExp;
export declare function isValidCssColor(color: unknown): boolean;
/**
 * Zod schema defining the theme configuration for the basic catalog.
 * Conforms to `specification/v0_9/catalogs/basic/catalog.json#/$defs/theme`.
 */
export declare const BasicCatalogThemeSchema: z.ZodObject<{
    primaryColor: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    iconUrl: z.ZodOptional<z.ZodString>;
    agentDisplayName: z.ZodOptional<z.ZodString>;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    primaryColor: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    iconUrl: z.ZodOptional<z.ZodString>;
    agentDisplayName: z.ZodOptional<z.ZodString>;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    primaryColor: z.ZodOptional<z.ZodEffects<z.ZodString, string, string>>;
    iconUrl: z.ZodOptional<z.ZodString>;
    agentDisplayName: z.ZodOptional<z.ZodString>;
}, z.ZodTypeAny, "passthrough">>;
export type BasicCatalogTheme = z.infer<typeof BasicCatalogThemeSchema>;
//# sourceMappingURL=theme.d.ts.map