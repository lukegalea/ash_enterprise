/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, css } from 'lit';
import { state } from 'lit/decorators.js';
import { classMap } from 'lit/directives/class-map.js';
import { getAccessibilityDescription, getAccessibilityLabel } from './accessibility.js';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
export class A2uiLitTabs extends BasicCatalogA2uiLitElement {
    constructor() {
        super(...arguments);
        this.activeIndex = 0;
    }
    willUpdate(changedProperties) {
        super.willUpdate(changedProperties);
        const props = this.controller?.props;
        if (props?.tabs && this.activeIndex >= props.tabs.length) {
            this.activeIndex = 0;
        }
    }
    render() {
        const props = this.controller?.props;
        if (!props || !props.tabs)
            return nothing;
        const tabPanelId = `${this.domId}-tabpanel`;
        const activeTab = props.tabs[this.activeIndex];
        return html `
      <div class="a2ui-tabs">
        <div
          class="a2ui-tab-bar"
          role="tablist"
          aria-label=${getAccessibilityLabel(props.accessibility)}
          aria-description=${getAccessibilityDescription(props.accessibility)}
        >
          ${props.tabs?.map((tab, i) => html `
              <button
                type="button"
                role="tab"
                id="${this.domId}-tab-${i}"
                aria-selected=${i === this.activeIndex ? 'true' : 'false'}
                aria-controls=${tabPanelId}
                class=${classMap({
            'a2ui-tab-button': true,
            'a2ui-tab-button-active': i === this.activeIndex,
        })}
                @click=${() => (this.activeIndex = i)}
              >
                ${tab.title}
              </button>
            `)}
        </div>
        <div
          class="a2ui-tab-content"
          role="tabpanel"
          id=${tabPanelId}
          aria-labelledby=${activeTab ? `${this.domId}-tab-${this.activeIndex}` : nothing}
        >
          ${activeTab ? html `${this.renderNode(activeTab.child)}` : nothing}
        </div>
      </div>
    `;
    }
}
/** @nocollapse */
A2uiLitTabs.tagName = 'a2ui-tabs';
/**
 * The styles of the tabs can be customized by redefining the following
 * CSS variables:
 *
 * - `--a2ui-tabs-border`: Controls the border of the tab bar. Defaults to `2px solid var(--a2ui-color-border, #eee)`.
 * - `--a2ui-tabs-header-background`: Controls the background of tab buttons. Defaults to `transparent`.
 * - `--a2ui-tabs-header-color`: Controls the text color of tab buttons. Defaults to `var(--a2ui-text-caption-color, #666)`.
 * - `--a2ui-tabs-header-background-active`: Controls the background of the active tab button. Defaults to `transparent`.
 * - `--a2ui-tabs-header-color-active`: Controls the text color of the active tab button. Defaults to `var(--a2ui-color-primary, #007bff)`.
 * - `--a2ui-tabs-content-padding`: Controls the padding of the tab content. Defaults to `var(--a2ui-spacing-m, 16px) 0`.
 *
 * @nocollapse
 */
A2uiLitTabs.styles = css `
    .a2ui-tabs {
      display: flex;
      flex-direction: column;
      width: 100%;
    }
    .a2ui-tab-bar {
      display: flex;
      border-bottom: var(--a2ui-tabs-border, 2px solid var(--a2ui-color-border, #eee));
      gap: var(--a2ui-spacing-m, 16px);
    }
    .a2ui-tab-button {
      padding: var(--a2ui-spacing-s, 8px) var(--a2ui-spacing-m, 16px);
      border: none;
      background: var(--a2ui-tabs-header-background, transparent);
      cursor: pointer;
      font-weight: 500;
      color: var(--a2ui-tabs-header-color, var(--a2ui-text-caption-color, #666));
      border-bottom: 2px solid transparent;
      margin-bottom: -2px;
    }
    .a2ui-tab-button.a2ui-tab-button-active {
      background: var(--a2ui-tabs-header-background-active, transparent);
      color: var(--a2ui-tabs-header-color-active, var(--a2ui-color-primary, #007bff));
      border-bottom: 2px solid var(--a2ui-color-primary, #007bff);
    }
    .a2ui-tab-content {
      padding: var(--a2ui-tabs-content-padding, var(--a2ui-spacing-m, 16px) 0);
    }
  `;
__decorate([
    state()
], A2uiLitTabs.prototype, "activeIndex", void 0);
export { A2uiLitTabs as A2uiTabsElement };
//# sourceMappingURL=Tabs.js.map