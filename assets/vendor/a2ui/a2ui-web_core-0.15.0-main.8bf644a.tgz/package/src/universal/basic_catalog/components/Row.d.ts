import { nothing, PropertyValues } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { RowSupportedApis } from './supported_apis.js';
export declare class A2uiBasicRowElement extends BasicCatalogA2uiLitElement<RowSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-basic-row";
    /**
     * The styles of the row can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-row-gap`: The gap between items in the row. Defaults to `--a2ui-spacing-m`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    updated(changedProperties: PropertyValues): void;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Row.d.ts.map