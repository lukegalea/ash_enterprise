import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { TabsSupportedApis } from './supported_apis.js';
export declare class A2uiLitTabs extends BasicCatalogA2uiLitElement<TabsSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-tabs";
    /**
     * The styles of the tabs can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-tabs-border`: Controls the border of the tab bar. Defaults to `2px solid var(--a2ui-color-border, #eee)`.
     * - `--a2ui-tabs-header-background`: Controls the background of tab buttons. Defaults to `transparent`.
     * - `--a2ui-tabs-header-color`: Controls the text color of tab buttons. Defaults to `var(--a2ui-text-caption-color, #666)`.
     * - `--a2ui-tabs-header-background-active`: Controls the background of the active tab button. Defaults to `transparent`.
     * - `--a2ui-tabs-header-color-active`: Controls the text color of the active tab button. Defaults to `var(--a2ui-color-primary, #007bff)`.
     * - `--a2ui-tabs-content-padding`: Controls the padding of the tab content. Defaults to `var(--a2ui-spacing-m, 16px) 0`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    activeIndex: number;
    willUpdate(changedProperties: any): void;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
export { A2uiLitTabs as A2uiTabsElement };
//# sourceMappingURL=Tabs.d.ts.map