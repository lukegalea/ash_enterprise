import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ButtonSupportedApis } from './supported_apis.js';
/**
 * A button component that can be used to trigger an action.
 */
export declare class A2uiBasicButtonElement extends BasicCatalogA2uiLitElement<ButtonSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-basic-button";
    /**
     * The styles of the button can be customized by redefining the following
     * CSS variables:
     *
     * - Primary variant:
     *   - `--a2ui-color-primary`: The color for the primary variant.
     *   - `--a2ui-color-on-primary`: The color of the text on the primary variant.
     * - Standard/default variant:
     *   - `--a2ui-color-secondary`: The color for the default variant.
     *   - `--a2ui-color-on-secondary`: The color of the text on the default variant.
     * - `--a2ui-button-border`: The styling for the button border. Defaults to `--a2ui-border-width` width and `--a2ui-color-border` color.
     * - `--a2ui-button-border-radius`: The border radius of the button. Defaults to `--a2ui-border-radius`.
     * - `--a2ui-button-padding`: The padding of the button. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-button-margin`: The outer margin of the button. Defaults to `--a2ui-spacing-m`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Button.d.ts.map