import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { TextFieldSupportedApis } from './supported_apis.js';
export declare class A2uiBasicTextFieldElement extends BasicCatalogA2uiLitElement<TextFieldSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-basic-textfield";
    /**
     * The styles of the text field can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-textfield-width`: Width of the component. Defaults to `100%`.
     * - `--a2ui-textfield-border`: The styling for the text field border. Defaults to `--a2ui-border-width` width and `--a2ui-color-border` color.
     * - `--a2ui-textfield-border-radius`: The border radius of the text field. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-textfield-padding`: The padding of the text field. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-textfield-color-border-focus`: The border color on focus. Defaults to `--a2ui-color-primary`.
     * - `--a2ui-textfield-color-error`: The color for both invalid border and error text. Defaults to red.
     * - `--a2ui-textfield-label-font-size`: Font size of the label. Defaults to `--a2ui-label-font-size` then `--a2ui-font-size-s`.
     * - `--a2ui-textfield-label-font-weight`: Font weight of the label. Defaults to `--a2ui-label-font-weight` then `bold`.
     *
     * It also inherits global input variables:
     * - `--a2ui-color-input`: Background color.
     * - `--a2ui-color-on-input`: Text color.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=TextField.d.ts.map