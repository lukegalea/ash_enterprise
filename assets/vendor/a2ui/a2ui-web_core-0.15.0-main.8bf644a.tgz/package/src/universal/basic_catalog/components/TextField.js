/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { html, nothing, css } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import { getAccessibilityDescription, getAccessibilityLabel, getValidationErrorId, renderValidationErrors, } from './accessibility.js';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
export class A2uiBasicTextFieldElement extends BasicCatalogA2uiLitElement {
    render() {
        const props = this.controller.props;
        if (!props)
            return nothing;
        const isInvalid = props.isValid === false;
        const onInput = (e) => props.setValue?.(e.target.value);
        let type = 'text';
        if (props.variant === 'number')
            type = 'number';
        if (props.variant === 'obscured')
            type = 'password';
        const classes = { 'a2ui-textfield': true, 'a2ui-invalid': isInvalid };
        // `placeholder` is new in v1.0.
        const placeholder = ('placeholder' in props && props.placeholder) || nothing;
        const inputId = `${this.domId}-input`;
        const a11yLabel = getAccessibilityLabel(props.accessibility);
        const a11yDescription = getAccessibilityDescription(props.accessibility);
        const errorId = getValidationErrorId(this.domId, props);
        return html `
      ${props.label ? html `<label for=${inputId}>${props.label}</label>` : nothing}
      ${props.variant === 'longText'
            ? html `<textarea
            id=${inputId}
            class=${classMap(classes)}
            placeholder=${placeholder}
            aria-label=${a11yLabel}
            aria-description=${a11yDescription}
            aria-invalid=${isInvalid ? 'true' : nothing}
            aria-describedby=${errorId}
            .value=${props.value || ''}
            @input=${onInput}
          ></textarea>`
            : html `<input
            id=${inputId}
            type=${type}
            class=${classMap(classes)}
            placeholder=${placeholder}
            aria-label=${a11yLabel}
            aria-description=${a11yDescription}
            aria-invalid=${isInvalid ? 'true' : nothing}
            aria-describedby=${errorId}
            .value=${props.value || ''}
            @input=${onInput}
          />`}
      ${renderValidationErrors(this.domId, props)}
    `;
    }
}
/** @nocollapse */
A2uiBasicTextFieldElement.tagName = 'a2ui-basic-textfield';
/**
 * The styles of the text field can be customized by redefining the following
 * CSS variables:
 *
 * - `--a2ui-textfield-width`: Width of the component. Defaults to `100%`.
 * - `--a2ui-textfield-border`: The styling for the text field border. Defaults to `--a2ui-border-width` width and `--a2ui-color-border` color.
 * - `--a2ui-textfield-border-radius`: The border radius of the text field. Defaults to `--a2ui-spacing-m`.
 * - `--a2ui-textfield-padding`: The padding of the text field. Defaults to `--a2ui-spacing-m`.
 * - `--a2ui-textfield-color-border-focus`: The border color on focus. Defaults to `--a2ui-color-primary`.
 * - `--a2ui-textfield-color-error`: The color for both invalid border and error text. Defaults to red.
 * - `--a2ui-textfield-label-font-size`: Font size of the label. Defaults to `--a2ui-label-font-size` then `--a2ui-font-size-s`.
 * - `--a2ui-textfield-label-font-weight`: Font weight of the label. Defaults to `--a2ui-label-font-weight` then `bold`.
 *
 * It also inherits global input variables:
 * - `--a2ui-color-input`: Background color.
 * - `--a2ui-color-on-input`: Text color.
 *
 * @nocollapse
 */
A2uiBasicTextFieldElement.styles = css `
    :host,
    a2ui-basic-textfield {
      display: flex;
      flex-direction: column;
      width: var(--a2ui-textfield-width, 100%);
      gap: var(--a2ui-spacing-xs, 0.25rem);
    }
    .a2ui-textfield {
      box-sizing: border-box;
      width: 100%;
      background-color: var(--a2ui-color-input, #fff);
      color: var(--a2ui-color-on-input, #333);
      border: var(--a2ui-textfield-border, var(--a2ui-border));
      border-radius: var(--a2ui-textfield-border-radius, var(--a2ui-spacing-m));
      padding: var(--a2ui-textfield-padding, var(--a2ui-spacing-m));
      font-family: inherit;
    }
    .a2ui-textfield:focus {
      outline: none;
      border-color: var(--a2ui-textfield-color-border-focus, var(--a2ui-color-primary, #17e));
    }
    .a2ui-textfield.a2ui-invalid {
      border-color: var(--a2ui-textfield-color-error, red);
    }
    label {
      font-size: var(
        --a2ui-textfield-label-font-size,
        var(--a2ui-label-font-size, var(--a2ui-font-size-s))
      );
      font-weight: var(--a2ui-textfield-label-font-weight, var(--a2ui-label-font-weight, bold));
    }
    .a2ui-error-message {
      color: var(--a2ui-textfield-color-error, red);
      font-size: var(--a2ui-font-size-xs, 0.75rem);
    }
  `;
//# sourceMappingURL=TextField.js.map