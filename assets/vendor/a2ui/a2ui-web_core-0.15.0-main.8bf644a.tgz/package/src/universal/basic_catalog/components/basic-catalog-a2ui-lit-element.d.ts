import { ComponentApi, type InferredComponentApiSchemaType } from '../../../catalog/types.js';
import type { ResolveA2uiProps } from '../../../resolution/generic-binder.js';
import { A2uiLitElement } from '../../index.js';
import { type CheckableResolvedProps, type ResolvedAccessibilityAttributes } from './accessibility.js';
/**
 * Internal base class for the built-in Basic Catalog components.
 *
 * Extends `A2uiLitElement` to inject global basic catalog CSS, map `props.weight` to flex,
 * and calculate `--a2ui-color-primary` CSS variables from the surface theme.
 *
 * @template Api The component API, or a union of the APIs of every protocol
 *     version the element supports. Props are inferred from each API's schema.
 * @internal
 */
export declare abstract class BasicCatalogA2uiLitElement<Api extends ComponentApi> extends A2uiLitElement<Api, ResolveA2uiProps<InferredComponentApiSchemaType<Api>>> {
    /**
     * Lifecycle hook invoked when the element is connected to the DOM.
     * Injects global basic catalog CSS.
     */
    connectedCallback(): void;
    /**
     * Lifecycle hook invoked before rendering.
     * Resolves the component flex weight and calculates theme color CSS variables.
     *
     * @param changedProperties Map of changed properties with their previous values.
     */
    willUpdate(changedProperties: Map<string, any>): void;
    /**
     * Built-in Basic Catalog components bind `accessibility.label`,
     * `accessibility.description`, and validation attributes directly in their
     * `render()` templates (or via `setContainerAccessibilityAttributes` on
     * `Column` and `Row`), so only host-level `aria-live` and `aria-hidden`
     * are applied on the host when `accessibilityTarget()` is not overridden.
     */
    protected applyAccessibilityAttributes(accessibility?: ResolvedAccessibilityAttributes, checkable?: CheckableResolvedProps): void;
}
//# sourceMappingURL=basic-catalog-a2ui-lit-element.d.ts.map