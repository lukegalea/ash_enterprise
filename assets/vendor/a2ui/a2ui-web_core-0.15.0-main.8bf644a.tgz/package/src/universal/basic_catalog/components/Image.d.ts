import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ImageSupportedApis } from './supported_apis.js';
export declare class A2uiImageElement extends BasicCatalogA2uiLitElement<ImageSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-image";
    /**
     * The styles of the image can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-image-border-radius`: Controls the rounded corners of the image. Defaults to `0`.
     * - `--a2ui-image-icon-size`: Controls the size of the `icon` variant. Defaults to `24px`.
     * - `--a2ui-image-avatar-size`: Controls the size of the `avatar` variant. Defaults to `40px`.
     * - `--a2ui-image-small-feature-size`: Controls the max-width of the `smallFeature` variant. Defaults to `100px`.
     * - `--a2ui-image-large-feature-size`: Controls the max-height of the `largeFeature` variant. Defaults to `400px`.
     * - `--a2ui-image-header-size`: Controls the height of the `header` variant. Defaults to `200px`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Image.d.ts.map