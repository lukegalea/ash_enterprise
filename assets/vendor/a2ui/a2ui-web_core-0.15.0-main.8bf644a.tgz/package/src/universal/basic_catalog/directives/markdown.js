/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { html, noChange } from 'lit';
import { directive } from 'lit/directive.js';
import { AsyncDirective } from 'lit/async-directive.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
let globalMarkdownRenderer;
/**
 * Sets the global markdown renderer for basic catalog text components.
 * Host applications or renderer packages can register a renderer (e.g. from `@a2ui/markdown-it`)
 * to automatically render markdown without explicit per-component context configuration.
 *
 * NOTE: The provided renderer is responsible for sanitizing its generated HTML output.
 */
export function setMarkdownRenderer(renderer) {
    globalMarkdownRenderer = renderer;
}
/**
 * Gets the currently registered global markdown renderer, if any.
 */
export function getMarkdownRenderer() {
    return globalMarkdownRenderer;
}
/** @internal For testing purposes only */
export function resetMarkdownWarningLoggedForTesting() {
    MarkdownDirective.resetWarningForTesting();
}
class MarkdownDirective extends AsyncDirective {
    constructor() {
        super(...arguments);
        this.renderToken = 0;
        this.lastValue = null;
        this.lastRenderer = undefined;
        this.lastTagClassMap = null;
    }
    /** @internal For testing purposes only */
    static resetWarningForTesting() {
        MarkdownDirective.defaultMarkdownWarningLogged = false;
    }
    update(_part, [value, markdownRenderer, markdownOptions]) {
        const effectiveRenderer = markdownRenderer ?? globalMarkdownRenderer;
        const jsonTagClassMap = JSON.stringify(markdownOptions?.tagClassMap);
        if (this.lastValue === value &&
            this.lastRenderer === effectiveRenderer &&
            jsonTagClassMap === this.lastTagClassMap) {
            return noChange;
        }
        this.lastValue = value;
        this.lastRenderer = effectiveRenderer;
        this.lastTagClassMap = jsonTagClassMap;
        return this.render(value, effectiveRenderer, markdownOptions);
    }
    render(value, markdownRenderer, markdownOptions) {
        const effectiveRenderer = markdownRenderer ?? globalMarkdownRenderer;
        if (effectiveRenderer) {
            // Discard stale results from previous in-flight asynchronous renders
            // if a newer render request is initiated before earlier promises resolve.
            const token = ++this.renderToken;
            try {
                Promise.resolve(effectiveRenderer(value, markdownOptions))
                    .then((renderedStr) => {
                    if (this.isConnected && token === this.renderToken) {
                        this.setValue(unsafeHTML(renderedStr));
                    }
                })
                    .catch(err => {
                    console.error('[MarkdownDirective] Error rendering markdown:', err);
                });
            }
            catch (err) {
                console.error('[MarkdownDirective] Synchronous error rendering markdown:', err);
            }
            return html `<span class="no-markdown-renderer">${value}</span>`;
        }
        if (!MarkdownDirective.defaultMarkdownWarningLogged) {
            console.warn('[MarkdownDirective]', "can't render markdown because no markdown renderer is configured.\n", 'Use `@a2ui/markdown-it`, or your own markdown renderer.');
            MarkdownDirective.defaultMarkdownWarningLogged = true;
        }
        return html `<span class="no-markdown-renderer">${value}</span>`;
    }
}
MarkdownDirective.defaultMarkdownWarningLogged = false;
export const markdown = directive(MarkdownDirective);
//# sourceMappingURL=markdown.js.map