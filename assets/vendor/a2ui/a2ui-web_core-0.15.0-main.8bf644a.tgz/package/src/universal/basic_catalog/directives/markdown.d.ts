import { noChange } from 'lit';
import { DirectiveParameters, Part } from 'lit/directive.js';
import { AsyncDirective } from 'lit/async-directive.js';
import type { MarkdownRenderer, MarkdownRendererOptions } from '../context/markdown.js';
/**
 * Sets the global markdown renderer for basic catalog text components.
 * Host applications or renderer packages can register a renderer (e.g. from `@a2ui/markdown-it`)
 * to automatically render markdown without explicit per-component context configuration.
 *
 * NOTE: The provided renderer is responsible for sanitizing its generated HTML output.
 */
export declare function setMarkdownRenderer(renderer?: MarkdownRenderer): void;
/**
 * Gets the currently registered global markdown renderer, if any.
 */
export declare function getMarkdownRenderer(): MarkdownRenderer | undefined;
/** @internal For testing purposes only */
export declare function resetMarkdownWarningLoggedForTesting(): void;
declare class MarkdownDirective extends AsyncDirective {
    private static defaultMarkdownWarningLogged;
    private renderToken;
    private lastValue;
    private lastRenderer;
    private lastTagClassMap;
    /** @internal For testing purposes only */
    static resetWarningForTesting(): void;
    update(_part: Part, [value, markdownRenderer, markdownOptions]: DirectiveParameters<this>): import("lit-html").TemplateResult<1> | typeof noChange;
    render(value: string, markdownRenderer?: MarkdownRenderer, markdownOptions?: MarkdownRendererOptions): import("lit-html").TemplateResult<1>;
}
export declare const markdown: (value: string, markdownRenderer?: MarkdownRenderer | undefined, markdownOptions?: MarkdownRendererOptions | undefined) => import("lit-html/directive.js").DirectiveResult<typeof MarkdownDirective>;
export {};
//# sourceMappingURL=markdown.d.ts.map