import type { ComponentContext } from '../resolution/component-context.js';
import type { ComponentNode } from '../resolution/component-node.js';
/**
 * The DOM contract an A2UI Custom Element fulfills.
 *
 * A host renderer creates the element for a `WebComponentImplementation` and
 * assigns `node` (preferred) or `context`; the element binds itself from
 * there. Renderers use this type to set the properties on an element they
 * have only as an `HTMLElement`.
 */
export interface A2uiWebComponentElement extends HTMLElement {
    /**
     * The A2UI context for the node this element renders.
     *
     * The host renderer assigns it right after creating the element, and may
     * reassign it when the element is reused for a different node. Implementations
     * should treat an assignment as the signal to (re)bind to the data model,
     * props, and event handlers exposed by the context, and must tolerate it being
     * unset while the element is detached or rendered standalone.
     *
     * @deprecated Assign `node` instead.
     */
    context?: ComponentContext;
    /**
     * The resolved node this element renders.
     *
     * A renderer that resolves its surface through a `NodeResolver` assigns
     * `node` to the element; when both `node` and `context` are set, `node`
     * wins and the element takes its properties and its children from the node.
     */
    node?: ComponentNode;
}
//# sourceMappingURL=a2ui_web_component_element.d.ts.map