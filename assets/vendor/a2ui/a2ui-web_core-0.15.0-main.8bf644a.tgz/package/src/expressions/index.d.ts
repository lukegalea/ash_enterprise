/**
 * Expression parser and evaluator for A2UI dynamic bindings.
 */
export * from './expression_parser.js';
//# sourceMappingURL=index.d.ts.map