/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { A2uiExpressionError } from '../errors.js';
/**
 * The maximum allowed length for expression template strings to prevent resource exhaustion (CWE-400),
 * measured in UTF-16 code units (i.e. JavaScript `string.length`, not characters and not bytes).
 */
export const MAX_EXPRESSION_TEMPLATE_LENGTH = 10_000;
/**
 * The maximum allowed number of parts in an expression template to prevent resource exhaustion (CWE-400).
 *
 * A "part" is an individual segment produced when parsing the template string: each interpolated
 * expression (`${...}`), escaped interpolation delimiter (`\${`), or literal text span between
 * interpolations that forms an element in the parsed output array.
 */
export const MAX_EXPRESSION_PARTS = 1_000;
/**
 * An optional sign, a mantissa (`5`, `5.`, `5.25`, or `.5`), and an optional
 * exponent (`e` or `E`, an optional sign, digits).
 *
 * Every engine checks the same pattern: `_NUMBER_LITERAL` in Python,
 * `_numberLiteral` in Dart, and `ExpressionParser.numberLiteralPattern` in
 * Swift.
 */
const NUMBER_LITERAL = /^[+-]?(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$/;
/**
 * Parses A2UI expressions, supporting string interpolation and function calls.
 *
 * Converts strings with `${...}` placeholders into arrays of `DynamicValue` objects.
 * Supports literals (strings, numbers, booleans), path-based data bindings, and
 * nested function calls with named arguments.
 */
export class ExpressionParser {
    /**
     * Parses an input string into an array of DynamicValues.
     *
     * If the input contains no interpolation placeholders, returns the raw string as a single literal.
     *
     * @param input Raw string to parse.
     * @param depth Current recursion depth.
     * @returns An array of parsed dynamic values and literals.
     */
    parse(input, depth = 0) {
        if (depth > ExpressionParser.MAX_DEPTH) {
            throw new A2uiExpressionError('Max recursion depth reached in parse');
        }
        if (input && input.length > MAX_EXPRESSION_TEMPLATE_LENGTH) {
            throw new A2uiExpressionError(`Expression template length (${input.length}) exceeds maximum limit (${MAX_EXPRESSION_TEMPLATE_LENGTH})`);
        }
        if (!input) {
            return [];
        }
        if (!input.includes('${')) {
            return [input];
        }
        const parts = [];
        const scanner = new Scanner(input);
        while (!scanner.isAtEnd()) {
            if (parts.length >= MAX_EXPRESSION_PARTS) {
                throw new A2uiExpressionError(`Expression parts count exceeds maximum limit (${MAX_EXPRESSION_PARTS})`);
            }
            if (scanner.matches('${')) {
                scanner.advance(2);
                const content = this.extractInterpolationContent(scanner);
                const parsed = this.parseExpression(content, depth + 1);
                if (parsed !== null) {
                    parts.push(parsed);
                }
            }
            else if (scanner.peek() === '\\' && scanner.peek(1) === '$' && scanner.peek(2) === '{') {
                scanner.advance();
                parts.push('${');
                scanner.advance(2);
            }
            else {
                const start = scanner.pos;
                while (!scanner.isAtEnd()) {
                    if (scanner.matches('${')) {
                        break;
                    }
                    if (scanner.peek() === '\\' && scanner.peek(1) === '$' && scanner.peek(2) === '{') {
                        break;
                    }
                    scanner.advance();
                }
                parts.push(scanner.input.substring(start, scanner.pos));
            }
        }
        return parts.filter(p => p !== null && p !== '');
    }
    extractInterpolationContent(scanner) {
        const start = scanner.pos;
        let braceBalance = 1;
        while (!scanner.isAtEnd() && braceBalance > 0) {
            const char = scanner.advance();
            if (char === '{') {
                braceBalance++;
            }
            else if (char === '}') {
                braceBalance--;
            }
            else if (char === "'" || char === '"') {
                const quote = char;
                while (!scanner.isAtEnd()) {
                    const c = scanner.advance();
                    if (c === '\\') {
                        scanner.advance();
                    }
                    else if (c === quote) {
                        break;
                    }
                }
            }
        }
        if (braceBalance > 0) {
            throw new A2uiExpressionError("Unclosed interpolation: missing '}'");
        }
        return scanner.input.substring(start, scanner.pos - 1);
    }
    /**
     * Parses a single expression string into a DynamicValue.
     *
     * Unlike `parse()`, which handles mixed literal text and interpolations,
     * this assumes the entire string is a single expression (e.g., as found inside `${...}`).
     *
     * @param expr The expression string to parse.
     * @param depth The current recursion depth.
     * @returns The resolved DynamicValue.
     */
    parseExpression(expr, depth = 0) {
        expr = expr.trim();
        if (!expr)
            return '';
        const scanner = new Scanner(expr);
        const result = this.parseExpressionInternal(scanner, depth);
        if (!scanner.isAtEnd()) {
            throw new A2uiExpressionError(`Unexpected characters at end of expression: '${scanner.input.substring(scanner.pos)}'`);
        }
        return result;
    }
    parseExpressionInternal(scanner, depth) {
        // Both recursive paths pass through here: interpolations nested inside an interpolation,
        // and function-call arguments that are themselves expressions. Checking here counts both.
        if (depth > ExpressionParser.MAX_DEPTH) {
            throw new A2uiExpressionError('Max recursion depth reached in parse');
        }
        scanner.skipWhitespace();
        if (scanner.isAtEnd())
            return '';
        // 0. Nested Interpolation (Block)
        if (scanner.matches('${')) {
            scanner.advance(2);
            const content = this.extractInterpolationContent(scanner);
            return this.parseExpression(content, depth + 1);
        }
        // 1. Literals
        if (scanner.matchesString("'") || scanner.matchesString('"')) {
            return this.parseStringLiteral(scanner);
        }
        if (this.isNumberStart(scanner)) {
            return this.parseNumberLiteral(scanner);
        }
        if (scanner.matchesKeyword('true'))
            return true;
        if (scanner.matchesKeyword('false'))
            return false;
        if (scanner.matchesKeyword('null'))
            return '';
        // 2. Identifiers (Function calls or Path starts)
        const token = this.scanPathOrIdentifier(scanner);
        scanner.skipWhitespace();
        if (scanner.peek() === '(') {
            return this.parseFunctionCall(token, scanner, depth);
        }
        else {
            if (token.startsWith('@')) {
                throw new A2uiExpressionError(`Expected '(' after function name '${token}'`);
            }
            if (!token) {
                return '';
            }
            return { path: token };
        }
    }
    scanPathOrIdentifier(scanner) {
        const start = scanner.pos;
        if (scanner.peek() === '@') {
            const next = scanner.peek(1);
            if (!next || !/[A-Za-z_]/.test(next)) {
                throw new A2uiExpressionError("Invalid identifier starting with '@' in expression");
            }
            scanner.advance();
            while (!scanner.isAtEnd()) {
                const c = scanner.peek();
                if (/[A-Za-z0-9_]/.test(c)) {
                    scanner.advance();
                }
                else {
                    break;
                }
            }
            return scanner.input.substring(start, scanner.pos);
        }
        while (!scanner.isAtEnd()) {
            const c = scanner.peek();
            if (isIdContinue(c) || c === '/' || c === '.' || c === '-') {
                scanner.advance();
            }
            else {
                break;
            }
        }
        return scanner.input.substring(start, scanner.pos);
    }
    parseFunctionCall(funcName, scanner, depth) {
        scanner.match('(');
        scanner.skipWhitespace();
        const args = {};
        while (!scanner.isAtEnd() && scanner.peek() !== ')') {
            const argName = this.scanIdentifier(scanner);
            scanner.skipWhitespace();
            if (!scanner.match(':')) {
                throw new A2uiExpressionError(`Expected ':' after argument name '${argName}' in function '${funcName}'`);
            }
            scanner.skipWhitespace();
            Object.defineProperty(args, argName, {
                value: this.parseExpressionInternal(scanner, depth + 1),
                enumerable: true,
                writable: true,
                configurable: true,
            });
            scanner.skipWhitespace();
            if (scanner.peek() === ',') {
                scanner.advance();
                scanner.skipWhitespace();
            }
        }
        if (!scanner.match(')')) {
            throw new A2uiExpressionError(`Expected ')' after function arguments for '${funcName}'`);
        }
        return { call: funcName, args, returnType: 'any' };
    }
    scanIdentifier(scanner) {
        const start = scanner.pos;
        while (!scanner.isAtEnd() && isIdContinue(scanner.peek())) {
            scanner.advance();
        }
        return scanner.input.substring(start, scanner.pos);
    }
    parseStringLiteral(scanner) {
        const quote = scanner.advance();
        let result = '';
        let closed = false;
        while (!scanner.isAtEnd()) {
            const c = scanner.advance();
            if (c === '\\') {
                if (scanner.isAtEnd())
                    break;
                const next = scanner.advance();
                if (next === 'n')
                    result += '\n';
                else if (next === 't')
                    result += '\t';
                else if (next === 'r')
                    result += '\r';
                else
                    result += next;
            }
            else if (c === quote) {
                closed = true;
                break;
            }
            else {
                result += c;
            }
        }
        if (!closed) {
            throw new A2uiExpressionError(`Unclosed string literal: missing closing ${quote}`);
        }
        return result;
    }
    /**
     * Whether the scanner is at the start of a number literal: a digit, a `.`
     * followed by a digit, or a `-` or `+` sign followed by either of those.
     *
     * The grammar has no arithmetic operators, so a sign here can only belong to
     * a literal. A `-` or `.` inside a path such as `a-1` or `a.5` never reaches
     * this check, because the path scanner consumes it as part of the token.
     */
    isNumberStart(scanner) {
        let offset = 0;
        if (scanner.peek() === '-' || scanner.peek() === '+')
            offset = 1;
        if (this.isDigit(scanner.peek(offset)))
            return true;
        return scanner.peek(offset) === '.' && this.isDigit(scanner.peek(offset + 1));
    }
    parseNumberLiteral(scanner) {
        const start = scanner.pos;
        if (scanner.peek() === '-' || scanner.peek() === '+') {
            scanner.advance();
        }
        while (!scanner.isAtEnd() && (this.isDigit(scanner.peek()) || scanner.peek() === '.')) {
            scanner.advance();
        }
        this.skipExponent(scanner);
        const text = scanner.input.substring(start, scanner.pos);
        if (!NUMBER_LITERAL.test(text)) {
            throw new A2uiExpressionError(`Invalid number literal: '${text}'`);
        }
        const value = Number(text);
        if (!Number.isFinite(value)) {
            throw new A2uiExpressionError(`Number literal is out of range: '${text}'`);
        }
        return value === 0 ? 0 : value;
    }
    /**
     * Consumes an exponent suffix (`e` or `E`, an optional sign, then digits)
     * if one is present.
     *
     * A malformed exponent such as `1e` or `1e+` is still consumed, so that
     * `parseNumberLiteral` reports it as an invalid literal instead of leaving
     * trailing characters behind.
     */
    skipExponent(scanner) {
        if (scanner.isAtEnd() || (scanner.peek() !== 'e' && scanner.peek() !== 'E')) {
            return;
        }
        scanner.advance();
        if (!scanner.isAtEnd() && (scanner.peek() === '+' || scanner.peek() === '-')) {
            scanner.advance();
        }
        while (!scanner.isAtEnd() && this.isDigit(scanner.peek())) {
            scanner.advance();
        }
    }
    isDigit(c) {
        return c >= '0' && c <= '9';
    }
}
/**
 * The maximum allowed recursion depth for nested expressions, which bounds
 * the work a payload can demand of the parser and keeps it off the stack
 * limit.
 *
 * Every engine uses the same number: `ExpressionParser.MAX_DEPTH` in Python
 * and `ExpressionParser.maxDepth` in Swift. They must agree, or an
 * expression one engine accepts the other rejects.
 */
ExpressionParser.MAX_DEPTH = 100;
const XID_CONTINUE_REGEX = new RegExp('^\\p{XID_Continue}$', 'u');
function isIdContinue(input) {
    if (Array.from(input).length !== 1) {
        return false;
    }
    return XID_CONTINUE_REGEX.test(input);
}
class Scanner {
    constructor(input) {
        this.input = input;
        this.pos = 0;
    }
    isAtEnd() {
        return this.pos >= this.input.length;
    }
    peek(offset = 0) {
        const targetPos = this.pos + offset;
        if (targetPos >= this.input.length)
            return '\0';
        // 1. Get the numeric 32-bit code point at the target index
        const codePoint = this.input.codePointAt(targetPos);
        if (codePoint === undefined)
            return '\0';
        // 2. Convert that code point back to its full string representation.
        // String.fromCodePoint correctly reconstructs surrogate pairs automatically.
        return String.fromCodePoint(codePoint);
    }
    advance(count) {
        const step = count ?? (this.peek() === '\0' ? 1 : this.peek().length);
        const char = this.input.substring(this.pos, this.pos + step);
        this.pos += step;
        return char;
    }
    match(expected) {
        if (this.peek() === expected) {
            this.advance();
            return true;
        }
        return false;
    }
    matches(expected) {
        if (this.input.startsWith(expected, this.pos)) {
            return true;
        }
        return false;
    }
    matchesString(expected) {
        return this.peek() === expected;
    }
    matchesKeyword(keyword) {
        if (this.input.startsWith(keyword, this.pos)) {
            const next = this.peek(keyword.length);
            if (!isIdContinue(next)) {
                this.advance(keyword.length);
                return true;
            }
        }
        return false;
    }
    skipWhitespace() {
        while (!this.isAtEnd() && /\s/.test(this.peek())) {
            this.advance();
        }
    }
}
//# sourceMappingURL=expression_parser.js.map