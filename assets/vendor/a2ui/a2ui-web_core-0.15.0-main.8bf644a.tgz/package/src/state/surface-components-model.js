/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { EventEmitter } from '../common/events.js';
import { A2uiIntegrityError, A2uiRecursionError, A2uiStateError, A2uiValidationError, } from '../errors.js';
import { Catalog } from '../catalog/types.js';
import { getComponentReferences, MAX_GLOBAL_DEPTH, } from '../validation/integrity-checker.js';
/**
 * Collection model of components on a surface supporting topology validation and cycle detection.
 */
export class SurfaceComponentsModel {
    /**
     * Initializes a new `SurfaceComponentsModel` instance.
     *
     * @param catalogOrRefMap Optional Catalog or precomputed ComponentRefMap used for schema-driven child reference extraction.
     */
    constructor(catalogOrRefMap) {
        this.components = new Map();
        this._onCreated = new EventEmitter();
        this._onDeleted = new EventEmitter();
        /** Event source firing when a new component is added to the model. */
        this.onCreated = this._onCreated;
        /** Event source firing when a component is removed from the model. */
        this.onDeleted = this._onDeleted;
        if (catalogOrRefMap) {
            this.setCatalog(catalogOrRefMap);
        }
    }
    /**
     * Associates a catalog or reference map with this model for schema-driven child detection.
     *
     * @param catalogOrRefMap Catalog instance or ComponentRefMap.
     */
    setCatalog(catalogOrRefMap) {
        this.refMap =
            catalogOrRefMap instanceof Catalog ? catalogOrRefMap.componentRefMap : catalogOrRefMap;
    }
    /**
     * Retrieves a component by its ID.
     *
     * @param id The ID of the component to retrieve.
     * @returns The component model, or undefined if not found.
     */
    get(id) {
        return this.components.get(id);
    }
    /**
     * Returns a copy of the internal component map.
     *
     * @returns Map of component models keyed by component ID.
     */
    getAll() {
        return new Map(this.components);
    }
    /**
     * Checks whether a component with the specified ID exists in the model.
     *
     * @param id Component identifier to check.
     * @returns Whether the component exists in the model.
     */
    has(id) {
        return this.components.has(id);
    }
    /**
     * Returns an iterator over the component ID and model entries.
     */
    get entries() {
        return this.components.entries();
    }
    /**
     * Returns an iterator over all component IDs in the model.
     */
    get keys() {
        return this.components.keys();
    }
    /**
     * Returns an iterator over all component models in the model.
     */
    get values() {
        return this.components.values();
    }
    /**
     * Total number of components in the model.
     */
    get size() {
        return this.components.size;
    }
    /**
     * Returns a readonly map of all active components in the model.
     */
    get componentsMap() {
        return this.components;
    }
    /**
     * Adds a component to the model.
     * Throws an error if a component with the same ID already exists.
     *
     * @param component The component to add.
     */
    addComponent(component) {
        if (this.components.has(component.id)) {
            throw new A2uiStateError(`Component with id '${component.id}' already exists.`);
        }
        this.components.set(component.id, component);
        this._onCreated.emit(component);
    }
    /**
     * Adds a component to the model at a position in its order.
     *
     * The model holds its components in the order they were added, and iteration, topology
     * checks and their error messages follow it. This puts the component where `index` says
     * instead of last, as when an undo restores a component that an update replaced: the
     * replacement went last, the restored component goes back where it was. Inserting before
     * the last position rebuilds the order, so it takes time in proportion to the components
     * the model holds. Like `addComponent`, it fires `onCreated`.
     *
     * @param index How many components come before it. An index at or past the end adds it
     *     last.
     * @param component The component to add.
     * @throws {A2uiStateError} If a component with the same ID already exists.
     */
    insertComponent(index, component) {
        if (this.components.has(component.id)) {
            throw new A2uiStateError(`Component with id '${component.id}' already exists.`);
        }
        if (index < this.components.size) {
            // Re-adds the components after the position, so the map the model exposes through
            // `componentsMap` stays the same object.
            const after = [...this.components].slice(Math.max(0, index));
            for (const [id] of after)
                this.components.delete(id);
            this.components.set(component.id, component);
            for (const [id, existing] of after)
                this.components.set(id, existing);
        }
        else {
            this.components.set(component.id, component);
        }
        this._onCreated.emit(component);
    }
    /**
     * Removes a component from the model by its ID.
     * Disposes of the component upon removal.
     *
     * @param id The ID of the component to remove.
     */
    removeComponent(id) {
        const component = this.components.get(id);
        if (component) {
            this.components.delete(id);
            component.dispose();
            this._onDeleted.emit(id);
        }
    }
    /**
     * Extracts child component references for a given component identifier.
     *
     * @param componentId The ID of the component whose children should be resolved.
     * @returns Array of tuples containing `[referencedId, propertyPath]`.
     */
    getChildReferences(componentId) {
        const comp = this.components.get(componentId);
        if (!comp)
            return [];
        const refMap = comp.catalog.components.size
            ? comp.catalog.componentRefMap
            : (this.refMap ?? comp.catalog.componentRefMap);
        return Array.from(getComponentReferences(comp.componentTree, refMap));
    }
    /**
     * Returns array of referenced child component IDs for a given component identifier.
     *
     * @param componentId The ID of the component whose child IDs should be retrieved.
     * @returns Array of unique child component IDs.
     */
    getChildIds(componentId) {
        return this.getChildReferences(componentId).map(([refId]) => refId);
    }
    /**
     * Detects self-references, circular dependencies, and exceeds depth limits via DFS.
     *
     * @param options Configuration specifying root node, max depth, or allowing missing root.
     * @returns Set of visited component identifiers.
     * @throws {A2uiRecursionError} When self-reference, cycle, or max depth limit is exceeded.
     */
    detectCycles(options = {}) {
        const rootId = options.rootId ?? 'root';
        const maxDepth = options.maxDepth ?? MAX_GLOBAL_DEPTH;
        const allowMissingRoot = options.allowMissingRoot ?? false;
        // 1. Check for immediate self-references across all components
        for (const comp of this.components.values()) {
            for (const [childId, fieldName] of this.getChildReferences(comp.id)) {
                if (childId === comp.id) {
                    throw new A2uiRecursionError(`Circular reference detected: Component '${comp.id}' references itself in field '${fieldName}' (Self-reference detected)`);
                }
            }
        }
        const visited = new Set();
        const recursionStack = new Set();
        const dfs = (nodeId, depth) => {
            if (depth > maxDepth) {
                throw new A2uiRecursionError(`Global recursion limit exceeded: logical depth > ${maxDepth}`);
            }
            visited.add(nodeId);
            recursionStack.add(nodeId);
            const childIds = this.getChildIds(nodeId);
            for (const childId of childIds) {
                if (!this.components.has(childId)) {
                    continue;
                }
                if (!visited.has(childId)) {
                    dfs(childId, depth + 1);
                }
                else if (recursionStack.has(childId)) {
                    throw new A2uiRecursionError(`Circular reference detected involving component '${childId}'`);
                }
            }
            recursionStack.delete(nodeId);
        };
        if (allowMissingRoot) {
            const sortedIds = Array.from(this.components.keys()).sort();
            for (const nodeId of sortedIds) {
                if (!visited.has(nodeId)) {
                    dfs(nodeId, 0);
                }
            }
        }
        else {
            if (this.components.has(rootId)) {
                dfs(rootId, 0);
            }
        }
        return visited;
    }
    /**
     * Validates topology, completeness, and references across the component hierarchy.
     *
     * @param options Validation settings (allowMissingRoot, allowDanglingReferences, allowOrphanComponents).
     * @throws {A2uiIntegrityError} If missing root, dangling references, or orphan components exist.
     * @throws {A2uiRecursionError} If self-reference, cycle, or depth limit is detected.
     */
    validateTopology(options = {}) {
        if (this.components.size === 0)
            return;
        const rootId = options.rootId ?? 'root';
        const allowMissingRoot = options.allowMissingRoot ?? false;
        const allowDanglingReferences = options.allowDanglingReferences ?? false;
        const allowOrphanComponents = options.allowOrphanComponents ?? false;
        // 1. Missing Root Check
        if (!allowMissingRoot && !this.components.has(rootId)) {
            throw new A2uiIntegrityError(`Missing root component: No component has id='${rootId}'`);
        }
        // 2. Dangling References Check
        if (!allowDanglingReferences) {
            for (const comp of this.components.values()) {
                for (const [childId, fieldName] of this.getChildReferences(comp.id)) {
                    if (!this.components.has(childId)) {
                        throw new A2uiIntegrityError(`Component '${comp.id}' references non-existent component '${childId}' in field '${fieldName}' (Dangling reference '${childId}' in component '${comp.id}')`);
                    }
                }
            }
        }
        // 3. Cycle & Depth Detection
        const visited = this.detectCycles({ rootId, allowMissingRoot, maxDepth: options.maxDepth });
        // 4. Orphan Components Check
        if (!allowOrphanComponents && !allowMissingRoot) {
            if (visited.size < this.components.size) {
                const orphans = Array.from(this.components.keys())
                    .filter(id => !visited.has(id))
                    .sort();
                if (orphans.length > 0) {
                    throw new A2uiIntegrityError(`Component '${orphans[0]}' is not reachable from '${rootId}' (Orphaned component '${orphans[0]}' is not reachable from root)`);
                }
            }
        }
    }
    /**
     * Performs non-throwing validation of references and topology across the component graph.
     * Returns an array containing the first validation error encountered, or an empty array if valid.
     *
     * @param options Validation options.
     * @returns Array of validation error objects.
     */
    validateReferences(options = {}) {
        const errors = [];
        try {
            this.validateTopology(options);
        }
        catch (err) {
            if (err instanceof A2uiValidationError) {
                errors.push(err);
            }
            else if (err instanceof Error) {
                errors.push(new A2uiValidationError(err.message));
            }
        }
        return errors;
    }
    /**
     * Disposes the model, clearing all components and update event emitters.
     */
    dispose() {
        const deletedIds = Array.from(this.components.keys());
        for (const component of this.components.values()) {
            component.dispose();
        }
        this.components.clear();
        for (const id of deletedIds) {
            this._onDeleted.emit(id);
        }
        this._onCreated.dispose();
        this._onDeleted.dispose();
    }
}
//# sourceMappingURL=surface-components-model.js.map