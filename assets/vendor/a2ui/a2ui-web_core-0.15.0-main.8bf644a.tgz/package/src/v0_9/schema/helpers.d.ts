import { z } from 'zod';
import { type ChildRefKind, type RefSchemaOptions, markChildRef, childRefKindOf } from '../../types/child-ref-helpers.js';
import { ChildListSchema, ComponentIdSchema } from './common-types.js';
export { type ChildRefKind, type RefSchemaOptions, markChildRef, childRefKindOf };
export declare const TemplateChildListSchema: z.ZodObject<{
    componentId: z.ZodLazy<z.ZodString>;
    path: z.ZodString;
}, "strip", z.ZodTypeAny, {
    path: string;
    componentId: string;
}, {
    path: string;
    componentId: string;
}>;
export type TemplateChildList = z.infer<typeof TemplateChildListSchema>;
export declare function componentId(options?: RefSchemaOptions): typeof ComponentIdSchema;
export declare function dynamicString(description?: string): z.ZodUnion<[z.ZodString, z.ZodObject<{
    path: z.ZodString;
}, "strict", z.ZodTypeAny, {
    path: string;
}, {
    path: string;
}>, z.ZodType<import("./common-types.js").FunctionCall, z.ZodTypeDef, import("./common-types.js").FunctionCall>]>;
export declare function dynamicNumber(description?: string): z.ZodUnion<[z.ZodNumber, z.ZodObject<{
    path: z.ZodString;
}, "strict", z.ZodTypeAny, {
    path: string;
}, {
    path: string;
}>, z.ZodType<import("./common-types.js").FunctionCall, z.ZodTypeDef, import("./common-types.js").FunctionCall>]>;
export declare function dynamicBoolean(description?: string): z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
    path: z.ZodString;
}, "strict", z.ZodTypeAny, {
    path: string;
}, {
    path: string;
}>, z.ZodType<import("./common-types.js").FunctionCall, z.ZodTypeDef, import("./common-types.js").FunctionCall>]>;
export declare function dynamicValue(description?: string): z.ZodType<import("./common-types.js").DynamicValue, z.ZodTypeDef, import("./common-types.js").DynamicValue>;
export declare function dynamicStringList(description?: string): z.ZodUnion<[z.ZodArray<z.ZodString, "many">, z.ZodObject<{
    path: z.ZodString;
}, "strict", z.ZodTypeAny, {
    path: string;
}, {
    path: string;
}>, z.ZodType<import("./common-types.js").FunctionCall, z.ZodTypeDef, import("./common-types.js").FunctionCall>]>;
export declare function childList(options?: RefSchemaOptions): typeof ChildListSchema;
export declare const AnyComponentSchema: z.ZodObject<{
    component: z.ZodString;
    id: z.ZodOptional<z.ZodLazy<z.ZodString>>;
    weight: z.ZodOptional<z.ZodNumber>;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    component: z.ZodString;
    id: z.ZodOptional<z.ZodLazy<z.ZodString>>;
    weight: z.ZodOptional<z.ZodNumber>;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    component: z.ZodString;
    id: z.ZodOptional<z.ZodLazy<z.ZodString>>;
    weight: z.ZodOptional<z.ZodNumber>;
}, z.ZodTypeAny, "passthrough">>;
export type AnyComponent = z.infer<typeof AnyComponentSchema>;
export type A2uiClientCapabilities = {
    'v0.9': any;
    'v0.9.1'?: any;
} | {
    'v0.9'?: any;
    'v0.9.1': any;
};
//# sourceMappingURL=helpers.d.ts.map