import { z } from 'zod';
export type JsonSchema = Record<string, unknown>;
export declare const FunctionDefinitionSchema: z.ZodObject<{
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    parameters: z.ZodRecord<z.ZodString, z.ZodAny>;
    returnType: z.ZodEnum<["string", "number", "boolean", "array", "object", "any", "void"]>;
}, "strict", z.ZodTypeAny, {
    name: string;
    returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
    parameters: Record<string, any>;
    description?: string | undefined;
}, {
    name: string;
    returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
    parameters: Record<string, any>;
    description?: string | undefined;
}>;
export type FunctionDefinition = z.infer<typeof FunctionDefinitionSchema>;
export declare const InlineCatalogSchema: z.ZodObject<{
    catalogId: z.ZodString;
    components: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>>;
    functions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        parameters: z.ZodRecord<z.ZodString, z.ZodAny>;
        returnType: z.ZodEnum<["string", "number", "boolean", "array", "object", "any", "void"]>;
    }, "strict", z.ZodTypeAny, {
        name: string;
        returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
        parameters: Record<string, any>;
        description?: string | undefined;
    }, {
        name: string;
        returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
        parameters: Record<string, any>;
        description?: string | undefined;
    }>, "many">>;
    theme: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>>;
}, "strict", z.ZodTypeAny, {
    catalogId: string;
    components?: Record<string, Record<string, any>> | undefined;
    theme?: Record<string, Record<string, any>> | undefined;
    functions?: {
        name: string;
        returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
        parameters: Record<string, any>;
        description?: string | undefined;
    }[] | undefined;
}, {
    catalogId: string;
    components?: Record<string, Record<string, any>> | undefined;
    theme?: Record<string, Record<string, any>> | undefined;
    functions?: {
        name: string;
        returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
        parameters: Record<string, any>;
        description?: string | undefined;
    }[] | undefined;
}>;
export type InlineCatalog = z.infer<typeof InlineCatalogSchema>;
export declare const A2uiVersionCapabilitiesSchema: z.ZodObject<{
    supportedCatalogIds: z.ZodArray<z.ZodString, "many">;
    inlineCatalogs: z.ZodOptional<z.ZodArray<z.ZodObject<{
        catalogId: z.ZodString;
        components: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>>;
        functions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            description: z.ZodOptional<z.ZodString>;
            parameters: z.ZodRecord<z.ZodString, z.ZodAny>;
            returnType: z.ZodEnum<["string", "number", "boolean", "array", "object", "any", "void"]>;
        }, "strict", z.ZodTypeAny, {
            name: string;
            returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
            parameters: Record<string, any>;
            description?: string | undefined;
        }, {
            name: string;
            returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
            parameters: Record<string, any>;
            description?: string | undefined;
        }>, "many">>;
        theme: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodAny>>>;
    }, "strict", z.ZodTypeAny, {
        catalogId: string;
        components?: Record<string, Record<string, any>> | undefined;
        theme?: Record<string, Record<string, any>> | undefined;
        functions?: {
            name: string;
            returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
            parameters: Record<string, any>;
            description?: string | undefined;
        }[] | undefined;
    }, {
        catalogId: string;
        components?: Record<string, Record<string, any>> | undefined;
        theme?: Record<string, Record<string, any>> | undefined;
        functions?: {
            name: string;
            returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
            parameters: Record<string, any>;
            description?: string | undefined;
        }[] | undefined;
    }>, "many">>;
}, "strip", z.ZodTypeAny, {
    supportedCatalogIds: string[];
    inlineCatalogs?: {
        catalogId: string;
        components?: Record<string, Record<string, any>> | undefined;
        theme?: Record<string, Record<string, any>> | undefined;
        functions?: {
            name: string;
            returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
            parameters: Record<string, any>;
            description?: string | undefined;
        }[] | undefined;
    }[] | undefined;
}, {
    supportedCatalogIds: string[];
    inlineCatalogs?: {
        catalogId: string;
        components?: Record<string, Record<string, any>> | undefined;
        theme?: Record<string, Record<string, any>> | undefined;
        functions?: {
            name: string;
            returnType: "string" | "number" | "boolean" | "object" | "array" | "void" | "any";
            parameters: Record<string, any>;
            description?: string | undefined;
        }[] | undefined;
    }[] | undefined;
}>;
export type A2uiVersionCapabilities = z.infer<typeof A2uiVersionCapabilitiesSchema>;
//# sourceMappingURL=client-capabilities.d.ts.map