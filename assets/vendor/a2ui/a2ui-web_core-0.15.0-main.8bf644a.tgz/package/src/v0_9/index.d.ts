/**
 * Core rendering and state management logic for A2UI v0.9.
 *
 * This module exports the fundamental building blocks for building web-based A2UI renderers,
 * including the data model, component model, and expression parsing logic.
 */
export * from '../catalog/function_invoker.js';
export * from '../catalog/types.js';
export * from '../common/events.js';
export { validateMetadata, cloneMetadata, metadataEquals, type A2uiMetadata, type Extensions, type ActionDispatchOptions, } from '../common/metadata.js';
export * from '../processing/message-processor.js';
export { mapErrorToRendererMessage, extractEnvelopeErrorContext, normalizeJsonPointer, type RendererErrorMessage, type A2uiRendererError, type ValidationFailedErrorBody, type GenericErrorBody, type ErrorEnvelopeContext, } from '../processing/message-error-mapper.js';
export * from '../resolution/index.js';
export * from './schema/index.js';
export * from './standard_defs.js';
export * from '../state/component-model.js';
export * from '../state/data-model.js';
export * from '../state/surface-components-model.js';
export * from '../state/surface-group-model.js';
export * from '../state/surface-model.js';
export * from '../errors.js';
export type { ResolvedChildRef } from '../resolution/index.js';
export type { DataBindingType, FunctionCallType } from '../types/common-types.js';
export { MAX_FUNCTION_CALL_ARGS } from '../types/helpers.js';
export * from './basic_catalog/index.js';
export { MAX_REGEX_PATTERN_CODE_POINTS, MAX_REGEX_VALUE_CODE_POINTS, RegexSyntaxError, analyzeRegex, checkRegexSafety, parseRegexSubset, type AnchorKind, type CodePointRange, type RegexAnalysisResult, type RegexNode, type RegexRejection, } from '../common/regex_subset.js';
export * from '../validation/integrity-checker.js';
export { 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
injectBasicCatalogStyles, 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
computeColorVariant, } from '../universal/basic_catalog/styles/default.js';
export type { 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
ColorVariantLightDarkOptions, 
/** @deprecated Import from `@a2ui/web_core/v0_9/basic_catalog` instead. */
ColorVariantHoverOptions, } from '../universal/basic_catalog/styles/default.js';
export { type Signal, effect, signal, computed, getValue, peekValue, batchWrite, isSignal, setValue, setSignalImplementation, _PRIVATE_DEFAULT_SIGNAL_IMPLEMENTATION, type SignalImplementations, } from '../reactivity/signals.js';
export declare const Schemas: {
    A2uiMessageSchemaRaw: {
        $schema: string;
        $id: string;
        title: string;
        description: string;
        type: string;
        oneOf: {
            $ref: string;
        }[];
        $defs: {
            CreateSurfaceMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    createSurface: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            catalogId: {
                                type: string;
                                description: string;
                            };
                            theme: {
                                $ref: string;
                                description: string;
                            };
                            sendDataModel: {
                                type: string;
                                description: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            UpdateComponentsMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    updateComponents: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            components: {
                                type: string;
                                description: string;
                                minItems: number;
                                items: {
                                    $ref: string;
                                };
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            UpdateDataModelMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    updateDataModel: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                            path: {
                                type: string;
                                description: string;
                            };
                            value: {
                                description: string;
                                additionalProperties: boolean;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
            DeleteSurfaceMessage: {
                type: string;
                properties: {
                    version: {
                        const: string;
                    };
                    deleteSurface: {
                        type: string;
                        description: string;
                        properties: {
                            surfaceId: {
                                type: string;
                                description: string;
                            };
                        };
                        required: string[];
                        additionalProperties: boolean;
                    };
                };
                required: string[];
                additionalProperties: boolean;
            };
        };
    };
};
//# sourceMappingURL=index.d.ts.map