import { z } from 'zod';
/**
 * Checks that the value is not null, undefined, or empty.
 */
export declare const RequiredApi: {
    name: "required";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodEffects<z.ZodAny, any, any>;
    }, "strip", z.ZodTypeAny, {
        value?: any;
    }, {
        value?: any;
    }>;
};
/**
 * Checks that the value matches a regular expression string.
 */
export declare const RegexApi: {
    name: "regex";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        pattern: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        pattern: string;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        pattern: string;
    }>;
};
/**
 * Checks string length constraints.
 */
export declare const LengthApi: {
    name: "length";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        min: z.ZodOptional<z.ZodNumber>;
        max: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }>;
};
/**
 * Checks numeric range constraints.
 */
export declare const NumericApi: {
    name: "numeric";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        min: z.ZodOptional<z.ZodNumber>;
        max: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }>;
};
/**
 * Checks that the value is a valid email address.
 */
export declare const EmailApi: {
    name: "email";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
};
/**
 * Performs string interpolation of data model values and other functions in the catalog functions list and returns the resulting string. The value string can contain interpolated expressions in the `${expression}` format. Supported expression types include: JSON Pointer paths to the data model (e.g., `${/absolute/path}` or `${relative/path}`), and client-side function calls (e.g., `${now()}`). Function arguments must be named (e.g., `${formatDate(value:${/currentDate}, format:'MM-dd')}`). To include a literal `${` sequence, escape it as `\${`.
 */
export declare const FormatStringApi: {
    name: "formatString";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
};
/**
 * Formats a number with the specified grouping and decimal precision.
 */
export declare const FormatNumberApi: {
    name: "formatNumber";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        decimals: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        grouping: z.ZodOptional<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
};
/**
 * Formats a number as a currency string.
 */
export declare const FormatCurrencyApi: {
    name: "formatCurrency";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        currency: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        decimals: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        grouping: z.ZodOptional<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        currency: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        currency: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
};
/**
 * Formats a timestamp into a string using a pattern.
 */
export declare const FormatDateApi: {
    name: "formatDate";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodType<import("../../index.js").DynamicValue, z.ZodTypeDef, import("../../index.js").DynamicValue>;
        format: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: import("../../index.js").DynamicValue;
        format: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: import("../../index.js").DynamicValue;
        format: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
};
/**
 * Returns a localized string based on the Common Locale Data Repository (CLDR) plural category of the count (zero, one, two, few, many, other). Requires an 'other' fallback. For English, just use 'one' and 'other'.
 */
export declare const PluralizeApi: {
    name: "pluralize";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        zero: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        one: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        two: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        few: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        many: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        other: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        other: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        many?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        zero?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        one?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        two?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        few?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        other: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        many?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        zero?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        one?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        two?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        few?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
};
/**
 * Opens the specified URL in a browser or handler. This function has no return value.
 */
export declare const OpenUrlApi: {
    name: "openUrl";
    returnType: "void";
    description: string;
    schema: z.ZodObject<{
        url: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        url: string;
    }, {
        url: string;
    }>;
};
/**
 * Performs a logical AND operation on a list of boolean values.
 */
export declare const AndApi: {
    name: "and";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        values: z.ZodArray<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>, "many">;
    }, "strip", z.ZodTypeAny, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }>;
};
/**
 * Performs a logical OR operation on a list of boolean values.
 */
export declare const OrApi: {
    name: "or";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        values: z.ZodArray<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>, "many">;
    }, "strip", z.ZodTypeAny, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }>;
};
/**
 * Performs a logical NOT operation on a boolean value.
 */
export declare const NotApi: {
    name: "not";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
};
export declare const BASIC_FUNCTION_APIS: ({
    name: "required";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodEffects<z.ZodAny, any, any>;
    }, "strip", z.ZodTypeAny, {
        value?: any;
    }, {
        value?: any;
    }>;
} | {
    name: "regex";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        pattern: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        pattern: string;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        pattern: string;
    }>;
} | {
    name: "length";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        min: z.ZodOptional<z.ZodNumber>;
        max: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }>;
} | {
    name: "numeric";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        min: z.ZodOptional<z.ZodNumber>;
        max: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }>;
} | {
    name: "email";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
} | {
    name: "formatString";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
} | {
    name: "formatNumber";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        decimals: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        grouping: z.ZodOptional<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
} | {
    name: "formatCurrency";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        currency: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        decimals: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        grouping: z.ZodOptional<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        currency: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        currency: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
} | {
    name: "formatDate";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodType<import("../../index.js").DynamicValue, z.ZodTypeDef, import("../../index.js").DynamicValue>;
        format: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: import("../../index.js").DynamicValue;
        format: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: import("../../index.js").DynamicValue;
        format: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
} | {
    name: "pluralize";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        zero: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        one: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        two: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        few: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        many: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        other: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        other: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        many?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        zero?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        one?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        two?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        few?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        other: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        many?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        zero?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        one?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        two?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        few?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
} | {
    name: "openUrl";
    returnType: "void";
    description: string;
    schema: z.ZodObject<{
        url: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        url: string;
    }, {
        url: string;
    }>;
} | {
    name: "and";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        values: z.ZodArray<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>, "many">;
    }, "strip", z.ZodTypeAny, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }>;
} | {
    name: "or";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        values: z.ZodArray<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>, "many">;
    }, "strip", z.ZodTypeAny, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }>;
} | {
    name: "not";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
})[];
export declare const V09_SPEC_FUNCTION_APIS: ({
    name: "required";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodEffects<z.ZodAny, any, any>;
    }, "strip", z.ZodTypeAny, {
        value?: any;
    }, {
        value?: any;
    }>;
} | {
    name: "regex";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        pattern: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        pattern: string;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        pattern: string;
    }>;
} | {
    name: "length";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        min: z.ZodOptional<z.ZodNumber>;
        max: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }>;
} | {
    name: "numeric";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        min: z.ZodOptional<z.ZodNumber>;
        max: z.ZodOptional<z.ZodNumber>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        min?: number | undefined;
        max?: number | undefined;
    }>;
} | {
    name: "email";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
} | {
    name: "formatString";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
} | {
    name: "formatNumber";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        decimals: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        grouping: z.ZodOptional<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
} | {
    name: "formatCurrency";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        currency: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        decimals: z.ZodOptional<z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        grouping: z.ZodOptional<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        currency: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        currency: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        decimals?: number | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        grouping?: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
} | {
    name: "formatDate";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodType<import("../../index.js").DynamicValue, z.ZodTypeDef, import("../../index.js").DynamicValue>;
        format: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: import("../../index.js").DynamicValue;
        format: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: import("../../index.js").DynamicValue;
        format: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
} | {
    name: "pluralize";
    returnType: "string";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodNumber, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
        zero: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        one: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        two: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        few: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        many: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        other: z.ZodUnion<[z.ZodString, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        other: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        many?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        zero?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        one?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        two?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        few?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        value: number | {
            path: string;
        } | import("../../index.js").FunctionCall;
        other: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
        many?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        zero?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        one?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        two?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        few?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>;
} | {
    name: "openUrl";
    returnType: "void";
    description: string;
    schema: z.ZodObject<{
        url: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        url: string;
    }, {
        url: string;
    }>;
} | {
    name: "and";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        values: z.ZodArray<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>, "many">;
    }, "strip", z.ZodTypeAny, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }>;
} | {
    name: "or";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        values: z.ZodArray<z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>, "many">;
    }, "strip", z.ZodTypeAny, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }, {
        values: (boolean | {
            path: string;
        } | import("../../index.js").FunctionCall)[];
    }>;
} | {
    name: "not";
    returnType: "boolean";
    description: string;
    schema: z.ZodObject<{
        value: z.ZodUnion<[z.ZodBoolean, z.ZodObject<{
            path: z.ZodString;
        }, "strict", z.ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, z.ZodType<import("../../index.js").FunctionCall, z.ZodTypeDef, import("../../index.js").FunctionCall>]>;
    }, "strip", z.ZodTypeAny, {
        value: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>;
})[];
//# sourceMappingURL=basic_functions_api.d.ts.map