export declare const A2uiAudioPlayer: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    url: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    url: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    description?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}, {
    url: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    description?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}>>;
export declare const A2uiButton: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    checks: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodBoolean, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
        message: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>, "many">>;
    child: import("zod").ZodString;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["default", "primary", "borderless"]>>>;
    action: import("zod").ZodUnion<[import("zod").ZodObject<{
        event: import("zod").ZodObject<{
            name: import("zod").ZodString;
            context: import("zod").ZodOptional<import("zod").ZodRecord<import("zod").ZodString, import("zod").ZodType<import("../../index.js").DynamicValue, import("zod").ZodTypeDef, import("../../index.js").DynamicValue>>>;
        }, "strict", import("zod").ZodTypeAny, {
            name: string;
            context?: Record<string, import("../../index.js").DynamicValue> | undefined;
        }, {
            name: string;
            context?: Record<string, import("../../index.js").DynamicValue> | undefined;
        }>;
    }, "strict", import("zod").ZodTypeAny, {
        event: {
            name: string;
            context?: Record<string, import("../../index.js").DynamicValue> | undefined;
        };
    }, {
        event: {
            name: string;
            context?: Record<string, import("../../index.js").DynamicValue> | undefined;
        };
    }>, import("zod").ZodObject<{
        functionCall: import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>;
    }, "strict", import("zod").ZodTypeAny, {
        functionCall: import("../../index.js").FunctionCall;
    }, {
        functionCall: import("../../index.js").FunctionCall;
    }>]>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    child: string;
    action: {
        event: {
            name: string;
            context?: Record<string, import("../../index.js").DynamicValue> | undefined;
        };
    } | {
        functionCall: import("../../index.js").FunctionCall;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    variant?: "default" | "primary" | "borderless" | undefined;
}, {
    child: string;
    action: {
        event: {
            name: string;
            context?: Record<string, import("../../index.js").DynamicValue> | undefined;
        };
    } | {
        functionCall: import("../../index.js").FunctionCall;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    variant?: "default" | "primary" | "borderless" | undefined;
}>>;
export declare const A2uiCard: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    child: import("zod").ZodString;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    child: string;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}, {
    child: string;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}>>;
export declare const A2uiCheckBox: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    checks: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodBoolean, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
        message: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>, "many">>;
    label: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    value: import("zod").ZodUnion<[import("zod").ZodBoolean, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    value: boolean | {
        path: string;
    } | import("../../index.js").FunctionCall;
    label: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
}, {
    value: boolean | {
        path: string;
    } | import("../../index.js").FunctionCall;
    label: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
}>>;
export declare const A2uiChoicePicker: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    checks: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodBoolean, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
        message: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>, "many">>;
    label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["multipleSelection", "mutuallyExclusive"]>>>;
    options: import("zod").ZodArray<import("zod").ZodObject<{
        label: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
        value: import("zod").ZodString;
    }, "strip", import("zod").ZodTypeAny, {
        value: string;
        label: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        value: string;
        label: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>, "many">;
    value: import("zod").ZodUnion<[import("zod").ZodArray<import("zod").ZodString, "many">, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    displayStyle: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["checkbox", "chips"]>>>;
    filterable: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodBoolean>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    value: string[] | {
        path: string;
    } | import("../../index.js").FunctionCall;
    options: {
        value: string;
        label: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[];
    label?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    filterable?: boolean | undefined;
    variant?: "multipleSelection" | "mutuallyExclusive" | undefined;
    displayStyle?: "checkbox" | "chips" | undefined;
}, {
    value: string[] | {
        path: string;
    } | import("../../index.js").FunctionCall;
    options: {
        value: string;
        label: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[];
    label?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    filterable?: boolean | undefined;
    variant?: "multipleSelection" | "mutuallyExclusive" | undefined;
    displayStyle?: "checkbox" | "chips" | undefined;
}>>;
export declare const A2uiColumn: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    children: import("zod").ZodUnion<[import("zod").ZodArray<import("zod").ZodString, "many">, import("zod").ZodObject<{
        componentId: import("zod").ZodString;
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
        componentId: string;
    }, {
        path: string;
        componentId: string;
    }>]>;
    justify: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["start", "center", "end", "spaceBetween", "spaceAround", "spaceEvenly", "stretch"]>>>;
    align: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["center", "end", "start", "stretch"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}>>;
export declare const A2uiDateTimeInput: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    checks: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodBoolean, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
        message: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>, "many">>;
    value: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    enableDate: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodBoolean>>;
    enableTime: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodBoolean>>;
    min: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    max: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    value: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    label?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    min?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    max?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    enableDate?: boolean | undefined;
    enableTime?: boolean | undefined;
}, {
    value: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    label?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    min?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    max?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    enableDate?: boolean | undefined;
    enableTime?: boolean | undefined;
}>>;
export declare const A2uiDivider: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    axis: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["horizontal", "vertical"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    axis?: "horizontal" | "vertical" | undefined;
}, {
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    axis?: "horizontal" | "vertical" | undefined;
}>>;
export declare const A2uiIcon: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    name: import("zod").ZodUnion<[import("zod").ZodEnum<["accountCircle", "add", "arrowBack", "arrowForward", "attachFile", "calendarToday", "call", "camera", "check", "close", "delete", "download", "edit", "event", "error", "fastForward", "favorite", "favoriteOff", "folder", "help", "home", "info", "locationOn", "lock", "lockOpen", "mail", "menu", "moreVert", "moreHoriz", "notificationsOff", "notifications", "pause", "payment", "person", "phone", "photo", "play", "print", "refresh", "rewind", "search", "send", "settings", "share", "shoppingCart", "skipNext", "skipPrevious", "star", "starHalf", "starOff", "stop", "upload", "visibility", "visibilityOff", "volumeDown", "volumeMute", "volumeOff", "volumeUp", "warning"]>, import("zod").ZodObject<{
        svgPath: import("zod").ZodString;
    }, "strip", import("zod").ZodTypeAny, {
        svgPath: string;
    }, {
        svgPath: string;
    }>, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>]>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    name: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | {
        path: string;
    } | "stop" | "fastForward" | "pause" | "play" | "rewind" | "skipNext" | "skipPrevious" | "volumeDown" | "volumeMute" | "volumeOff" | "volumeUp" | {
        svgPath: string;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}, {
    name: "call" | "event" | "error" | "accountCircle" | "add" | "arrowBack" | "arrowForward" | "attachFile" | "calendarToday" | "camera" | "check" | "close" | "delete" | "download" | "edit" | "favorite" | "favoriteOff" | "folder" | "help" | "home" | "info" | "locationOn" | "lock" | "lockOpen" | "mail" | "menu" | "moreVert" | "moreHoriz" | "notificationsOff" | "notifications" | "payment" | "person" | "phone" | "photo" | "print" | "refresh" | "search" | "send" | "settings" | "share" | "shoppingCart" | "star" | "starHalf" | "starOff" | "upload" | "visibility" | "visibilityOff" | "warning" | {
        path: string;
    } | "stop" | "fastForward" | "pause" | "play" | "rewind" | "skipNext" | "skipPrevious" | "volumeDown" | "volumeMute" | "volumeOff" | "volumeUp" | {
        svgPath: string;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}>>;
export declare const A2uiImage: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    url: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    fit: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["contain", "cover", "fill", "none", "scaleDown"]>>>;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["icon", "avatar", "smallFeature", "mediumFeature", "largeFeature", "header"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    url: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    description?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    fit?: "fill" | "none" | "contain" | "cover" | "scaleDown" | undefined;
    variant?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
}, {
    url: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    description?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    fit?: "fill" | "none" | "contain" | "cover" | "scaleDown" | undefined;
    variant?: "icon" | "avatar" | "smallFeature" | "mediumFeature" | "largeFeature" | "header" | undefined;
}>>;
export declare const A2uiList: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    children: import("zod").ZodUnion<[import("zod").ZodArray<import("zod").ZodString, "many">, import("zod").ZodObject<{
        componentId: import("zod").ZodString;
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
        componentId: string;
    }, {
        path: string;
        componentId: string;
    }>]>;
    direction: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["vertical", "horizontal"]>>>;
    align: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["start", "center", "end", "stretch"]>>>;
    listStyle: import("zod").ZodOptional<import("zod").ZodEnum<["ordered", "unordered", "none"]>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    direction?: "horizontal" | "vertical" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
    listStyle?: "none" | "ordered" | "unordered" | undefined;
}, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    direction?: "horizontal" | "vertical" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
    listStyle?: "none" | "ordered" | "unordered" | undefined;
}>>;
export declare const A2uiModal: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    trigger: import("zod").ZodString;
    content: import("zod").ZodString;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    trigger: string;
    content: string;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}, {
    trigger: string;
    content: string;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}>>;
export declare const A2uiRow: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    children: import("zod").ZodUnion<[import("zod").ZodArray<import("zod").ZodString, "many">, import("zod").ZodObject<{
        componentId: import("zod").ZodString;
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
        componentId: string;
    }, {
        path: string;
        componentId: string;
    }>]>;
    justify: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["center", "end", "spaceAround", "spaceBetween", "spaceEvenly", "start", "stretch"]>>>;
    align: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["start", "center", "end", "stretch"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}, {
    children: string[] | {
        path: string;
        componentId: string;
    };
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    justify?: "start" | "center" | "end" | "spaceBetween" | "spaceAround" | "spaceEvenly" | "stretch" | undefined;
    align?: "start" | "center" | "end" | "stretch" | undefined;
}>>;
export declare const A2uiSlider: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    checks: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodBoolean, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
        message: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>, "many">>;
    label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    min: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodNumber>>;
    max: import("zod").ZodNumber;
    value: import("zod").ZodUnion<[import("zod").ZodNumber, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    value: number | {
        path: string;
    } | import("../../index.js").FunctionCall;
    max: number;
    label?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    min?: number | undefined;
}, {
    value: number | {
        path: string;
    } | import("../../index.js").FunctionCall;
    max: number;
    label?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    min?: number | undefined;
}>>;
export declare const A2uiTabs: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    tabs: import("zod").ZodArray<import("zod").ZodObject<{
        title: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
        child: import("zod").ZodString;
    }, "strip", import("zod").ZodTypeAny, {
        child: string;
        title: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        child: string;
        title: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>, "many">;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    tabs: {
        child: string;
        title: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[];
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}, {
    tabs: {
        child: string;
        title: string | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[];
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}>>;
export declare const A2uiText: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    text: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["h1", "h2", "h3", "h4", "h5", "caption", "body"]>>>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    text: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    variant?: "h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body" | undefined;
}, {
    text: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
    variant?: "h1" | "h2" | "h3" | "h4" | "h5" | "caption" | "body" | undefined;
}>>;
export declare const A2uiTextField: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    checks: import("zod").ZodOptional<import("zod").ZodArray<import("zod").ZodObject<{
        condition: import("zod").ZodUnion<[import("zod").ZodBoolean, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
        message: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }, {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }>, "many">>;
    label: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    value: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    variant: import("zod").ZodOptional<import("zod").ZodDefault<import("zod").ZodEnum<["longText", "number", "shortText", "obscured"]>>>;
    validationRegexp: import("zod").ZodOptional<import("zod").ZodString>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    label: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    value?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    validationRegexp?: string | undefined;
    variant?: "number" | "shortText" | "longText" | "obscured" | undefined;
}, {
    label: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    value?: string | {
        path: string;
    } | import("../../index.js").FunctionCall | undefined;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    checks?: {
        message: string;
        condition: boolean | {
            path: string;
        } | import("../../index.js").FunctionCall;
    }[] | undefined;
    weight?: number | undefined;
    validationRegexp?: string | undefined;
    variant?: "number" | "shortText" | "longText" | "obscured" | undefined;
}>>;
export declare const A2uiVideo: import("../../universal/index.js").WebComponentImplementation<import("zod").ZodObject<{
    accessibility: import("zod").ZodOptional<import("zod").ZodObject<{
        label: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
        description: import("zod").ZodOptional<import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
            path: import("zod").ZodString;
        }, "strict", import("zod").ZodTypeAny, {
            path: string;
        }, {
            path: string;
        }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>>;
    }, "strip", import("zod").ZodTypeAny, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }, {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    }>>;
    url: import("zod").ZodUnion<[import("zod").ZodString, import("zod").ZodObject<{
        path: import("zod").ZodString;
    }, "strict", import("zod").ZodTypeAny, {
        path: string;
    }, {
        path: string;
    }>, import("zod").ZodType<import("../../index.js").FunctionCall, import("zod").ZodTypeDef, import("../../index.js").FunctionCall>]>;
    weight: import("zod").ZodOptional<import("zod").ZodNumber>;
}, "strict", import("zod").ZodTypeAny, {
    url: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}, {
    url: string | {
        path: string;
    } | import("../../index.js").FunctionCall;
    accessibility?: {
        label?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
        description?: string | {
            path: string;
        } | import("../../index.js").FunctionCall | undefined;
    } | undefined;
    weight?: number | undefined;
}>>;
export { BASIC_COMPONENTS, AudioPlayerApi, ButtonApi, CardApi, CheckBoxApi, ChoicePickerApi, ColumnApi, DateTimeInputApi, DividerApi, IconApi, ImageApi, ListApi, ModalApi, RowApi, SliderApi, TabsApi, TextApi, TextFieldApi, VideoApi, } from './basic_components.js';
//# sourceMappingURL=index.d.ts.map