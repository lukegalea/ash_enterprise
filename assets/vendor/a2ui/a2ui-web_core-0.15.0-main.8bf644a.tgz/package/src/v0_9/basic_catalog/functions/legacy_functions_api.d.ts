/**
 * Function APIs that `@a2ui/web_core` 0.9.x shipped in its basic catalog but
 * that the published v0.9 basic catalog document never defined.
 *
 * They are kept out of `basicCatalog`, whose `toJson()` must match
 * `specification/v0_9/catalogs/basic/catalog.json`, and out of the generated
 * `BASIC_FUNCTION_APIS`, but stay in `BASIC_FUNCTIONS` so catalogs that
 * composed their function list from it keep resolving `add`, `equals`, and
 * the rest.
 *
 * @deprecated Define these functions in your own catalog instead.
 */
import { z } from 'zod';
/**
 * API of the legacy `add` function.
 *
 * @deprecated Define `add` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const AddApi: {
    name: "add";
    returnType: "number";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
};
/**
 * API of the legacy `subtract` function.
 *
 * @deprecated Define `subtract` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const SubtractApi: {
    name: "subtract";
    returnType: "number";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
};
/**
 * API of the legacy `multiply` function.
 *
 * @deprecated Define `multiply` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const MultiplyApi: {
    name: "multiply";
    returnType: "number";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
};
/**
 * API of the legacy `divide` function.
 *
 * @deprecated Define `divide` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const DivideApi: {
    name: "divide";
    returnType: "number";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
};
/**
 * API of the legacy `equals` function.
 *
 * @deprecated Define `equals` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const EqualsApi: {
    name: "equals";
    returnType: "boolean";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodAny, any, any>;
        b: z.ZodEffects<z.ZodAny, any, any>;
    }, "strip", z.ZodTypeAny, {
        a?: any;
        b?: any;
    }, {
        a?: any;
        b?: any;
    }>;
};
/**
 * API of the legacy `not_equals` function.
 *
 * @deprecated Define `not_equals` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const NotEqualsApi: {
    name: "not_equals";
    returnType: "boolean";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodAny, any, any>;
        b: z.ZodEffects<z.ZodAny, any, any>;
    }, "strip", z.ZodTypeAny, {
        a?: any;
        b?: any;
    }, {
        a?: any;
        b?: any;
    }>;
};
/**
 * API of the legacy `greater_than` function.
 *
 * @deprecated Define `greater_than` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const GreaterThanApi: {
    name: "greater_than";
    returnType: "boolean";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
};
/**
 * API of the legacy `less_than` function.
 *
 * @deprecated Define `less_than` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const LessThanApi: {
    name: "less_than";
    returnType: "boolean";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
};
/**
 * API of the legacy `contains` function.
 *
 * @deprecated Define `contains` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const ContainsApi: {
    name: "contains";
    returnType: "boolean";
    schema: z.ZodObject<{
        string: z.ZodEffects<z.ZodString, string, unknown>;
        substring: z.ZodEffects<z.ZodString, string, unknown>;
    }, "strip", z.ZodTypeAny, {
        string: string;
        substring: string;
    }, {
        string?: unknown;
        substring?: unknown;
    }>;
};
/**
 * API of the legacy `starts_with` function.
 *
 * @deprecated Define `starts_with` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const StartsWithApi: {
    name: "starts_with";
    returnType: "boolean";
    schema: z.ZodObject<{
        string: z.ZodEffects<z.ZodString, string, unknown>;
        prefix: z.ZodEffects<z.ZodString, string, unknown>;
    }, "strip", z.ZodTypeAny, {
        string: string;
        prefix: string;
    }, {
        string?: unknown;
        prefix?: unknown;
    }>;
};
/**
 * API of the legacy `ends_with` function.
 *
 * @deprecated Define `ends_with` in your own catalog instead; the v0.9 basic
 *   catalog document does not include it.
 */
export declare const EndsWithApi: {
    name: "ends_with";
    returnType: "boolean";
    schema: z.ZodObject<{
        string: z.ZodEffects<z.ZodString, string, unknown>;
        suffix: z.ZodEffects<z.ZodString, string, unknown>;
    }, "strip", z.ZodTypeAny, {
        string: string;
        suffix: string;
    }, {
        string?: unknown;
        suffix?: unknown;
    }>;
};
/**
 * The legacy function APIs, in the order `@a2ui/web_core` 0.9.x listed them.
 *
 * @deprecated See the module documentation.
 */
export declare const LEGACY_V09_FUNCTION_APIS: ({
    name: "add";
    returnType: "number";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
} | {
    name: "subtract";
    returnType: "number";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
} | {
    name: "multiply";
    returnType: "number";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
} | {
    name: "divide";
    returnType: "number";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
} | {
    name: "equals";
    returnType: "boolean";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodAny, any, any>;
        b: z.ZodEffects<z.ZodAny, any, any>;
    }, "strip", z.ZodTypeAny, {
        a?: any;
        b?: any;
    }, {
        a?: any;
        b?: any;
    }>;
} | {
    name: "not_equals";
    returnType: "boolean";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodAny, any, any>;
        b: z.ZodEffects<z.ZodAny, any, any>;
    }, "strip", z.ZodTypeAny, {
        a?: any;
        b?: any;
    }, {
        a?: any;
        b?: any;
    }>;
} | {
    name: "greater_than";
    returnType: "boolean";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
} | {
    name: "less_than";
    returnType: "boolean";
    schema: z.ZodObject<{
        a: z.ZodEffects<z.ZodNumber, number, unknown>;
        b: z.ZodEffects<z.ZodNumber, number, unknown>;
    }, "strip", z.ZodTypeAny, {
        a: number;
        b: number;
    }, {
        a?: unknown;
        b?: unknown;
    }>;
} | {
    name: "contains";
    returnType: "boolean";
    schema: z.ZodObject<{
        string: z.ZodEffects<z.ZodString, string, unknown>;
        substring: z.ZodEffects<z.ZodString, string, unknown>;
    }, "strip", z.ZodTypeAny, {
        string: string;
        substring: string;
    }, {
        string?: unknown;
        substring?: unknown;
    }>;
} | {
    name: "starts_with";
    returnType: "boolean";
    schema: z.ZodObject<{
        string: z.ZodEffects<z.ZodString, string, unknown>;
        prefix: z.ZodEffects<z.ZodString, string, unknown>;
    }, "strip", z.ZodTypeAny, {
        string: string;
        prefix: string;
    }, {
        string?: unknown;
        prefix?: unknown;
    }>;
} | {
    name: "ends_with";
    returnType: "boolean";
    schema: z.ZodObject<{
        string: z.ZodEffects<z.ZodString, string, unknown>;
        suffix: z.ZodEffects<z.ZodString, string, unknown>;
    }, "strip", z.ZodTypeAny, {
        string: string;
        suffix: string;
    }, {
        string?: unknown;
        suffix?: unknown;
    }>;
})[];
//# sourceMappingURL=legacy_functions_api.d.ts.map