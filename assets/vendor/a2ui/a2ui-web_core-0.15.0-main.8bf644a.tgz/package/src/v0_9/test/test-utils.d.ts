import { ComponentContext } from '../../resolution/component-context.js';
import { SurfaceModel } from '../../state/surface-model.js';
import { ComponentApi } from '../../catalog/types.js';
/**
 * Test double for `SurfaceModel` initialized with an empty catalog.
 */
export declare class TestSurfaceModel extends SurfaceModel<ComponentApi> {
    /**
     * Creates a new `TestSurfaceModel` instance.
     *
     * @param actionHandler Optional action listener callback.
     */
    constructor(actionHandler?: any);
}
/**
 * Creates a mock `ComponentContext` bound to a test surface and component model.
 *
 * @param properties Component properties dictionary.
 * @param actionHandler Optional action listener callback.
 * @returns Initialized component context for testing.
 */
export declare function createTestContext(properties: any, actionHandler?: any): ComponentContext;
//# sourceMappingURL=test-utils.d.ts.map