/**
 * A2UI Web Core Library.
 *
 * Provides core catalog-agnostic state management, data binding, expression evaluation,
 * message processing, and validation infrastructure for A2UI renderers and clients.
 */
export * from './catalog/index.js';
export * from './state/index.js';
export * from './processing/index.js';
export * from './resolution/index.js';
export * from './validation/index.js';
export * from './reactivity/index.js';
export * from './expressions/index.js';
export * from './errors.js';
export * from './common/events.js';
export * from './common/markdown.js';
export * from './common/sanitize_media_url.js';
export { validateMetadata, cloneMetadata, metadataEquals, type A2uiMetadata, type Extensions, type ActionDispatchOptions, } from './common/metadata.js';
export * from './common/semver.js';
export * from './common/uax31.js';
export { MAX_REGEX_PATTERN_CODE_POINTS, MAX_REGEX_VALUE_CODE_POINTS, RegexSyntaxError, analyzeRegex, checkRegexSafety, parseRegexSubset, type AnchorKind, type CodePointRange, type RegexAnalysisResult, type RegexNode, type RegexRejection, } from './common/regex_subset.js';
export * from './spec_versions.js';
export { isSafeRegex, type SafeRegexOptions } from './v0_9/basic_catalog/functions/safe_regex.js';
//# sourceMappingURL=index.d.ts.map