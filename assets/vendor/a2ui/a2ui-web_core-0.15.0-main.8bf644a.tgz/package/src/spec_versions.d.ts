/**
 * Standard protocol versions supported by the A2UI specification and runtime.
 */
export declare enum SpecVersion {
    V0_8 = "v0.8",
    V0_9 = "v0.9",
    V0_9_1 = "v0.9.1",
    V1_0 = "1.0"
}
//# sourceMappingURL=spec_versions.d.ts.map