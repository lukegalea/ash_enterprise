import { Root } from './root.js';
export declare class List extends Root {
    accessor direction: 'vertical' | 'horizontal';
    static styles: import("lit").CSSResultGroup[];
    render(): import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=list.d.ts.map