/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
import { html, css, nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { Root } from './root.js';
import { A2uiMessageProcessor } from '@a2ui/web_core/data/model-processor';
import { classMap } from 'lit/directives/class-map.js';
import { styleMap } from 'lit/directives/style-map.js';
import { structuralStyles } from './styles.js';
let DateTimeInput = (() => {
    let _classDecorators = [customElement('a2ui-datetimeinput')];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = Root;
    let _value_decorators;
    let _value_initializers = [];
    let _value_extraInitializers = [];
    let _label_decorators;
    let _label_initializers = [];
    let _label_extraInitializers = [];
    let _enableDate_decorators;
    let _enableDate_initializers = [];
    let _enableDate_extraInitializers = [];
    let _enableTime_decorators;
    let _enableTime_initializers = [];
    let _enableTime_extraInitializers = [];
    var DateTimeInput = class extends _classSuper {
        static { _classThis = this; }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _value_decorators = [property()];
            _label_decorators = [property()];
            _enableDate_decorators = [property({ reflect: false, type: Boolean })];
            _enableTime_decorators = [property({ reflect: false, type: Boolean })];
            __esDecorate(this, null, _value_decorators, { kind: "accessor", name: "value", static: false, private: false, access: { has: obj => "value" in obj, get: obj => obj.value, set: (obj, value) => { obj.value = value; } }, metadata: _metadata }, _value_initializers, _value_extraInitializers);
            __esDecorate(this, null, _label_decorators, { kind: "accessor", name: "label", static: false, private: false, access: { has: obj => "label" in obj, get: obj => obj.label, set: (obj, value) => { obj.label = value; } }, metadata: _metadata }, _label_initializers, _label_extraInitializers);
            __esDecorate(this, null, _enableDate_decorators, { kind: "accessor", name: "enableDate", static: false, private: false, access: { has: obj => "enableDate" in obj, get: obj => obj.enableDate, set: (obj, value) => { obj.enableDate = value; } }, metadata: _metadata }, _enableDate_initializers, _enableDate_extraInitializers);
            __esDecorate(this, null, _enableTime_decorators, { kind: "accessor", name: "enableTime", static: false, private: false, access: { has: obj => "enableTime" in obj, get: obj => obj.enableTime, set: (obj, value) => { obj.enableTime = value; } }, metadata: _metadata }, _enableTime_initializers, _enableTime_extraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            DateTimeInput = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        }
        #value_accessor_storage = __runInitializers(this, _value_initializers, null);
        get value() { return this.#value_accessor_storage; }
        set value(value) { this.#value_accessor_storage = value; }
        #label_accessor_storage = (__runInitializers(this, _value_extraInitializers), __runInitializers(this, _label_initializers, null));
        get label() { return this.#label_accessor_storage; }
        set label(value) { this.#label_accessor_storage = value; }
        #enableDate_accessor_storage = (__runInitializers(this, _label_extraInitializers), __runInitializers(this, _enableDate_initializers, true));
        get enableDate() { return this.#enableDate_accessor_storage; }
        set enableDate(value) { this.#enableDate_accessor_storage = value; }
        #enableTime_accessor_storage = (__runInitializers(this, _enableDate_extraInitializers), __runInitializers(this, _enableTime_initializers, true));
        get enableTime() { return this.#enableTime_accessor_storage; }
        set enableTime(value) { this.#enableTime_accessor_storage = value; }
        static { this.styles = [
            structuralStyles,
            css `
      * {
        box-sizing: border-box;
      }

      :host {
        display: block;
        flex: var(--weight);
        min-height: 0;
        overflow: auto;
      }

      input {
        display: block;
        border-radius: 8px;
        padding: 8px;
        border: 1px solid #ccc;
        width: 100%;
        color: #333;
      }

      input::-webkit-datetime-edit,
      input::-webkit-datetime-edit-fields-wrapper {
        color: #333;
      }
    `,
        ]; }
        #setBoundValue(value) {
            if (!this.value || !this.processor) {
                return;
            }
            if (!('path' in this.value)) {
                return;
            }
            if (!this.value.path) {
                return;
            }
            this.processor.setData(this.component, this.value.path, value, this.surfaceId ?? A2uiMessageProcessor.DEFAULT_SURFACE_ID);
        }
        #renderField(value) {
            return html `<section class=${classMap(this.theme.components.DateTimeInput.container)}>
      <label for="data" class=${classMap(this.theme.components.DateTimeInput.label)}
        >${this.#getPlaceholderText()}</label
      >
      <input
        autocomplete="off"
        class=${classMap(this.theme.components.DateTimeInput.element)}
        style=${this.theme.additionalStyles?.DateTimeInput
                ? styleMap(this.theme.additionalStyles?.DateTimeInput)
                : nothing}
        @input=${(evt) => {
                if (!(evt.target instanceof HTMLInputElement)) {
                    return;
                }
                this.#setBoundValue(evt.target.value);
            }}
        id="data"
        name="data"
        .value=${this.#formatInputValue(value)}
        .placeholder=${this.#getPlaceholderText()}
        .type=${this.#getInputType()}
      />
    </section>`;
        }
        #getInputType() {
            if (this.enableDate && this.enableTime) {
                return 'datetime-local';
            }
            else if (this.enableDate) {
                return 'date';
            }
            else if (this.enableTime) {
                return 'time';
            }
            return 'datetime-local';
        }
        #formatInputValue(value) {
            const inputType = this.#getInputType();
            const date = value ? new Date(value) : null;
            if (!date || isNaN(date.getTime())) {
                return '';
            }
            const year = this.#padNumber(date.getFullYear());
            const month = this.#padNumber(date.getMonth() + 1);
            const day = this.#padNumber(date.getDate());
            const hours = this.#padNumber(date.getHours());
            const minutes = this.#padNumber(date.getMinutes());
            // Browsers are picky with what format they allow for the `value` attribute of date/time inputs.
            // We need to parse it out of the provided value. Note that we don't use `toISOString`,
            // because the resulting value is relative to UTC.
            if (inputType === 'date') {
                return `${year}-${month}-${day}`;
            }
            else if (inputType === 'time') {
                return `${hours}:${minutes}`;
            }
            return `${year}-${month}-${day}T${hours}:${minutes}`;
        }
        #padNumber(value) {
            return value.toString().padStart(2, '0');
        }
        #getPlaceholderText() {
            // TODO: this should likely be passed from the model.
            const inputType = this.#getInputType();
            if (inputType === 'date') {
                return 'Date';
            }
            else if (inputType === 'time') {
                return 'Time';
            }
            return 'Date & Time';
        }
        render() {
            if (this.value && typeof this.value === 'object') {
                if ('literalString' in this.value && this.value.literalString) {
                    return this.#renderField(this.value.literalString);
                }
                else if ('literal' in this.value && this.value.literal !== undefined) {
                    return this.#renderField(this.value.literal);
                }
                else if (this.value && 'path' in this.value && this.value.path) {
                    if (!this.processor || !this.component) {
                        return html `(no model)`;
                    }
                    const textValue = this.processor.getData(this.component, this.value.path, this.surfaceId ?? A2uiMessageProcessor.DEFAULT_SURFACE_ID);
                    if (typeof textValue !== 'string') {
                        return html `(invalid)`;
                    }
                    return this.#renderField(textValue);
                }
            }
            return nothing;
        }
        constructor() {
            super(...arguments);
            __runInitializers(this, _enableTime_extraInitializers);
        }
        static {
            __runInitializers(_classThis, _classExtraInitializers);
        }
    };
    return DateTimeInput = _classThis;
})();
export { DateTimeInput };
//# sourceMappingURL=datetime-input.js.map