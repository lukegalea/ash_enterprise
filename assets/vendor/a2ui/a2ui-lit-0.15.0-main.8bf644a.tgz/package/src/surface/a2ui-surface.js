/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
import { html, nothing, LitElement } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { NodeResolver, effect, getValue, } from '@a2ui/web_core';
import { renderA2uiNode } from './render-a2ui-node.js';
/**
 * A Lit component that renders an A2UI Surface.
 *
 * This component takes a `SurfaceModel` and dynamically renders the root component
 * and its children using the provided catalog. It handles loading states if the
 * root component is not yet available.
 *
 * @element a2ui-surface
 */
let A2uiSurface = (() => {
    let _classDecorators = [customElement('a2ui-surface')];
    let _classDescriptor;
    let _classExtraInitializers = [];
    let _classThis;
    let _classSuper = LitElement;
    let _surface_decorators;
    let _surface_initializers = [];
    let _surface_extraInitializers = [];
    let __rootNode_decorators;
    let __rootNode_initializers = [];
    let __rootNode_extraInitializers = [];
    var A2uiSurface = class extends _classSuper {
        static { _classThis = this; }
        constructor() {
            super(...arguments);
            this.#surface_accessor_storage = __runInitializers(this, _surface_initializers, void 0);
            this.#_rootNode_accessor_storage = (__runInitializers(this, _surface_extraInitializers), __runInitializers(this, __rootNode_initializers, void 0));
            /**
             * Subscription cleanup function.
             * @internal
             */
            this.unsubscribe = __runInitializers(this, __rootNode_extraInitializers);
        }
        static {
            const _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(_classSuper[Symbol.metadata] ?? null) : void 0;
            _surface_decorators = [property({ type: Object })];
            __rootNode_decorators = [state()];
            __esDecorate(this, null, _surface_decorators, { kind: "accessor", name: "surface", static: false, private: false, access: { has: obj => "surface" in obj, get: obj => obj.surface, set: (obj, value) => { obj.surface = value; } }, metadata: _metadata }, _surface_initializers, _surface_extraInitializers);
            __esDecorate(this, null, __rootNode_decorators, { kind: "accessor", name: "_rootNode", static: false, private: false, access: { has: obj => "_rootNode" in obj, get: obj => obj._rootNode, set: (obj, value) => { obj._rootNode = value; } }, metadata: _metadata }, __rootNode_initializers, __rootNode_extraInitializers);
            __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
            A2uiSurface = _classThis = _classDescriptor.value;
            if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
            __runInitializers(_classThis, _classExtraInitializers);
        }
        #surface_accessor_storage;
        /**
         * The surface model containing the component tree and catalog.
         */
        get surface() { return this.#surface_accessor_storage; }
        set surface(value) { this.#surface_accessor_storage = value; }
        #_rootNode_accessor_storage;
        /**
         * Resolved root component node from `NodeResolver`.
         * @internal
         */
        get _rootNode() { return this.#_rootNode_accessor_storage; }
        set _rootNode(value) { this.#_rootNode_accessor_storage = value; }
        /**
         * Returns the currently resolved root component node for this surface, if any.
         */
        get rootNode() {
            return this._rootNode;
        }
        /**
         * Renders into the element's direct children (Light DOM) instead of a ShadowRoot
         * so host stylesheets can target components inside the surface.
         */
        createRenderRoot() {
            return this;
        }
        /**
         * Handles lifecycle updates, specifically when the `surface` property changes.
         *
         * It subscribes to the components model so the surface re-renders whenever
         * the 'root' component is created or deleted.
         *
         * @param changedProperties Map of changed properties.
         */
        willUpdate(changedProperties) {
            if (changedProperties.has('surface')) {
                this.subscribeToRoot();
            }
        }
        /**
         * Restores the root subscriptions when the element is reattached.
         */
        connectedCallback() {
            super.connectedCallback();
            if (this.surface && !this.unsubscribe) {
                this.subscribeToRoot();
            }
        }
        /**
         * Cleans up subscriptions.
         */
        disconnectedCallback() {
            super.disconnectedCallback();
            this.unsubscribe?.();
            this.unsubscribe = undefined;
            this._rootNode = undefined;
        }
        /**
         * Tracks the 'root' component of the current surface via `NodeResolver` for
         * as long as the surface is shown.
         *
         * The processor replaces a component's model when an update changes its
         * type or catalog, deleting the old model and creating a new one, so the
         * subscription outlives the first creation of the root: the surface then
         * renders the new model.
         */
        subscribeToRoot() {
            this.unsubscribe?.();
            this.unsubscribe = undefined;
            this._rootNode = undefined;
            if (!this.surface) {
                return;
            }
            const resolver = new NodeResolver(this.surface);
            const stopEffect = effect(() => {
                this._rootNode = getValue(resolver.rootNode);
            });
            this.unsubscribe = () => {
                stopEffect();
                resolver.dispose();
            };
        }
        /**
         * Renders the surface.
         *
         * If `surface` is not set, or the root has not resolved (it has not arrived,
         * has an unknown type, or is part of a cycle), returns `nothing`.
         * Otherwise, renders the root component using `renderA2uiNode`.
         */
        render() {
            if (!this.surface)
                return nothing;
            const root = this._rootNode;
            // Nothing to show until the root resolves (pending, unknown type or cycle).
            if (!root || root.isPlaceholder)
                return nothing;
            try {
                return renderA2uiNode(root);
            }
            catch (e) {
                console.error('Error rendering root node:', e);
                return html `<div>Error rendering surface</div>`;
            }
        }
    };
    return A2uiSurface = _classThis;
})();
export { A2uiSurface };
//# sourceMappingURL=a2ui-surface.js.map