export { renderA2uiNode } from '@a2ui/web_core/universal';
//# sourceMappingURL=render-a2ui-node.d.ts.map