import type { WebComponentImplementation } from '@a2ui/web_core/universal';
/**
 * Interface representing an A2UI component implementation in Lit / Web Components.
 *
 * Re-exported for backwards compatibility as a type alias for `WebComponentImplementation`.
 */
export type LitComponentApi = WebComponentImplementation;
//# sourceMappingURL=types.d.ts.map