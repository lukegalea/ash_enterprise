export { A2uiController } from '@a2ui/web_core/universal';
//# sourceMappingURL=a2ui-controller.d.ts.map